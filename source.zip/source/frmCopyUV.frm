VERSION 5.00
Begin VB.Form frmCopyUV 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Copy UV Channels"
   ClientHeight    =   1095
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4335
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmCopyUV.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   73
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   289
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.CommandButton cmdCopy 
      Caption         =   "Copy"
      Height          =   375
      Left            =   3120
      TabIndex        =   3
      Top             =   120
      Width           =   1095
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      Height          =   375
      Left            =   3120
      TabIndex        =   2
      Top             =   600
      Width           =   1095
   End
   Begin VB.ComboBox cbbDst 
      Height          =   315
      ItemData        =   "frmCopyUV.frx":000C
      Left            =   1200
      List            =   "frmCopyUV.frx":000E
      Style           =   2  'Dropdown List
      TabIndex        =   1
      Top             =   540
      Width           =   1815
   End
   Begin VB.ComboBox cbbSrc 
      Height          =   315
      ItemData        =   "frmCopyUV.frx":0010
      Left            =   1200
      List            =   "frmCopyUV.frx":0012
      Style           =   2  'Dropdown List
      TabIndex        =   0
      Top             =   120
      Width           =   1815
   End
   Begin VB.Label labMisc 
      AutoSize        =   -1  'True
      Caption         =   "Destination:"
      Height          =   195
      Index           =   4
      Left            =   120
      TabIndex        =   5
      Top             =   600
      Width           =   870
   End
   Begin VB.Label labMisc 
      AutoSize        =   -1  'True
      Caption         =   "Source:"
      Height          =   195
      Index           =   2
      Left            =   120
      TabIndex        =   4
      Top             =   180
      Width           =   555
   End
End
Attribute VB_Name = "frmCopyUV"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    FillChannelList Me.cbbDst
    FillChannelList Me.cbbSrc
End Sub

Private Sub cmdCopy_Click()
    If Not CopyUVs(Me.cbbSrc.ListIndex, Me.cbbDst.ListIndex) Then Exit Sub
    RedrawViewports
    Unload Me
End Sub

Private Sub cmdClose_Click()
    Unload Me
End Sub

'copies UV channels
Private Function CopyUVs(ByVal src As Long, ByVal dst As Long) As Boolean
    If src = dst Then
        MsgBox "Source and destination channels are the same!", vbExclamation
        Exit Function
    End If
    With vmesh
        If Not .loadok Then Exit Function
        
        Dim srcUVoffset As Long
        Dim dstUVoffset As Long
        srcUVoffset = BF2MeshGetTexcOffset(src)
        dstUVoffset = BF2MeshGetTexcOffset(dst)
        
        Dim i As Long
        For i = 0 To .vertnum - 1
            'If .vertinfo(i).flag Then
            'If .vertinfo(i).sel Then
                
                .vert(i * .stride + dstUVoffset + 0) = .vert(i * .stride + srcUVoffset + 0)
                .vert(i * .stride + dstUVoffset + 1) = .vert(i * .stride + srcUVoffset + 1)
                
            'End If
            'End If
        Next i
    End With
    CopyUVs = True
End Function

