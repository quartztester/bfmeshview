VERSION 5.00
Begin VB.Form frmTransform 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Vertex Transform"
   ClientHeight    =   1815
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   3375
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmTransform.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   121
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   225
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.TextBox txtBoneID 
      Height          =   285
      Left            =   960
      TabIndex        =   0
      Text            =   "0"
      Top             =   120
      Width           =   975
   End
   Begin VB.CommandButton cmdSelect 
      Caption         =   "Select"
      Height          =   375
      Left            =   2160
      TabIndex        =   4
      Top             =   120
      Width           =   1095
   End
   Begin VB.CommandButton cmdMove 
      Caption         =   "Move"
      Height          =   375
      Left            =   2160
      TabIndex        =   5
      Top             =   1320
      Width           =   1095
   End
   Begin VB.TextBox txtOffset 
      Alignment       =   2  'Center
      BackColor       =   &H00FFC0C0&
      Height          =   285
      Index           =   2
      Left            =   960
      TabIndex        =   3
      Text            =   "0.0"
      Top             =   1440
      Width           =   975
   End
   Begin VB.TextBox txtOffset 
      Alignment       =   2  'Center
      BackColor       =   &H00C0FFC0&
      Height          =   285
      Index           =   1
      Left            =   960
      TabIndex        =   2
      Text            =   "0.0"
      Top             =   1080
      Width           =   975
   End
   Begin VB.TextBox txtOffset 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0FF&
      Height          =   285
      Index           =   0
      Left            =   960
      TabIndex        =   1
      Text            =   "0.0"
      Top             =   720
      Width           =   975
   End
   Begin VB.Line Line1 
      BorderColor     =   &H80000010&
      Index           =   1
      X1              =   8
      X2              =   216
      Y1              =   39
      Y2              =   39
   End
   Begin VB.Line Line1 
      BorderColor     =   &H80000014&
      Index           =   0
      X1              =   8
      X2              =   216
      Y1              =   40
      Y2              =   40
   End
   Begin VB.Label labMisc 
      AutoSize        =   -1  'True
      Caption         =   "Offset Z:"
      Height          =   195
      Index           =   2
      Left            =   120
      TabIndex        =   9
      Top             =   1470
      Width           =   660
   End
   Begin VB.Label labMisc 
      AutoSize        =   -1  'True
      Caption         =   "Offset Y:"
      Height          =   195
      Index           =   1
      Left            =   120
      TabIndex        =   8
      Top             =   1110
      Width           =   660
   End
   Begin VB.Label labMisc 
      AutoSize        =   -1  'True
      Caption         =   "Bone ID:"
      Height          =   195
      Index           =   3
      Left            =   120
      TabIndex        =   7
      Top             =   150
      Width           =   630
   End
   Begin VB.Label labMisc 
      AutoSize        =   -1  'True
      Caption         =   "Offset X:"
      Height          =   195
      Index           =   0
      Left            =   120
      TabIndex        =   6
      Top             =   750
      Width           =   660
   End
End
Attribute VB_Name = "frmTransform"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    SetTopMostWindow Me.hWnd, True
End Sub

Private Sub Form_Unload(Cancel As Integer)
    frmMain.picMain_Paint
End Sub

Private Sub cmdSelect_Click()
    ClearSelection
    UpdateSelection
    frmMain.picMain_Paint
End Sub

Private Sub cmdMove_Click()
    MoveVerts
    frmMain.picMain_Paint
End Sub

'------------------------------------------------------------------------------------------------------------


'sets vertex flags
Private Sub UpdateSelection()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim selid As Long
        selid = val(Me.txtBoneID.Text)
        
        Dim attriboff As Long
        attriboff = BF2MeshGetWeightOffset()
        
        UpdateMaskFlags
        
        Dim vw As bf2vw
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
                
                'get block
                CopyMem VarPtr(vw), VarPtr(.vert(i * .stride + attriboff)), 4
                
                If vw.b1 = selid Then
                    .vertinfo(i).sel = 1
                Else
                    .vertinfo(i).sel = 0
                End If
                
            End If
        Next i
        
    End With
End Sub


'move vertices by bone index
Private Sub MoveVerts()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim offset As float3
        offset.x = val(Me.txtOffset(0).Text)
        offset.y = val(Me.txtOffset(1).Text)
        offset.z = val(Me.txtOffset(2).Text)
        
        UpdateMaskFlags
        
        Dim i As Long
        
        If selmode = sel_vert Then
            For i = 0 To .vertnum - 1
                If .vertinfo(i).flag Then
                    If .vertinfo(i).sel Then
                        SetVert i, AddFloat3(GetVert(i), offset)
                    End If
                End If
            Next i
        End If
        
        If selmode >= sel_face Then
            For i = 0 To .vertnum - 1
                If .vertinfo(i).flag Then
                    If .vertinfo(i).facesel Then
                        SetVert i, AddFloat3(GetVert(i), offset)
                    End If
                End If
            Next i
        End If
        
    End With
End Sub

Private Sub txtOffset_Validate(index As Integer, Cancel As Boolean)
    txtOffset(index).Text = FormatFloat(txtOffset(index).Text)
End Sub
