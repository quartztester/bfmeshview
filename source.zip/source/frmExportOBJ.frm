VERSION 5.00
Begin VB.Form frmExportOBJ 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "OBJ Export"
   ClientHeight    =   3255
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4455
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmExportOBJ.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   217
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   297
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.CheckBox chkDeform 
      Caption         =   "Export Transformed Vertices"
      Height          =   255
      Left            =   120
      TabIndex        =   1
      Top             =   1050
      Value           =   1  'Checked
      Width           =   2415
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   120
      TabIndex        =   3
      Top             =   2760
      Width           =   1095
   End
   Begin VB.ComboBox cbbChannel 
      Height          =   315
      ItemData        =   "frmExportOBJ.frx":000C
      Left            =   1200
      List            =   "frmExportOBJ.frx":000E
      Style           =   2  'Dropdown List
      TabIndex        =   0
      Top             =   660
      Width           =   1815
   End
   Begin VB.CommandButton cmdExport 
      Caption         =   "Export"
      Height          =   375
      Left            =   3240
      TabIndex        =   2
      Top             =   2760
      Width           =   1095
   End
   Begin VB.Label Label1 
      Caption         =   $"frmExportOBJ.frx":0010
      ForeColor       =   &H000000C0&
      Height          =   855
      Left            =   120
      TabIndex        =   6
      Top             =   1620
      Width           =   4095
   End
   Begin VB.Line Line1 
      BorderColor     =   &H80000014&
      Index           =   3
      X1              =   8
      X2              =   288
      Y1              =   174
      Y2              =   174
   End
   Begin VB.Line Line1 
      BorderColor     =   &H80000010&
      Index           =   2
      X1              =   8
      X2              =   288
      Y1              =   173
      Y2              =   173
   End
   Begin VB.Line Line1 
      BorderColor     =   &H80000014&
      Index           =   1
      X1              =   8
      X2              =   288
      Y1              =   97
      Y2              =   97
   End
   Begin VB.Line Line1 
      BorderColor     =   &H80000010&
      Index           =   0
      X1              =   8
      X2              =   288
      Y1              =   96
      Y2              =   96
   End
   Begin VB.Label labMisc 
      Caption         =   "The WaveFront/OBJ file format supports only one texture coordinate (UV) channel. Please choose a channel below."
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   5
      Top             =   120
      Width           =   4275
   End
   Begin VB.Label labMisc 
      AutoSize        =   -1  'True
      Caption         =   "UV Channel:"
      Height          =   195
      Index           =   2
      Left            =   120
      TabIndex        =   4
      Top             =   720
      Width           =   885
   End
End
Attribute VB_Name = "frmExportOBJ"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private export_fname As String
Private export_chan As Long

Private Sub Form_Load()
    
    'fill UV channel listbox
    FillChannelList Me.cbbChannel
    
    'remember last used channel
    If Me.cbbChannel.ListCount > export_chan Then Me.cbbChannel.ListIndex = export_chan
    
End Sub

Private Sub cmdExport_Click()
    
    'just in case
    RunConformanceTest
    
    'get chosen channel index
    export_chan = Me.cbbChannel.ListIndex
    
    'export to OBJ
    ExportMesh export_fname, export_chan, (Me.chkDeform.value = vbChecked)
    
    'hide window
    Unload Me
    
End Sub

Private Sub cmdCancel_Click()
    Unload Me
End Sub

'shows export dialog
Public Sub Export(ByRef fname As String)
    export_fname = fname
    frmExportOBJ.Show vbModal
End Sub
