Attribute VB_Name = "BF2_Renormalize"
Option Explicit
