Attribute VB_Name = "BF2_MeshStruct"
Option Explicit

'--- BfMeshView internal structures -----------------------------------------------------------------------

'internal struct, we use this for our approximate shading
Public Type mat_layer
    texmapid As Long            'index of texmap
    texcoff As Long             '...
    blend As Boolean            'blending
    blendsrc As GLuint          'blend source factor
    blenddst As GLuint          'blend destination factor
    alphaTest As Boolean        'alpha testing
    alpharef As Single          'alpha cutoff value [0-1]
    depthfunc As GLenum         'depth testing function
    depthWrite As GLboolean     'write to z-buffer
    twosided As Boolean         'two-sided
    lighting As Boolean         'FFP lighting
End Type

'internal vertex info (helper structure generated after load time)
Public Type fh2vert
    geom As Byte        'geom index
    lod As Byte         'LOD index
    mat As Byte         'LOD material index
    
    sel As Byte         'selection
    flag As Byte        'selection mask flag
    facesel As Byte     'set if face selected
    
    'tf As float3        'transformed position (TODO: use this to replace vmesh.skinpos())
    sv As float3        'screen space projected vertex
    sharepos As Long    'index of first vertex of this LOD we share position with
    sharenorm As Long   'index of first vertex of this LOD we share position+normal with
    sharetang As Long   'index of first vertex of this LOD we share position+normal+tangent with
    elem As Long        'element ID
End Type

'internal structure
Public Type fh2edge
    geom As Byte        'geom index
    lod As Byte         'LOD index
    mat As Byte         'LOD material index
    
    sel As Byte         'selection
    flag As Byte        'selecton mask
    
    v1 As Long          'vertex index 1
    v2 As Long          'vertex index 2
    
    f1 As Long          'face index 1
    f2 As Long          'face index 2
    
    elem As Long        'element ID
End Type

'internal structure
Public Type fh2face
    geom As Byte        'geom index
    lod As Byte         'LOD index
    mat As Byte         'LOD material index
    
    sel As Byte         'selection
    flag As Byte        'selecton mask
    bad As Byte         'marked as bad face (skip when processing)
    
    v1 As Long          'vertex index 1
    v2 As Long          'vertex index 2
    v3 As Long          'vertex index 3
    
    poly As Long        'polygon ID
    elem As Long        'element ID
    f1 As Long          'face index of neighbor on edge 1
    f2 As Long          'face index of neighbor on edge 2
    f3 As Long          'face index of neighbor on edge 3
    
    n As float3         'face normal vector
    area As Single      'face surface area
    angle1 As Single    'v1 corner angle
    angle2 As Single    'v2 corner angle
    angle3 As Single    'v3 corner angle
    
    mathash As Long     'material hash (for comparing)
End Type

Public Type fh2poly
    sel As Byte         'selected
    'faces As Long       'number of faces
End Type

Public Type fh2elem
    sel As Byte         'selected
    'faces As Long       'number of faces
End Type

'--- BF2 Mesh Structures ----------------------------------------------------------------------------

'bf2 mesh file header
Public Type bf2head '20 bytes
    u1 As Long          '0
    version As Long     '10 for most bundledmesh, 6 for some bundledmesh, 11 for staticmesh
    u3 As Long          '0
    u4 As Long          '0
    u5 As Long          '0
End Type


'bf2 vertex attribute table entry
Public Type bf2vertattrib '8 bytes
    flag As Integer         'some sort of boolean flag (if true the below field are to be ignored?)
    offset As Integer       'offset from vertex data start
    vartype As Integer      'attribute type (vec2, vec3 etc)
    usage As Integer        'usage ID (vertex, texcoord etc)
    
    'Note: "usage" field correspond to the definition in DX SDK "Include\d3d9types.h"
    '      It looks like DICE extended these for additional UV channels, these
    '      constants are much larger so they don't conflict with other DX enums.
End Type


'bf2 bone structure
Public Type bf2bone  '68 bytes
    id As Long        'bone ID (4 bytes)
    matrix As matrix4 'inverse bone matrix (64 bytes)
    
    'internal
    skinmat As matrix4  'world space deformed skin transform
End Type


'bf2 rig structure
Public Type bf2rig
    bonenum As Long
    bone() As bf2bone
End Type


'bf2 lod material (drawcall)
Public Type bf2mat
    alphamode As Long     '0=opaque, 1=blend, 2=alphatest
    fxfile As String      'shader filename string
    technique As String   'technique name
    
    'texture map filenames
    mapnum As Long
    map() As String
    
    'geometry info
    vstart As Long      'vertex start offset
    istart As Long      'index start offset
    inum As Long        'number of indices
    vnum As Long        'number of vertices
    
    'unknown
    u4 As Long          '0
    u5 As Long          '0
    
    'per-material bounds (staticmesh only)
    mmin As float3
    mmax As float3
    
    ''''internal
    facenum As Long         'inum / 3
    texmapid() As Long      'texmap() index
    IsBumpMap() As Boolean  'if map is bump map
    mapuvid() As Long       'UV index for each map
    layernum As Long
    layer(1 To 4) As mat_layer
    glslprog As Long
    hasBump As Boolean
    hasWreck As Boolean
    hasAnimatedUV As Boolean
    hasBumpAlpha As Boolean
    hasDetail As Boolean
    hasDirt As Boolean
    hasCrack As Boolean
    hasCrackN As Boolean
    hasDetailN As Boolean
    hasEnvMap As Boolean
    alphaTest As Single
    twosided As Boolean
    vertStart As Long   'internal first vertex index
    vertEnd As Long     'internal last vertex index
    faceStart As Long   'internal first face index
    faceEnd As Long     'internal last face index
    hash As Long        'unique hash
    shortname As String 'UV editor material name
End Type


'bf2 lod
Public Type bf2lod
    
    'bounds
    min As float3
    max As float3
    pivot As float3 'not sure this is really a pivot (only on version<=6)
    
    'skinning matrices (skinnedmesh only)
    rignum As Long  'this corresponds to matnum
    rig() As bf2rig
    
    'nodes (staticmesh and bundledmesh only)
    nodenum As Long
    node() As matrix4
    
    'material groups
    matnum As Long
    mat() As bf2mat
    
    ''''internal
    polycount As Long   'number of triangles
    vertStart As Long   'internal first vertex index
    vertEnd As Long     'internal last vertex index
    faceStart As Long   'internal first face index
    faceEnd As Long     'internal last face index
End Type


'bf2 geom
Public Type bf2geom
    lodnum As Long
    lod() As bf2lod
End Type


'bf2 BundledMesh vertex weight (helper structure, memcopy float to this)
Public Type bf2vw
    b1 As Byte 'bone 1 index
    b2 As Byte 'bone 2 index
    w1 As Byte 'weight for bone 1
    w2 As Byte 'weight for bone 2
End Type


'bf2 SkinnedMesh vertex weight (helper structure, memcopy float to this)
Public Type bf2skinweight
    w As Single
    b1 As Byte
    b2 As Byte
    b3 As Byte
    b4 As Byte
End Type


'file structure
Public Type bf2mesh
    
    'header
    head As bf2head
    
    'unknown
    u1 As Byte 'always 0?
    
    'geoms
    geomnum As Long
    geom() As bf2geom
    
    'vertex attribute table
    vertattribnum As Long
    vertattrib() As bf2vertattrib
    
    'vertices
    vertformat As Long 'always 4?  (e.g. GL_FLOAT)
    vertstride As Long
    vertnum As Long
    vert() As Single
    
    'indices
    indexnum As Long
    index() As Integer
    
    'unknown
    u2 As Long 'always 8?
    
    ''''internal
    filename As String       'current loaded mesh file
    fileext As String        'filename extension
    isStaticMesh As Boolean  'true if file extension is "staticmesh"
    isSkinnedMesh As Boolean 'true if file extension is "skinnedmesh"
    isBundledMesh As Boolean 'true if file extension is "bundledmesh"
    isBFP4F As Boolean       'true if file is inside BFP4F directory
    loadok As Boolean        'mesh loaded properly
    drawok As Boolean        'mesh rendered properly
    stride As Long           'vertstride / 4
    facenum As Long          'facenum / 3
    polynum As Long          'number of polygons
    elemnum As Long          'number of elements
    normoff As Long          'vertex array normal vector offset
    tangoff As Long          'vertex array tangent vector offset
    texcoff As Long          'vertex array UV0 offset
    xtan() As float4         'corrected tangents
    uvnum As Long            'number of detected uv channels
    editinfo As Boolean      'has mesh_edit info computed
    
    vertinfo() As fh2vert    'vertex info & flags
    faceinfo() As fh2face    'face info & flags
    polyinfo() As fh2poly    'polygon info & flags
    eleminfo() As fh2elem    'element info & flags
    
    hasSkinVerts As Boolean  'deformed vertices flag
    skinvert() As float3     'deformed vertices
    skinnorm() As float3     'deformed normals
End Type


'--- helper functions -----------------------------------------------------------------------------------


'returns true if valid indices
Public Function IsValidGeom(ByVal g As Long) As Boolean
    With vmesh
        If .loadok Then
            If g >= 0 And g < .geomnum Then
                IsValidGeom = True
            End If
        End If
    End With
End Function


'returns true if valid indices
Public Function IsValidLod(ByVal g As Long, ByVal L As Long) As Boolean
    With vmesh
        If .loadok Then
            If g >= 0 And g < .geomnum Then
                If L >= 0 And L < .geom(g).lodnum Then
                    IsValidLod = True
                End If
            End If
        End If
    End With
End Function


'returns true if valid indices
Public Function IsValidMat(ByVal g As Long, ByVal L As Long, ByVal m As Long) As Boolean
    With vmesh
        If .loadok Then
            If g >= 0 And g < .geomnum Then
                If L >= 0 And L < .geom(g).lodnum Then
                    If m >= 0 And m < .geom(g).lod(L).matnum Then
                        IsValidMat = True
                    End If
                End If
            End If
        End If
    End With
End Function


'returns vertex buffer offset for normal attribute
Private Function BF2MeshGetAttribOffset(ByVal usageID As Long) As Long
    Dim i As Long
    With vmesh
        For i = 0 To .vertattribnum - 1
            If .vertattrib(i).usage = usageID Then
                BF2MeshGetAttribOffset = .vertattrib(i).offset / 4
                Exit Function
            End If
        Next i
    End With
    BF2MeshGetAttribOffset = -1
End Function


'returns vertex buffer offset for UV attribute
Public Function BF2MeshGetTexcOffset(ByVal uvchan As Long) As Long
    BF2MeshGetTexcOffset = -1
    If uvchan = 0 Then BF2MeshGetTexcOffset = BF2MeshGetAttribOffset(5)
    If uvchan = 1 Then BF2MeshGetTexcOffset = BF2MeshGetAttribOffset(261)
    If uvchan = 2 Then BF2MeshGetTexcOffset = BF2MeshGetAttribOffset(517)
    If uvchan = 3 Then BF2MeshGetTexcOffset = BF2MeshGetAttribOffset(773)
    If uvchan = 4 Then BF2MeshGetTexcOffset = BF2MeshGetAttribOffset(1029)
End Function


'returns vertex buffer offset for normal vector
Public Function BF2MeshGetNormOffset() As Long
    BF2MeshGetNormOffset = BF2MeshGetAttribOffset(3)
End Function


'returns vertex buffer offset for tangent vector
Public Function BF2MeshGetTangOffset() As Long
    BF2MeshGetTangOffset = BF2MeshGetAttribOffset(6)
End Function


'returns vertex buffer offset for weight/bone index attributes (start of 4 x 1-byte block)
Public Function BF2MeshGetWeightOffset() As Long
    BF2MeshGetWeightOffset = BF2MeshGetAttribOffset(2)
End Function
