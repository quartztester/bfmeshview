VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmMain 
   Caption         =   "BfMeshView"
   ClientHeight    =   10110
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   15240
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   674
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   1016
   StartUpPosition =   2  'CenterScreen
   Begin ComctlLib.ProgressBar pgbProgress 
      Height          =   255
      Left            =   9240
      TabIndex        =   12
      Top             =   480
      Visible         =   0   'False
      Width           =   3645
      _ExtentX        =   6429
      _ExtentY        =   450
      _Version        =   327682
      Appearance      =   1
   End
   Begin MSComctlLib.ImageList imlMesh 
      Left            =   2400
      Top             =   3960
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16711935
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   19
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1042
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":11AC
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":13A6
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1548
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":16F2
            Key             =   ""
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1854
            Key             =   ""
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":19BA
            Key             =   ""
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1D0C
            Key             =   ""
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":205E
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":23F0
            Key             =   ""
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":255E
            Key             =   ""
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":28F0
            Key             =   ""
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2A9E
            Key             =   ""
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2C50
            Key             =   ""
         EndProperty
         BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2DCA
            Key             =   ""
         EndProperty
         BeginProperty ListImage16 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2F54
            Key             =   ""
         EndProperty
         BeginProperty ListImage17 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":310E
            Key             =   ""
         EndProperty
         BeginProperty ListImage18 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3278
            Key             =   ""
         EndProperty
         BeginProperty ListImage19 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":33DE
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.Toolbar tlbMesh 
      Height          =   330
      Left            =   4920
      TabIndex        =   11
      Top             =   120
      Width           =   5145
      _ExtentX        =   9075
      _ExtentY        =   582
      ButtonWidth     =   609
      ButtonHeight    =   582
      AllowCustomize  =   0   'False
      Style           =   1
      ImageList       =   "imlMesh"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   18
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "selinside"
            Object.ToolTipText     =   "Select only faces entirely inside selection rectangle"
            ImageIndex      =   14
            Style           =   1
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "selbackface"
            Object.ToolTipText     =   "Select Backfaces"
            ImageIndex      =   15
            Style           =   1
            Value           =   1
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "vert"
            Object.ToolTipText     =   "Select Vertices"
            ImageIndex      =   3
            Style           =   2
            Value           =   1
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "edge"
            Object.ToolTipText     =   "Select Edges"
            ImageIndex      =   9
            Style           =   2
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "face"
            Object.ToolTipText     =   "Select Faces"
            ImageIndex      =   4
            Style           =   2
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "poly"
            Object.ToolTipText     =   "Select Polygons"
            ImageIndex      =   5
            Style           =   2
         EndProperty
         BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "elem"
            Object.ToolTipText     =   "Select Elements"
            ImageIndex      =   6
            Style           =   2
         EndProperty
         BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "flatten"
            Object.ToolTipText     =   "Flatten Normals"
            ImageIndex      =   19
         EndProperty
         BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "weld"
            Object.ToolTipText     =   "Weld Normals"
            ImageIndex      =   18
         EndProperty
         BeginProperty Button13 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button14 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "facedel"
            Object.ToolTipText     =   "Delete Faces"
            ImageIndex      =   16
         EndProperty
         BeginProperty Button15 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "collapse"
            Object.ToolTipText     =   "Collapse Vertices"
            ImageIndex      =   17
         EndProperty
         BeginProperty Button16 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button17 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "transform"
            Object.ToolTipText     =   "Transform"
            ImageIndex      =   11
         EndProperty
         BeginProperty Button18 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "fix"
            Object.ToolTipText     =   "Fix Tools"
            ImageIndex      =   10
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.ImageList imlToolbar 
      Left            =   1920
      Top             =   3240
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16711935
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   24
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3544
            Key             =   "openfile"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":36DE
            Key             =   "savefile"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":37F0
            Key             =   "edituv"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3956
            Key             =   "editnorm"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3B44
            Key             =   "editmat"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3CFE
            Key             =   "skinedit"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":4050
            Key             =   ""
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":43A2
            Key             =   ""
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":46F4
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":4A46
            Key             =   ""
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":4D98
            Key             =   ""
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":4F02
            Key             =   ""
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":5254
            Key             =   ""
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":55A6
            Key             =   ""
         EndProperty
         BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":58F8
            Key             =   ""
         EndProperty
         BeginProperty ListImage16 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":5C4A
            Key             =   ""
         EndProperty
         BeginProperty ListImage17 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":5F9C
            Key             =   ""
         EndProperty
         BeginProperty ListImage18 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":62EE
            Key             =   ""
         EndProperty
         BeginProperty ListImage19 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":6640
            Key             =   ""
         EndProperty
         BeginProperty ListImage20 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":6992
            Key             =   ""
         EndProperty
         BeginProperty ListImage21 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":6CE4
            Key             =   ""
         EndProperty
         BeginProperty ListImage22 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":7036
            Key             =   ""
         EndProperty
         BeginProperty ListImage23 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":71B0
            Key             =   ""
         EndProperty
         BeginProperty ListImage24 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":7502
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Timer tmrMeshAnim 
      Enabled         =   0   'False
      Left            =   9360
      Top             =   4680
   End
   Begin VB.Timer tmrTime 
      Enabled         =   0   'False
      Left            =   8520
      Top             =   4560
   End
   Begin MSComctlLib.ImageList imlAnim 
      Left            =   1320
      Top             =   4680
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16711935
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   5
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":7678
            Key             =   "rewind"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":79CA
            Key             =   "end"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":7D1C
            Key             =   "pause"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":806E
            Key             =   "stop"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":83C0
            Key             =   "play"
         EndProperty
      EndProperty
   End
   Begin VB.PictureBox picAnim 
      BorderStyle     =   0  'None
      HasDC           =   0   'False
      Height          =   495
      Left            =   1440
      ScaleHeight     =   33
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   697
      TabIndex        =   6
      Top             =   6960
      Width           =   10455
      Begin VB.PictureBox picTime 
         BackColor       =   &H00FFFFFF&
         BorderStyle     =   0  'None
         FillStyle       =   0  'Solid
         Height          =   300
         Left            =   1800
         ScaleHeight     =   20
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   441
         TabIndex        =   8
         Top             =   0
         Width           =   6615
      End
      Begin MSComctlLib.Toolbar tlbAnim 
         Height          =   330
         Left            =   0
         TabIndex        =   7
         Top             =   0
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   582
         ButtonWidth     =   609
         ButtonHeight    =   582
         ToolTips        =   0   'False
         AllowCustomize  =   0   'False
         Style           =   1
         ImageList       =   "imlAnim"
         _Version        =   393216
         BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
            NumButtons      =   4
            BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "start"
               Object.ToolTipText     =   "To Start"
               ImageIndex      =   1
            EndProperty
            BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "play"
               Object.ToolTipText     =   "Play/Pause"
               ImageIndex      =   5
            EndProperty
            BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "stop"
               Object.ToolTipText     =   "Stop"
               ImageIndex      =   4
            EndProperty
            BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "end"
               Object.ToolTipText     =   "To End"
               ImageIndex      =   2
            EndProperty
         EndProperty
      End
      Begin VB.Label labTime 
         Alignment       =   2  'Center
         Caption         =   "0/0"
         Height          =   255
         Left            =   8640
         TabIndex        =   9
         Top             =   0
         Width           =   690
      End
   End
   Begin VB.TextBox txtConsole 
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Left            =   3600
      TabIndex        =   5
      Top             =   6000
      Visible         =   0   'False
      Width           =   3975
   End
   Begin MSComctlLib.ImageList imlTree 
      Left            =   720
      Top             =   3840
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   13
      ImageHeight     =   13
      MaskColor       =   16711935
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   10
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":8712
            Key             =   "lod"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":889C
            Key             =   "mat"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":8A26
            Key             =   "tex"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":8B68
            Key             =   "geom"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":8CB2
            Key             =   "trinum"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":8E04
            Key             =   "shader"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":8F86
            Key             =   "prop"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":90C0
            Key             =   "texmissing"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":9206
            Key             =   "badlod"
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":937C
            Key             =   "file"
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.TreeView trvMain 
      Height          =   1335
      Left            =   480
      TabIndex        =   4
      Top             =   1080
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   2355
      _Version        =   393217
      HideSelection   =   0   'False
      Indentation     =   0
      LabelEdit       =   1
      LineStyle       =   1
      Style           =   7
      ImageList       =   "imlTree"
      Appearance      =   1
   End
   Begin VB.PictureBox picSamples 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00404040&
      BorderStyle     =   0  'None
      Height          =   1095
      Left            =   12840
      ScaleHeight     =   73
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   97
      TabIndex        =   3
      Top             =   4320
      Visible         =   0   'False
      Width           =   1455
   End
   Begin ComctlLib.StatusBar stsMain 
      Align           =   2  'Align Bottom
      Height          =   285
      Left            =   0
      TabIndex        =   2
      Top             =   9825
      Width           =   15240
      _ExtentX        =   26882
      _ExtentY        =   503
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   6
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            AutoSize        =   1
            Object.Width           =   16722
            TextSave        =   ""
            Key             =   "info"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel2 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Width           =   1323
            MinWidth        =   1323
            TextSave        =   ""
            Key             =   "geom"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel3 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Width           =   1323
            MinWidth        =   1323
            TextSave        =   ""
            Key             =   "lod"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel4 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Width           =   2117
            MinWidth        =   2117
            TextSave        =   ""
            Key             =   "mat"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel5 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Width           =   2117
            MinWidth        =   2117
            TextSave        =   ""
            Key             =   "tri"
            Object.Tag             =   ""
         EndProperty
         BeginProperty Panel6 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Object.Width           =   2646
            MinWidth        =   2646
            TextSave        =   ""
            Key             =   "mem"
            Object.Tag             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.TextBox txtLog 
      BackColor       =   &H80000018&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2775
      Left            =   3120
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      Top             =   2760
      Visible         =   0   'False
      Width           =   3975
   End
   Begin MSComDlg.CommonDialog cdlFile 
      Left            =   7800
      Top             =   3000
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.PictureBox picMain 
      BackColor       =   &H00404040&
      BorderStyle     =   0  'None
      FillStyle       =   0  'Solid
      Height          =   1575
      Left            =   3960
      OLEDropMode     =   2  'Automatic
      ScaleHeight     =   105
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   161
      TabIndex        =   1
      Top             =   960
      Width           =   2415
   End
   Begin MSComctlLib.Toolbar tlbMain 
      Height          =   330
      Left            =   120
      TabIndex        =   10
      Top             =   120
      Width           =   3825
      _ExtentX        =   6747
      _ExtentY        =   582
      ButtonWidth     =   609
      ButtonHeight    =   582
      AllowCustomize  =   0   'False
      Style           =   1
      ImageList       =   "imlToolbar"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   14
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "openfile"
            Object.ToolTipText     =   "Open File..."
            ImageIndex      =   12
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "savefile"
            Object.ToolTipText     =   "Save File"
            ImageIndex      =   14
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "lighting"
            Object.ToolTipText     =   "Lighting"
            ImageIndex      =   21
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "wire"
            Object.ToolTipText     =   "Wireframe"
            ImageIndex      =   18
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "solid"
            Object.ToolTipText     =   "Solid"
            ImageIndex      =   19
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "textured"
            Object.ToolTipText     =   "Textured"
            ImageIndex      =   20
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Object.Visible         =   0   'False
            Key             =   "matedit"
            Object.ToolTipText     =   "Edit Materials"
            ImageIndex      =   5
         EndProperty
         BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "uvedit"
            Object.ToolTipText     =   "UV Editor"
            ImageIndex      =   17
         EndProperty
         BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "skinedit"
            Object.ToolTipText     =   "Skin Editor"
            ImageIndex      =   16
         EndProperty
         BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button13 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "pickmat"
            Object.ToolTipText     =   "Pick material in viewport"
            ImageIndex      =   22
            Style           =   1
         EndProperty
         BeginProperty Button14 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "meshedit"
            Object.ToolTipText     =   "Mesh Editor"
            ImageIndex      =   24
            Style           =   1
         EndProperty
      EndProperty
   End
   Begin VB.Label labProgress 
      AutoSize        =   -1  'True
      Caption         =   "Please wait..."
      Height          =   195
      Left            =   9720
      TabIndex        =   13
      Top             =   960
      Visible         =   0   'False
      Width           =   990
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuFileOpen 
         Caption         =   "Open..."
      End
      Begin VB.Menu mnuFileSave 
         Caption         =   "Save"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuFileSaveAs 
         Caption         =   "Save As..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuFileReload 
         Caption         =   "Reload"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuFileClose 
         Caption         =   "Close"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuFileLine2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileExport 
         Caption         =   "Export..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuFileLine1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileExit 
         Caption         =   "Exit"
      End
   End
   Begin VB.Menu mnuEdit 
      Caption         =   "Edit"
      Begin VB.Menu mnuEditSelectAll 
         Caption         =   "Select All"
      End
      Begin VB.Menu mnuEditSelectNone 
         Caption         =   "Select None"
      End
      Begin VB.Menu mnuEditSelectInvert 
         Caption         =   "Select Invert"
      End
      Begin VB.Menu mnuLine31 
         Caption         =   "-"
      End
      Begin VB.Menu mnuEditSelectBadTangents 
         Caption         =   "Select Bad Tangents"
      End
   End
   Begin VB.Menu mnuView 
      Caption         =   "View"
      Begin VB.Menu mnuViewWireframe 
         Caption         =   "Wireframe"
      End
      Begin VB.Menu mnuViewLighting 
         Caption         =   "Lighting"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewStaticLighting 
         Caption         =   "Static Lighting"
      End
      Begin VB.Menu mnuViewMatCap 
         Caption         =   "MatCap"
      End
      Begin VB.Menu mnuViewGamma 
         Caption         =   "Gamma Correction"
      End
      Begin VB.Menu mnuViewLine2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewTexture 
         Caption         =   "Diffuse Map"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewBumpMap 
         Caption         =   "Normal Map"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewSpecularMap 
         Caption         =   "Specular Map"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewEnvmap 
         Caption         =   "Environment Map"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewLine3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewPolygons 
         Caption         =   "Polygons"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewVertices 
         Caption         =   "Vertices"
      End
      Begin VB.Menu mnuViewEdges 
         Caption         =   "Edges"
      End
      Begin VB.Menu mnuViewNormals 
         Caption         =   "Normals"
      End
      Begin VB.Menu mnuViewTangents 
         Caption         =   "Tangents"
      End
      Begin VB.Menu mnuViewBackfaces 
         Caption         =   "Backfaces"
      End
      Begin VB.Menu mnuViewBounds 
         Caption         =   "Bounding Box"
      End
      Begin VB.Menu mnuViewBonesys 
         Caption         =   "Bone System"
      End
      Begin VB.Menu mnuViewSamples 
         Caption         =   "Samples"
      End
      Begin VB.Menu mnuViewLine1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewAxis 
         Caption         =   "Show Axis"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuViewGrids 
         Caption         =   "Show Grids"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuLine77 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewAnimateMesh 
         Caption         =   "Animate Mesh"
      End
      Begin VB.Menu mnuViewCamAnim 
         Caption         =   "Animate Camera"
      End
      Begin VB.Menu mnuViewLine88 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewMode 
         Caption         =   "Advanced Rendering"
         Begin VB.Menu mnuViewModeNormal 
            Caption         =   "Normal"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnuViewModeVertexOrder 
            Caption         =   "Vertex Order"
         End
         Begin VB.Menu mnuViewModeOverdraw 
            Caption         =   "Triangle Overdraw"
         End
      End
      Begin VB.Menu mnuViewLine5 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewGLSL 
         Caption         =   "GLSL Shaders"
      End
      Begin VB.Menu mnuLine55 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewBakePreview 
         Caption         =   "Texture Bake Preview"
      End
      Begin VB.Menu mnuViewSamplesBitmap 
         Caption         =   "Samples Bitmap"
      End
      Begin VB.Menu mnuViewLog 
         Caption         =   "Debug Console"
      End
   End
   Begin VB.Menu mnuTools 
      Caption         =   "Tools"
      Begin VB.Menu mnuToolsReloadTextures 
         Caption         =   "Reload Textures"
      End
      Begin VB.Menu mnuToolsReloadShaders 
         Caption         =   "Reload Shaders"
      End
      Begin VB.Menu mnuToolsLine2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuToolsRenderLighting 
         Caption         =   "Render Lighting..."
      End
      Begin VB.Menu mnuToolsBakeTexture 
         Caption         =   "Bake Texture..."
      End
      Begin VB.Menu mnuToolsConvertNormalMap 
         Caption         =   "Convert Normal Map..."
      End
      Begin VB.Menu mnuToolsGenSamples 
         Caption         =   "Generate Samples..."
      End
      Begin VB.Menu mnuToolsCopyUV 
         Caption         =   "Copy UV Channels..."
      End
      Begin VB.Menu mnuToolsRenameTextures 
         Caption         =   "Rename Textures..."
      End
      Begin VB.Menu mnuToolsLine1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuToolsWeightedNormals 
         Caption         =   "Generate Weighted Normals"
      End
      Begin VB.Menu mnuToolsMakeWorldSpace 
         Caption         =   "Make Tangents Worldspace"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuToolsVeggieNormals 
         Caption         =   "Compute Veggie Normals"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuToolsFlattenSamples 
         Caption         =   "Flatten Samples"
      End
      Begin VB.Menu mnuToolsFixSamples 
         Caption         =   "Fix Samples"
      End
      Begin VB.Menu mnuToolsVerifyMesh 
         Caption         =   "Fix Mesh"
      End
      Begin VB.Menu mnuToolsFixTangents 
         Caption         =   "Fix Tangents"
      End
      Begin VB.Menu mnuToolsFixTexPaths 
         Caption         =   "Fix Texture Paths"
      End
      Begin VB.Menu mnuToolsFixOGAlpha 
         Caption         =   "Fix Overgrowth Alpha Mode"
      End
      Begin VB.Menu mnuToolsLine3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuToolsUvEditor 
         Caption         =   "UV Editor..."
      End
      Begin VB.Menu mnuToolsSkin 
         Caption         =   "Skin Editor..."
      End
      Begin VB.Menu mnuToolsLine4 
         Caption         =   "-"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewSvnUpdateTex 
         Caption         =   "SVN Update Textures"
         Visible         =   0   'False
      End
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "Options"
      Begin VB.Menu mnuOptionsLoadTextures 
         Caption         =   "Load Textures"
      End
      Begin VB.Menu mnuOptionsLoadSamples 
         Caption         =   "Load Samples"
      End
      Begin VB.Menu mnuOptionsLoadCon 
         Caption         =   "Load Con"
      End
      Begin VB.Menu mnuOptionsLine3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOptionsTexOverride 
         Caption         =   "Load Source Textures (*.tga)"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuOptionsLine13 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOptionsSuffix 
         Caption         =   "Texture Suffix"
         Begin VB.Menu mnuOptionsSuffixNone 
            Caption         =   "None"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnuOptionsSuffixLine1 
            Caption         =   "-"
         End
         Begin VB.Menu mnuOptionsSuffixItem 
            Caption         =   "<should_not_see_me>"
            Index           =   0
            Visible         =   0   'False
         End
      End
      Begin VB.Menu mnuOptionsLine1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOptionsRememberViewSettings 
         Caption         =   "Remember Settings"
      End
      Begin VB.Menu mnuOptionsResetSettings 
         Caption         =   "Reset Settings To Default"
      End
      Begin VB.Menu mnuOptionsLine2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOptionsPreferences 
         Caption         =   "Preferences..."
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "Help"
      Begin VB.Menu mnuHelpOpenglInfo 
         Caption         =   "OpenGL Info..."
      End
      Begin VB.Menu mnuHelpLine1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuHelpAbout 
         Caption         =   "About..."
      End
   End
   Begin VB.Menu mnuTreeContext 
      Caption         =   "Treeview Context Menu"
      Visible         =   0   'False
      Begin VB.Menu mnuTreeContextViewTex 
         Caption         =   "View Texture"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuTreeContextOpenFolder 
         Caption         =   "Open Folder"
      End
      Begin VB.Menu mnuTreeContextSelectFaces 
         Caption         =   "Select Faces"
      End
      Begin VB.Menu mnuTreeContextLine1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuTreeContextEdit 
         Caption         =   "Edit..."
      End
      Begin VB.Menu mnuTreeContextLine2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuTreeContextCopy 
         Caption         =   "Copy"
      End
      Begin VB.Menu mnuTreeContextPaste 
         Caption         =   "Paste"
      End
      Begin VB.Menu mnu 
         Caption         =   "-"
      End
      Begin VB.Menu mnuTreeContextDelete 
         Caption         =   "Delete"
      End
      Begin VB.Menu mnuTreeContextLine3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuTreeContextExpand 
         Caption         =   "Expand All"
      End
      Begin VB.Menu mnuTreeContextCollapse 
         Caption         =   "Collapse All"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public hglrc As Long
Private viewport_w As Long
Private viewport_h As Long

Private restorefrmrender As Boolean
Private restorefrmrenderwinstate As Long

Private restorefrmoutput As Boolean
Private restorefrmoutputwinstate As Long

Private restorefrmuvedit As Boolean
Private restorefrmuveditwinstate As Long

Private restorefrmfix As Boolean
Private restorefrmfixwinstate As Long

Private fps As Long
Private current_file As String
Private current_filterindex As Integer
Private treeview_width As Long
Private splitdrag As Boolean
Private mousex As Single
Private mousey As Single
Private animtime As Single

Private copymatset As Boolean
Private copymat As bf2mat

Public blockdraw As Boolean
Public quitguard As Boolean

Private treemouseup As Boolean
Private treemousebutton As Integer
Private treemousex As Single
Private treemousey As Single

Private dragx As Single 'mouse coordinates at start of drag
Private dragy As Single 'mouse coordinates at start of drag
Private sel_vis As Boolean
Private sel_minx As Single
Private sel_miny As Single
Private sel_maxx As Single
Private sel_maxy As Single

Private fgwindow As Long

Private progress_max As Long
Private progress_cur As Long

Private tooltipfix As Boolean 'mesh editing toolbar tooltip workaround


'form load
Private Sub Form_Load()
    tooltipfix = True
    
    'get window ID
    fgwindow = GetForegroundWindow
    
    'detect if we're running in debugger
    idemode = IsIdeMode()
    
    'deter if we're running in Wine on Linux
    WINE = IsWine()
    'If WINE Then MsgBox "Hello Linux user!"
    
    'fix working directory if running in debugger
    If idemode Then
        app_path = App.path & "\.."
        ChDrive app_path
        ChDir app_path
    Else
        app_path = App.path
    End If
    
    'do not redraw viewport yet
    blockdraw = True
    
    'setup opengl
    Dim pfd As PIXELFORMATDESCRIPTOR
    Dim fmt As Long
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 32
    pfd.cDepthBits = 16
    pfd.cRedBits = 8
    pfd.cGreenBits = 8
    pfd.cBlueBits = 8
    pfd.cAlphaBits = 8
    pfd.cStencilBits = 8
    pfd.iLayerType = PFD_MAIN_PLANE
    fmt = ChoosePixelFormat(Me.picMain.hDC, pfd)
    If fmt = 0 Then
        MsgBox "OpenGL initalization failed.", vbCritical
        Exit Sub
    End If
    fmt = SetPixelFormat(Me.picMain.hDC, fmt, pfd)
    hglrc = wglCreateContext(Me.picMain.hDC)
    wglMakeCurrent Me.picMain.hDC, hglrc
    
    'init extensions
    glextInit
    
    'get max anisotropy value
    glGetFloatv GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, maxaniso
    
    'default states
    glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
    glLightModeli GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE
    'glEnable GL_NORMALIZE 'don't enable, allows us to see normal defects in models!
    
    'detect error reporting driver optimization
    'glBegin GL_TRIANGLES
    '    glBindTexture GL_TEXTURE_2D, tex
    'glEnd
    'Dim gr As GLenum
    'gr = glGetError
    'Me.stsMain.SimpleText = gr
    
    'init glew
    'If glewInit = GLEW_OK Then
    '    'MsgBox "glew ok"
    '    'glMultiTexCoord2f GL_TEXTURE0, 0, 0
    'End If
    
    'lighting
    Dim amb(3) As GLfloat
    'glLightModeli GL_LIGHT_MODEL_LOCAL_VIEWER, 1
    glLightModelfv GL_LIGHT_MODEL_Ambient, amb(0)
    glEnable GL_LIGHT0
    glEnable GL_COLOR_MATERIAL
    
    'generate random color table
    GenColorTable
    
    'form settings
    treeview_width = 300
    
    'default camera rotation
    camrotx = 10
    camroty = -30
    camzoom = 10
    
    toolmode = 0
    
    'clean up
    CloseFile
    current_folder = app_path
    current_filterindex = 17
    
    'set config filename
    app_configfile = app_path & "\config.ini"
    
    'default config
    LoadDefaultConfig
    
    'load config file
    LoadConfig app_configfile
    
    'load shaders
    If opt_useglsl Then
        LoadShaders
    End If
    GenDummyTexColor
    GenDummyTexBump
    
    'synchronize menu
    SyncMenu
    FillSuffixMenu
    
    'install window message hook
    If Not idemode Then
        Hook Me.hWnd
        DisableTreeViewToolTips Me.trvMain.hWnd
    End If
    
    'maximize
    If opt_runmaximized Then
        Me.WindowState = vbMaximized
    End If
    
    'timer
    Me.tmrMeshAnim.Interval = 1000 / 60
    Me.tmrTime.Interval = 1000 / 60
    SetTime 0
    
    'show form
    Me.Show
    
    'redraw to clear viewport and show grid
    blockdraw = False
    picMain_Paint
    blockdraw = True
    
    'command line
    Dim cmd As String
    cmd = Replace(Command$(), Chr(34), "")
    If Len(cmd) Then
        OpenFile cmd
        ZoomExtends
    End If
    
    'fix for Win7
    blockdraw = False
    picMain_Paint
    
    'workaround for tooltip bug
    tooltipfix = False
    Me.tlbMesh.Visible = False
    
    'conformance test
    If opt_conformancetest Then
        RunConformanceTest
        opt_conformancetest = False
    End If
End Sub


'form unload
Private Sub Form_Unload(Cancel As Integer)
    
    If quitguard Then
        Cancel = True
        Exit Sub
    End If
    
    CloseFile
    
    SaveConfig app_configfile
    
    app_exit = True
    
    Unload frmRender
    Unload frmOutput
    Unload frmUvEdit
    Unload frmTransform
    Unload frmSkin
    Unload frmFix
    
    If opt_useglsl Then
        UnloadShaders
    End If
    
    If hglrc Then
        wglMakeCurrent 0, 0
        wglDeleteContext hglrc
        hglrc = 0
    End If
    If Not idemode Then
        UnHook
    End If
    
End Sub


'updates menu checkboxes
Public Sub SyncMenu()
    frmMain.mnuViewWireframe.Checked = view_wire
    frmMain.mnuViewLighting.Checked = view_lighting
    frmMain.mnuViewStaticLighting.Checked = view_staticlight
    frmMain.mnuViewGamma.Checked = view_gamma
    
    frmMain.mnuViewTexture.Checked = view_textures
    frmMain.mnuViewBumpMap.Checked = view_bumpmap
    frmMain.mnuViewSpecularMap.Checked = view_specmap
    frmMain.mnuViewEnvmap.Checked = view_envmap
    
    frmMain.mnuViewPolygons.Checked = view_poly
    frmMain.mnuViewVertices.Checked = view_verts
    frmMain.mnuViewEdges.Checked = view_edges
    frmMain.mnuViewNormals.Checked = view_normals
    frmMain.mnuViewTangents.Checked = view_tangents
    frmMain.mnuViewBackfaces.Checked = view_backfaces
    frmMain.mnuViewBounds.Checked = view_bounds
    frmMain.mnuViewBonesys.Checked = view_bonesys
    frmMain.mnuViewSamples.Checked = view_samples
    
    frmMain.mnuViewAxis.Checked = view_axis
    frmMain.mnuViewGrids.Checked = view_grids
    frmMain.mnuViewGLSL.Checked = opt_useglsl
    
    frmMain.mnuOptionsLoadTextures.Checked = opt_loadtextures
    frmMain.mnuOptionsLoadSamples.Checked = opt_loadsamples
    frmMain.mnuOptionsLoadCon.Checked = opt_loadcon
    frmMain.mnuOptionsRememberViewSettings.Checked = opt_loadviewsettings
    frmMain.mnuOptionsTexOverride.Checked = opt_texoverride
End Sub


'set whether windows are topmost
Public Sub MakeWindowsTopMost(ByVal b As Boolean)
    If frmTransform.Visible Then SetTopMostWindow frmTransform.hWnd, b
    If frmUvEdit.Visible Then SetTopMostWindow frmUvEdit.hWnd, b
    If frmSkin.Visible Then SetTopMostWindow frmSkin.hWnd, b
    If frmFix.Visible Then SetTopMostWindow frmFix.hWnd, b
End Sub


'received focus event
Public Sub GotFocus()
    MakeWindowsTopMost True
End Sub

'lost focus event
Public Sub LostFocus()
    MakeWindowsTopMost False
End Sub


'form resize
Public Sub Form_Resize()
'On Error GoTo errorhandler
    
    If Me.WindowState = vbMinimized Then
        
        'hide windows
        If frmRender.Visible Then
            frmRender.Visible = False
            restorefrmrender = True
            restorefrmrenderwinstate = frmRender.WindowState
        End If
        If frmOutput.Visible Then
            frmOutput.Visible = False
            restorefrmoutput = True
            restorefrmoutputwinstate = frmOutput.WindowState
        End If
        If frmUvEdit.Visible Then
            frmUvEdit.Visible = False
            restorefrmuvedit = True
            restorefrmuveditwinstate = frmUvEdit.WindowState
        End If
        If frmFix.Visible Then
            frmFix.Visible = False
            restorefrmfix = True
            restorefrmfixwinstate = frmFix.WindowState
        End If
        
    Else
        
        'restore windows
        If restorefrmrender Then
            frmRender.Visible = True
            DoEvents
            frmRender.WindowState = restorefrmrenderwinstate
            restorefrmrender = False
        End If
        If restorefrmoutput Then
            frmOutput.Visible = True
            DoEvents
            frmOutput.WindowState = restorefrmoutputwinstate
            restorefrmoutput = False
        End If
        If restorefrmuvedit Then
            frmUvEdit.Visible = True
            DoEvents
            frmUvEdit.WindowState = restorefrmuveditwinstate
            restorefrmuvedit = False
        End If
        If restorefrmfix Then
            frmFix.Visible = True
            DoEvents
            frmFix.WindowState = restorefrmfixwinstate
            restorefrmfix = False
        End If
        
        If idemode Then
            If Me.width < 400 * 15 Then Me.width = 400 * 15
            If Me.height < 300 * 15 Then Me.height = 300 * 15
        End If
        
        Me.tlbMain.Move 2, 0
        If tooltipfix Then
            Me.tlbMesh.Move 0, -100 'move off-screen to hide it, while still being 'visible'
        Else
            Me.tlbMesh.Move Me.tlbMain.Left + Me.tlbMain.width, 0
        End If
        
        Dim pgbX As Long
        If Me.tlbMesh.Visible Then
            pgbX = Me.tlbMesh.Left + Me.tlbMesh.width
        Else
            pgbX = Me.tlbMain.Left + Me.tlbMain.width
        End If
        Me.pgbProgress.Move pgbX + 6, 2
        Me.labProgress.Move Me.pgbProgress.Left + Me.pgbProgress.width + 10, 3
        
        Dim yoff As Long
        yoff = 1 + 24 + 1
        
        Dim animHeight As Long
        If picAnim.Visible Then
            Me.picAnim.height = Me.tlbAnim.height
            animHeight = picAnim.height
        End If
        
        If Me.ScaleWidth - 20 < treeview_width Then treeview_width = Me.ScaleWidth - 20
        
        'If Not idemode Then LockWindowUpdate Me.hWnd
        Me.trvMain.Move 2, yoff, treeview_width, Me.ScaleHeight - 3 - Me.stsMain.height - yoff - animHeight
        Me.picMain.Move treeview_width + 7, yoff, Me.ScaleWidth - (treeview_width + 4) - 4, Me.ScaleHeight - 3 - Me.stsMain.height - yoff - animHeight
        Me.picSamples.Move picMain.Left, picMain.top, picMain.width, picMain.height
        
        Me.txtLog.Move treeview_width + 7, yoff, Me.ScaleWidth - (treeview_width + 4) - 4, Me.ScaleHeight - 3 - Me.stsMain.height - yoff - Me.txtConsole.height - 6 - animHeight
        Me.txtConsole.Move treeview_width + 7, yoff + Me.txtLog.height + 3, Me.ScaleWidth - (treeview_width + 4) - 4 - animHeight
        
        Me.picAnim.Move 2, Me.picMain.top + Me.picMain.height + 2, Me.ScaleWidth - 4
        
        'If Not idemode Then LockWindowUpdate 0
        
        Me.Refresh
        
        viewport_w = Me.picMain.ScaleWidth
        viewport_h = Me.picMain.ScaleHeight
        If viewport_w < 1 Then viewport_w = 1
        If viewport_h < 1 Then viewport_h = 1
        picMain_Paint
        
    End If
    Exit Sub
errorhandler:
    'nothing
End Sub


'--- progress bar ---------------------------------------------------------------------------------

'starts progress bar
Public Sub StartProgress(ByVal max As Long, ByVal str As String)
    If progress_max > 0 Then Exit Sub 'already started elsewhere
    progress_max = max
    If progress_max < 2 Then progress_max = 2
    Me.labProgress.Caption = str
    Me.pgbProgress.Visible = True
    Me.labProgress.Visible = True
    Form_Resize 'reposition label+bar
    Me.MousePointer = vbHourglass
    DoEvents
End Sub

'updates progress bar
Public Sub UpdateProgress(ByVal val As Long)
    If val > progress_max Then val = progress_max
    Dim w As Single
    w = (val / progress_max) * 100
    If w = progress_cur Then Exit Sub
    progress_cur = w
    Me.pgbProgress.value = progress_cur
    DoEvents
End Sub

'ends progress bar
Public Sub EndProgress()
    Me.pgbProgress.Visible = False
    Me.labProgress.Visible = False
    Me.MousePointer = vbDefault
    DoEvents
    progress_max = 0
End Sub


'--- form mouse events -----------------------------------------------------------------------------

Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 1 Then
        If SplitHover(X, Y) Then
            splitdrag = True
        End If
    End If
    mousex = X
    mousey = Y
End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If splitdrag Then
        treeview_width = treeview_width + (X - mousex)
        treeview_width = Clamp(treeview_width, 20, 3 * (Me.ScaleWidth / 4))
        Form_Resize
    End If
    
    'hover
    If SplitHover(X, Y) Then
        Me.MousePointer = vbSizeWE
    Else
        Me.MousePointer = vbDefault
    End If
    
    mousex = X
    mousey = Y
End Sub

Private Sub Form_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    splitdrag = False
End Sub


'hover event over tree/viewport splitter
Private Function SplitHover(ByVal X As Single, ByVal Y As Single) As Boolean
Dim minx As Single
Dim maxx As Single
    minx = Me.trvMain.Left + Me.trvMain.width
    maxx = Me.picMain.Left

Dim miny As Single
Dim maxy As Single
    miny = 0
    maxy = Me.ScaleHeight - Me.stsMain.height
    
    If X > minx And X < maxx Then
        If Y > 0 And Y < maxy Then
            SplitHover = True
        End If
    End If
End Function


'--- viewport paint event -------------------------------------------------------------------------------------

'picMain paint event
Public Sub picMain_Paint()
    If blockdraw Then Exit Sub
    If lmrender Then Exit Sub
    If hglrc = 0 Then Exit Sub
    
    If viewport_w = 0 Then Exit Sub
    If viewport_h = 0 Then Exit Sub
    
    wglMakeCurrent Me.picMain.hDC, hglrc
    
    glViewport 0, 0, viewport_w, viewport_h
    camasp = viewport_w / viewport_h
    
    'draw scene
    DrawScene
    
    'prepare for 2d stuff
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    glOrtho 0, viewport_w, viewport_h, 0, -1, 1
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    
    glDisable GL_DEPTH_TEST
    glPolygonMode GL_FRONT_AND_BACK, GL_FILL
    
    'draw selection rectangle
    If sel_vis And ((sel_maxx - sel_minx) > 4 Or (sel_maxy - sel_miny) > 4) Then
        glBlendFunc GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA
        glEnable GL_BLEND
        glColor4f 1, 1, 1, 0.1
        glBegin GL_QUADS
            glVertex2f sel_minx + 1, sel_miny + 1
            glVertex2f sel_minx + 1, sel_maxy - 0
            glVertex2f sel_maxx - 0, sel_maxy - 0
            glVertex2f sel_maxx - 0, sel_miny + 1
        glEnd
        
        glLineWidth 1
        glColor4f 1, 1, 1, 0.333
        glBegin GL_LINE_STRIP
            glVertex2f sel_minx + 0.5, sel_miny + 0.5
            glVertex2f sel_minx + 0.5, sel_maxy + 0.5
            glVertex2f sel_maxx + 0.5, sel_maxy + 0.5
            glVertex2f sel_maxx + 0.5, sel_miny + 0.5
            glVertex2f sel_minx + 0.5, sel_miny + 0.5
        glEnd
        glDisable GL_BLEND
    End If
    
    'TEMP: draw screen projected vertices
    If False Then
        With vmesh
            If .loadok Then
                Dim i As Long
                glPointSize 8
                
                glBegin GL_POINTS
                For i = 0 To .vertnum - 1
                    If .vertinfo(i).sv.z > 0 Then
                        glColor3f .vertinfo(i).sv.z, .vertinfo(i).sv.z, .vertinfo(i).sv.z
                    Else
                        glColor3f 0, 0, 1
                    End If
                    glVertex2fv .vertinfo(i).sv.X
                Next i
                glEnd
            End If
        End With
    End If
    
    'TEMP: draw mouse hit position
    If False Then
        glPointSize 8
        glColor3f 0.25, 0.75, 1
        glBegin GL_POINTS
            glVertex2fv mouse_hitpos2d.X
        glEnd
    End If
    
    'flip buffers
    glFinish
    SwapBuffers Me.picMain.hDC
    
    'draw GDI stuff
    If opt_useGDI Then
        BF2DrawColInfo
    End If
    
End Sub


'--- keyboard input -------------------------------------------------------------------------------


'forward picMain key input to form
Private Sub picMain_KeyDown(KeyCode As Integer, Shift As Integer)
    Form_KeyDown KeyCode, Shift
End Sub
Private Sub picMain_KeyUp(KeyCode As Integer, Shift As Integer)
    Form_KeyUp KeyCode, Shift
End Sub


'form key down event
Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    Select Case KeyCode
    Case vbKeyLeft
        fooz = fooz - 1
        Me.Caption = fooz
        picMain_Paint
    Case vbKeyRight
        fooz = fooz + 1
        Me.Caption = fooz
        picMain_Paint
    Case vbKeySpace
        ZoomExtends
        picMain_Paint
    Case vbKeyF10:
        ReloadEnvMap
        SetStatus "info", "EnvMap reloaded..."
        picMain_Paint
    Case vbKeyF11
        Dim i As Long
        Dim s As Single
        Dim off As Single
        s = InputBox("Scale:", "Rescale", 1)
        If s > 0 And s <> 1 Then
            With vmesh
                For i = 0 To .vertnum - 1
                    off = i * .stride
                    .vert(off + 0) = .vert(off + 0) * s
                    .vert(off + 1) = .vert(off + 1) * s
                    .vert(off + 2) = .vert(off + 2) * s
                Next i
            End With
        End If
        picMain_Paint
    Case vbKeyF12
        Screendump
    Case vbKeyControl:  keyctrl = True
    Case vbKeyMenu:     keyalt = True
    Case vbKeyShift:    keyshift = True
    Case vbKeyAdd, vbKeyW:
        zoom 0.5
        picMain_Paint
    Case vbKeySubtract, vbKeyS:
        zoom -0.5
        picMain_Paint
    
    End Select
End Sub

'form key up event
Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
    Select Case KeyCode
    Case vbKeyControl: keyctrl = False
    Case vbKeyMenu:    keyalt = False
    Case vbKeyShift:   keyshift = False
    End Select
End Sub

'writes screenshot to file
Private Sub Screendump()
    'get frame buffer size
    Dim w As Long
    Dim h As Long
    w = picMain.width
    h = picMain.height
    
    'commpute image size
    Dim sz As Long
    sz = w * h * 4
    
    'allocate buffer
    'ReDim buffer(0 To sz - 1) As Byte
    ReDim buffer(0 To (w * h) - 1) As bgra
    
    'readback
    glReadPixels 0, 0, w, h, GL_BGRA, GL_UNSIGNED_BYTE, ByVal VarPtr(buffer(0))
    
    'output
    Dim fname As String
    fname = format(Now, "yyyy-MM-dd hh_mm_ss.tga")
    WriteTGA32 fname, w, h, buffer
    
    'clean up
    Erase buffer()
End Sub


'--- mouse input -----------------------------------------------------------------------------


'mouse button down event
Private Sub picMain_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    mouse_down = True
    mouse_px = X
    mouse_py = Y
    
    dragx = X
    dragy = Y
End Sub


'mouse move event
Private Sub picMain_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If mouse_down Then
        If Button = vbLeftButton Then
            If pickmatmode Then
                'nothing
            ElseIf (toolmode = 1 And Not keyshift) Then
                sel_vis = True
                sel_minx = min(dragx, X)
                sel_miny = min(dragy, Y)
                sel_maxx = max(dragx, X)
                sel_maxy = max(dragy, Y)
            Else
                camrotx = camrotx + ((Y - mouse_py) * 0.5)
                camroty = camroty + ((X - mouse_px) * 0.5)
            End If
        End If
        If Button = vbRightButton Then
            If pickmatmode Then
                'nothing
            ElseIf (toolmode = 1 Or Not opt_RMBzoom) Then
                camrotx = camrotx + ((Y - mouse_py) * 0.5)
                camroty = camroty + ((X - mouse_px) * 0.5)
            Else
                zoom ((mouse_py - Y) * 0.1)
            End If
        End If
        If Button = vbMiddleButton Then
            Pan ((X - mouse_px) * 0.01), ((Y - mouse_py) * 0.01)
        End If
        picMain_Paint
    End If
    
    Me.MousePointer = vbDefault
    mouse_px = X
    mouse_py = Y
End Sub


'mouse button up event
Private Sub picMain_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    
    'ignore MouseUp after minimizing/maximizing window
    If Not mouse_down Then Exit Sub
    
    If Button = vbLeftButton Then
        If pickmatmode Then
            PickFaceMat X, Y
        ElseIf (toolmode = 1 And Not keyshift) Then
            If sel_vis And ((sel_maxx - sel_minx) > 4 Or (sel_maxy - sel_miny) > 4) Then
                If selmode = sel_vert Then BF2SelectVerts sel_minx, sel_miny, sel_maxx, sel_maxy
                If selmode = sel_face Then BF2SelectFaces sel_minx, sel_miny, sel_maxx, sel_maxy
                If selmode = sel_poly Then BF2SelectPolys sel_minx, sel_miny, sel_maxx, sel_maxy
                If selmode = sel_elem Then BF2SelectElems sel_minx, sel_miny, sel_maxx, sel_maxy
            Else
                If selmode = sel_vert Then BF2SelectVerts (X - 3), (Y - 3), (X + 3), (Y + 3)
                If selmode = sel_face Then BF2SelectFace X, Y
                If selmode = sel_poly Then BF2SelectPoly X, Y
                If selmode = sel_elem Then BF2SelectElem X, Y
            End If
            sel_vis = False
            frmSkin.SelectionChanged
            frmUvEdit.UpdateSelBox
            RedrawViewports
        End If
    End If
    
    mouse_down = False
End Sub


'mouse wheel event
Public Sub MouseWheel(ByVal MouseKeys As Long, ByVal value As Long, ByVal X As Long, ByVal Y As Long)
    zoom value
    picMain_Paint
End Sub


'--- misc -----------------------------------------------------------------------------------------------

'viewport pan
Private Sub Pan(ByVal X As Single, ByVal Y As Single)
    campanx = campanx + ((X * 0.1) * camzoom)
    campany = campany - ((Y * 0.1) * camzoom)
End Sub


'viewport zoom
Private Sub zoom(ByVal v As Single)
    camzoom = camzoom - (v * camzoom * 0.1)
    If camzoom < 0.001 Then camzoom = 0.001
End Sub


'select material by face clicked in viewport
Private Sub PickFaceMat(ByVal X As Single, ByVal Y As Single)
    'end picking mode
    pickmatmode = False
    Me.tlbMain.Buttons("pickmat").value = tbrUnpressed
    
    'no bf2 mesh loaded
    If Not vmesh.loadok Then Exit Sub
    
    'verify selection
    If Not IsValidLod(selgeom, sellod) Then Exit Sub
    
    'pick face
    Dim face As Long
    UpdateMaskFlags
    face = PickFace(X, Y)
    If face = -1 Then Exit Sub
    
    'select material
    With vmesh.faceinfo(face)
        
        'select mesh node
        Dim key As String
        key = MakeKey(.geom, .lod, .mat, -1)
        SelectMesh -1, key
        
        'select tree view node
        Dim i As Long
        For i = 1 To Me.trvMain.Nodes.count
            With Me.trvMain.Nodes.Item(i)
                If .key = key Then
                    .Selected = False
                    .EnsureVisible
                    Me.trvMain.SelectedItem = Me.trvMain.Nodes.Item(i)
                    .Expanded = True
                    Me.trvMain.SetFocus
                End If
            End With
        Next i
        
    End With
End Sub


'--- anim ---------------------------------------------------------------------------------------------------------------

Private Sub picAnim_Resize()
    If Me.WindowState = vbMinimized Then Exit Sub
    
    picTime.Move Me.tlbAnim.width + 2, 2, picAnim.ScaleWidth - tlbAnim.width - labTime.width - 6, 18
    
    labTime.top = 4
    labTime.Left = picAnim.ScaleWidth - labTime.width
    
    picTime_Paint
End Sub

Private Sub picTime_Paint()
    Dim w As Long
    Dim h As Long
    Dim wt As Long
    
    w = picTime.width
    h = picTime.height
    
    'slider position
    wt = (w - 2) * animtime
    
    'white background
    picTime.FillColor = RGB(255, 255, 255)
    picTime.ForeColor = RGB(127, 127, 127)
    DrawRect picTime.hDC, 0, 0, w, h
    
    'time
    If wt > 0 Then
        picTime.FillColor = RGB(200, 200, 200)
        picTime.ForeColor = RGB(200, 200, 200)
        DrawRect picTime.hDC, 1, 1, wt + 1, h - 1
        
        ''picTime.FillColor = RGB(140, 214, 213)
        ''picTime.ForeColor = RGB(140, 214, 213)
        'DrawRect picTime.hDC, 1, 1, wt + 1, (h / 2)
        
        'picTime.FillColor = RGB(41, 165, 173)
        'picTime.ForeColor = RGB(41, 165, 173)
        'DrawRect picTime.hDC, 1, (h / 2), wt + 1, h - 1
    End If
    
    'draw slider
    picTime.FillColor = RGB(200, 63, 63)
    picTime.ForeColor = RGB(200, 63, 63)
    DrawRect picTime.hDC, wt + 1 - 2, 0, wt + 1 + 2, h
    
End Sub

Public Sub SetTime(ByVal t As Single, Optional redraw As Boolean = True)
    animtime = t
    If animtime < 0 Then animtime = 0
    If animtime > 1 Then animtime = 1
    
    Dim frame As Long
    If bf2baf.loaded Then
        frame = (bf2baf.framenum - 1) * animtime
        Me.labTime = (frame + 1) & "/" & bf2baf.framenum
        Me.labTime.Refresh
        
        DeformBF2Skeleton bf2baf, frame
    End If
    
    picTime_Paint
    If redraw Then
        picMain_Paint
    End If
End Sub

Private Sub picTime_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    picTime_MouseMove Button, Shift, X, Y
End Sub

Private Sub picTime_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button Then
        Dim w  As Single
        w = (picTime.width - 2)
        If w = 0 Then Exit Sub
        Dim val As Single
        val = (X - 1) / w
        If val < 0 Then val = 0
        If val > 1 Then val = 1
        SetTime val
    End If
End Sub

Private Sub tmrMeshAnim_Timer()
    timephase = timephase + (1 / 60)
    picMain_Paint
End Sub

Private Sub tmrTime_Timer()
    Dim frames As Single
    frames = 100
    If bf2baf.loaded Then frames = bf2baf.framenum
    
    Dim t As Single
    t = animtime + (1 / 60) * ((1 / CSng(frames)) * 30)
    
    'repeat
    If t > 1 Then t = 0
    
    SetTime t
End Sub

Private Sub tlbAnim_ButtonClick(ByVal Button As MSComctlLib.Button)
    Select Case Button.key
    Case "start"
        SetTime 0
    Case "end"
        SetTime 1
    Case "play"
        tmrTime.enabled = Not tmrTime.enabled
        If tmrTime.enabled Then
            Button.Image = "pause"
        Else
            Button.Image = "play"
        End If
    Case "stop"
        tlbAnim.Buttons("play").Image = "play"
        SetTime 0, False
        tmrTime.enabled = False
        ResetBF2Skeleton
        BF2MeshDeformSM
        frmMain.picMain_Paint
    End Select
End Sub

'--- menu ---------------------------------------------------------------------------------------------------------------

Private Sub mnuFileOpen_Click()
    With Me.cdlFile
        .DialogTitle = "Open File"
        .Filter = "Static Mesh (*.staticmesh)|*.staticmesh|" & _
                  "Bundled Mesh (*.bundledmesh)|*.bundledmesh|" & _
                  "Skin Mesh (*.skinnedmesh)|*.skinnedmesh|" & _
                  "Collision Mesh (*.collisionmesh)|*.collisionmesh|" & _
                  "BF2 Animation (*.baf)|*.baf|" & _
                  "Skeleton (*.ske)|*.ske|" & _
                  "Occluder (*.occ)|*.occ|" & _
                  "Samples (*.samp*)|*.samp*|" & _
                  "Standard Mesh (*.sm)|*.sm|" & _
                  "Tree Mesh (*.tm)|*.tm|" & _
                  "Wavefront OBJ (*.obj)|*.obj|" & _
                  "FrostBite Mesh (*.res)|*.res|" & _
                  "FHX Geometry (*.geo)|*.geo|" & _
                  "FHX Trimesh (*.tri)|*.tri|" & _
                  "FHX Rig (*.rig)|*.rig|" & _
                  "BfMeshView Workspace (*.bfmv)|*.bfmv|" & _
                  "All Files (*.*)|*.*"
        .FilterIndex = current_filterindex
        .flags = cdlOFNExplorer Or cdlOFNFileMustExist
        .InitDir = current_folder
        .CancelError = True
        On Error Resume Next
        .ShowOpen
        If Not err.Number = cdlCancel Then
            On Error GoTo 0
            
            current_filterindex = .FilterIndex
            OpenFile .filename
        End If
    End With
End Sub

Public Sub mnuFileSave_Click()
    Dim sure As Boolean
    If pro_mode Then
        sure = True
    Else
        sure = MsgBox("Are you sure you want to overwrite this file?", vbExclamation Or vbYesNoCancel) = vbYes
    End If
    If sure Then
        If wspace.loaded Then
            If vmesh.loadok Then
                SaveMeshFile wspace.fname_mesh
                SetStatus "info", "Saved."
            End If
        Else
            SaveFile current_file
        End If
    End If
End Sub

Private Sub mnuFileSaveAs_Click()
    With Me.cdlFile
        .DialogTitle = "Save File"
        .Filter = "Static Mesh (*.staticmesh)|*.staticmesh|" & _
                  "Bundled Mesh (*.bundledmesh)|*.bundledmesh|" & _
                  "Skin Mesh (*.skinnedmesh)|*.skinnedmesh|" & _
                  "Samples (*.samp*)|*.samp*|" & _
                  "All Files (*.*)|*.*"
        .flags = cdlOFNOverwritePrompt Or cdlOFNNoReadOnlyReturn
        .InitDir = current_folder
        .CancelError = True
        
        If vmesh.loadok Then
            .filename = GetNameFromFileName(vmesh.filename)
            If vmesh.isBundledMesh Then
                .FilterIndex = 2
            ElseIf vmesh.isSkinnedMesh Then
                .FilterIndex = 3
            Else
                .FilterIndex = 1
            End If
        Else
            .filename = GetFilenameFromPath(bf2samples(0).filename)
            .FilterIndex = 4
        End If
        
        On Error Resume Next
        .ShowSave
        If Not err.Number = cdlCancel Then
            On Error GoTo 0
            
            SaveFile .filename
        End If
    End With
End Sub

Private Sub mnuFileReload_Click()
Dim oldfile As String
    oldfile = current_file
    
    CloseFile
    OpenFile oldfile
End Sub

Private Sub mnuFileClose_Click()
    CloseFile
End Sub

Private Sub mnuFileExport_Click()
    With Me.cdlFile
        .DialogTitle = "Export File"
        .Filter = "Wavefront OBJ (*.obj)|*.obj"
        .FilterIndex = 1
        .flags = cdlOFNOverwritePrompt Or cdlOFNNoReadOnlyReturn
        .InitDir = current_folder
        .CancelError = True
        .filename = GetNameFromFileName(vmesh.filename)
        On Error Resume Next
        .ShowSave
        If Not err.Number = cdlCancel Then
            On Error GoTo 0
            
            frmExportOBJ.Export .filename
        End If
    End With
End Sub

Private Sub mnuFileExit_Click()
    Unload Me
End Sub

Private Sub mnuEditSelectAll_Click()
    SelectAll
    picMain_Paint
End Sub

Private Sub mnuEditSelectNone_Click()
    ClearSelection
    picMain_Paint
End Sub

Private Sub mnuEditSelectInvert_Click()
    SelectInvert
    picMain_Paint
End Sub

Private Sub mnuEditSelectBadTangents_Click()
    SelectBadTangents
    picMain_Paint
End Sub

Private Sub mnuViewWireframe_Click()
    view_wire = Not view_wire
    mnuViewWireframe.Checked = view_wire
    picMain_Paint
End Sub

Private Sub mnuViewLighting_Click()
    view_lighting = Not view_lighting
    mnuViewLighting.Checked = view_lighting
    picMain_Paint
End Sub

Private Sub mnuViewStaticLighting_Click()
    view_staticlight = Not view_staticlight
    mnuViewStaticLighting.Checked = view_staticlight
    picMain_Paint
End Sub

Private Sub mnuViewMatCap_Click()
    view_matcap = Not view_matcap
    mnuViewMatCap.Checked = view_matcap
    picMain_Paint
End Sub

Private Sub mnuViewGamma_Click()
    view_gamma = Not view_gamma
    mnuViewGamma.Checked = view_gamma
    picMain_Paint
End Sub

Private Sub mnuViewTexture_Click()
    view_textures = Not view_textures
    mnuViewTexture.Checked = view_textures
    picMain_Paint
End Sub

Private Sub mnuViewBumpMap_Click()
    view_bumpmap = Not view_bumpmap
    mnuViewBumpMap.Checked = view_bumpmap
    picMain_Paint
End Sub

Private Sub mnuViewSpecularMap_Click()
    view_specmap = Not view_specmap
    mnuViewSpecularMap.Checked = view_specmap
    picMain_Paint
End Sub

Private Sub mnuViewEnvmap_Click()
    view_envmap = Not view_envmap
    mnuViewEnvmap.Checked = view_envmap
    picMain_Paint
End Sub

Private Sub mnuViewPolygons_Click()
    view_poly = Not view_poly
    mnuViewPolygons.Checked = view_poly
    picMain_Paint
End Sub

Private Sub mnuViewVertices_Click()
    view_verts = Not view_verts
    mnuViewVertices.Checked = view_verts
    picMain_Paint
End Sub

Public Sub mnuViewEdges_Click()
    view_edges = Not view_edges
    mnuViewEdges.Checked = view_edges
    picMain_Paint
End Sub

Private Sub mnuViewNormals_Click()
    view_normals = Not view_normals
    mnuViewNormals.Checked = view_normals
    picMain_Paint
End Sub

Private Sub mnuViewBackfaces_Click()
    view_backfaces = Not view_backfaces
    mnuViewBackfaces.Checked = view_backfaces
    picMain_Paint
End Sub

Private Sub mnuViewTangents_Click()
    view_tangents = Not view_tangents
    mnuViewTangents.Checked = view_tangents
    picMain_Paint
End Sub

Private Sub mnuViewBounds_Click()
    view_bounds = Not view_bounds
    mnuViewBounds.Checked = view_bounds
    picMain_Paint
End Sub

Private Sub mnuViewBonesys_Click()
    view_bonesys = Not view_bonesys
    mnuViewBonesys.Checked = view_bonesys
    picMain_Paint
End Sub

Private Sub mnuViewSamples_Click()
    view_samples = Not view_samples
    mnuViewSamples.Checked = view_samples
    picMain_Paint
End Sub

Private Sub mnuViewAxis_Click()
    view_axis = Not view_axis
    mnuViewAxis.Checked = view_axis
    picMain_Paint
End Sub

Private Sub mnuViewGrids_Click()
    view_grids = Not view_grids
    mnuViewGrids.Checked = view_grids
    picMain_Paint
End Sub

Private Sub mnuViewAnimateMesh_Click()
    tmrMeshAnim.enabled = Not tmrMeshAnim.enabled
    mnuViewAnimateMesh.Checked = tmrMeshAnim.enabled
    If tmrMeshAnim.enabled Then timephase = 0
End Sub

Private Sub mnuViewCamAnim_Click()
    view_camanim = Not view_camanim
    mnuViewCamAnim.Checked = view_camanim
    picMain_Paint
End Sub

Private Sub mnuViewModeNormal_Click()
    draw_mode = dm_normal
    Me.mnuViewModeNormal.Checked = True
    Me.mnuViewModeVertexOrder.Checked = False
    Me.mnuViewModeOverdraw.Checked = False
    picMain_Paint
End Sub

Private Sub mnuViewModeVertexOrder_Click()
    draw_mode = dm_vertorder
    Me.mnuViewModeNormal.Checked = False
    Me.mnuViewModeVertexOrder.Checked = True
    Me.mnuViewModeOverdraw.Checked = False
    picMain_Paint
End Sub

Private Sub mnuViewModeOverdraw_Click()
    draw_mode = dm_overdraw
    Me.mnuViewModeNormal.Checked = False
    Me.mnuViewModeVertexOrder.Checked = False
    Me.mnuViewModeOverdraw.Checked = True
    picMain_Paint
End Sub

Private Sub mnuViewGLSL_Click()
    opt_useglsl = Not opt_useglsl
    Me.mnuViewGLSL.Checked = opt_useglsl
    
    If opt_useglsl Then
        LoadShaders
    Else
        UnloadShaders
    End If
    BuildFFPShaders
    picMain_Paint
End Sub

Private Sub mnuViewBakePreview_Click()
    bakemode = Not bakemode
    Me.mnuViewBakePreview.Checked = bakemode
    picMain_Paint
End Sub

Private Sub mnuViewSamplesBitmap_Click()
    mnuViewSamplesBitmap.Checked = Not mnuViewSamplesBitmap.Checked
    'Me.txtLog.Visible = Not mnuViewSamplesBitmap.Checked
    Me.picMain.Visible = Not mnuViewSamplesBitmap.Checked
    Me.picSamples.Visible = mnuViewSamplesBitmap.Checked
    
    If mnuViewSamplesBitmap.Checked Then
        DrawSamples2d Me.picSamples
    End If
End Sub

Private Sub mnuViewLog_Click()
    mnuViewLog.Checked = Not mnuViewLog.Checked
    Me.txtLog.Visible = mnuViewLog.Checked
    Me.picMain.Visible = Not mnuViewLog.Checked
    'Me.picSamples.Visible = Not mnuViewLog.Checked
    
    Me.txtConsole.Visible = Me.txtLog.Visible
End Sub

Private Sub mnuOptionsLoadTextures_Click()
    opt_loadtextures = Not opt_loadtextures
    mnuOptionsLoadTextures.Checked = opt_loadtextures
End Sub

Private Sub mnuOptionsLoadSamples_Click()
    opt_loadsamples = Not opt_loadsamples
    mnuOptionsLoadSamples.Checked = opt_loadsamples
End Sub

Private Sub mnuOptionsLoadCon_Click()
    opt_loadcon = Not opt_loadcon
    mnuOptionsLoadCon.Checked = opt_loadcon
End Sub

Private Sub mnuOptionsSuffixNone_Click()
    suffix_sel = 0
    mnuOptionsSuffixNone.Checked = True
    Dim i As Long
    For i = 1 To suffixnum
        mnuOptionsSuffixItem.Item(i).Checked = False
    Next i
    mnuToolsReloadTextures_Click
End Sub

Private Sub mnuOptionsTexOverride_Click()
    opt_texoverride = Not opt_texoverride
    mnuOptionsTexOverride.Checked = opt_texoverride
    mnuToolsReloadTextures_Click
End Sub

Private Sub mnuOptionsSuffixItem_Click(index As Integer)
    suffix_sel = index
    mnuOptionsSuffixNone.Checked = False
    Dim i As Long
    For i = 1 To suffixnum
        mnuOptionsSuffixItem.Item(i).Checked = (i = suffix_sel)
    Next i
    mnuToolsReloadTextures_Click
End Sub

Private Sub mnuOptionsRememberViewSettings_Click()
    opt_loadviewsettings = Not opt_loadviewsettings
    mnuOptionsRememberViewSettings.Checked = opt_loadviewsettings
End Sub

Private Sub mnuOptionsResetSettings_Click()
    LoadDefaultConfig
    SyncMenu
    picMain_Paint
End Sub

Private Sub mnuOptionsPreferences_Click()
    frmOptions.Show vbModal
    picMain_Paint
End Sub

Public Sub mnuToolsReloadTextures_Click()
    LoadMeshTextures
    FillTreeView
    picMain_Paint
    SetStatus "info", "Done."
    
    'todo: update icons in treeview
End Sub

Private Sub mnuToolsReloadShaders_Click()
    ReloadShaders
    picMain_Paint
End Sub

Private Sub mnuToolsRenderLighting_Click()
    frmRender.Show 'vbModal
End Sub

Private Sub mnuToolsBakeTexture_Click()
    If Not vmesh.loadok Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    frmBake.Show vbModal
End Sub

Private Sub mnuToolsConvertNormalMap_Click()
    frmNormalMap.Show vbModal
End Sub

Private Sub mnuToolsWeightedNormals_Click()
    If Not vmesh.loadok Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    GenWeightedNormals
    picMain_Paint
End Sub

Private Sub mnuToolsMakeWorldSpace_Click()
    If Not vmesh.loadok Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    VisMeshTool_MakeWS
    picMain_Paint
End Sub

Private Sub mnuToolsVeggieNormals_Click()
    If Not vmesh.loadok Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    VisMeshTool_VeggieNormals
    picMain_Paint
End Sub

Private Sub mnuToolsFlattenSamples_Click()
    Dim i As Long
    Dim n As Long
    For i = 0 To 4
        If FlattenSamples(bf2samples(i)) Then n = n + 1
    Next i
    If n = 0 Then
        MsgBox "No BF2 samples loaded.", vbExclamation
        Exit Sub
    End If
    picMain_Paint
End Sub

Private Sub mnuToolsFixSamples_Click()
    Dim i As Long
    Dim n As Long
    For i = 0 To 4
        If FixSamples(bf2samples(i)) Then n = n + 1
    Next i
    If n = 0 Then
        MsgBox "No BF2 samples loaded.", vbExclamation
        Exit Sub
    End If
    picMain_Paint
End Sub

Private Sub mnuToolsVerifyMesh_Click()
    BF2VerifyMesh
End Sub

Private Sub mnuToolsFixTangents_Click()
    BF2FixTangents
    picMain_Paint
End Sub

Private Sub mnuToolsFixTexPaths_Click()
    BF2MeshFixTexPaths
    picMain_Paint
End Sub

Private Sub mnuToolsFixOGAlpha_Click()
    FixOvergrowthAlpha
    picMain_Paint
End Sub

Private Sub mnuToolsGenSamples_Click()
    If Not vmesh.loadok Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    frmSamples.Show 'vbModal
End Sub

Private Sub mnuToolsCopyUV_Click()
    If Not vmesh.loadok Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    frmCopyUV.Show vbModal
End Sub

Private Sub mnuToolsRenameTextures_Click()
    If Not vmesh.loadok Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    frmTexRename.Show vbModal
End Sub

Private Sub mnuToolsUvEditor_Click()
    If Not vmesh.loadok Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    frmUvEdit.Show
    picMain_Paint
End Sub

Private Sub mnuToolsSkin_Click()
    If Not vmesh.loadok And vmesh.isSkinnedMesh Then
        MsgBox "No BF2 mesh loaded.", vbExclamation
        Exit Sub
    End If
    frmSkin.Show
End Sub

Private Sub mnuViewSvnUpdateTex_Click()
    '
    
End Sub

Private Sub mnuHelpOpenglInfo_Click()
    frmGLInfo.Show vbModal
End Sub

Private Sub mnuHelpAbout_Click()
    frmAbout.Show vbModal
End Sub

'--- toolbars ------------------------------------------------------------

Private Sub tlbMain_ButtonClick(ByVal Button As MSComctlLib.Button)
    Select Case Button.key
    Case "openfile":        mnuFileOpen_Click
    Case "savefile":        mnuFileSave_Click
    
    Case "lighting":
        mnuViewLighting_Click
        
    Case "wire":
        view_wire = False
        mnuViewWireframe_Click
        view_textures = True
        mnuViewTexture_Click
        
    Case "solid":
        view_wire = True
        mnuViewWireframe_Click
        view_textures = True
        mnuViewTexture_Click
        
    Case "textured"
        view_wire = True
        mnuViewWireframe_Click
        view_textures = False
        mnuViewTexture_Click
    
    Case "matedit":       'TODO?
    Case "skinedit":      mnuToolsSkin_Click
    Case "uvedit":        mnuToolsUvEditor_Click
    Case "meshedit":      EditMesh (Button.value = tbrPressed), True
    Case "pickmat":       pickmatmode = (Button.value = tbrPressed)
    End Select
    picMain_Paint
End Sub

'sets mesh editing mode
Public Sub EditMesh(ByVal enabled As Boolean, ByVal onclick As Boolean)
    If enabled And vmesh.loadok Then
        edit_mesh = True
        toolmode = 1
        GenMeshEditInfo
    Else
        edit_mesh = False
        toolmode = 0
        frmTransform.Hide
        frmFix.Hide
    End If
    Me.tlbMesh.Visible = edit_mesh
    If Not onclick Then
        Dim i As Long
        If edit_mesh Then
            Me.tlbMain.Buttons("meshedit").value = tbrPressed
        Else
            Me.tlbMain.Buttons("meshedit").value = tbrUnpressed
        End If
    End If
    selbackface = (Me.tlbMesh.Buttons("selbackface").value = tbrPressed)
    
    'workaround for missing tooltips on mesh toolbar
    'TODO
End Sub

Private Sub SetSelMode(ByVal mode As selmodes)
    selmode = mode
    Me.tlbMesh.Buttons("collapse").enabled = (selmode = sel_vert)
    Me.tlbMesh.Buttons("facedel").enabled = (selmode > sel_edge)
    'Me.tlbMesh.Buttons("fix").enabled = (selmode > sel_edge)
End Sub
    
Private Sub tlbMesh_ButtonClick(ByVal Button As MSComctlLib.Button)
    Select Case Button.key
    Case "selinside": selinside = (Button.value = tbrPressed)
    Case "selbackface": selbackface = (Button.value = tbrPressed)
    Case "vert": SetSelMode sel_vert
    Case "edge": SetSelMode sel_edge
    Case "face": SetSelMode sel_face
    Case "poly": SetSelMode sel_poly
    Case "elem": SetSelMode sel_elem
    Case "flatten":
        If selmode = sel_vert Then FlattenVertNormals
        If selmode >= sel_face Then FlattenFaceNormals
    Case "weld"
        If selmode = sel_vert Then WeldVertNormals
        If selmode >= sel_face Then WeldFaceNormals
    Case "collapse"
        If selmode = sel_vert Then CollapseVerts
    Case "facedel"
        If MsgBox("Are you sure you want to delete the selected faces?" & vbLf & "This operation cannot be undone.", vbExclamation Or vbYesNoCancel) = vbYes Then
            DeleteFaces
        End If
    Case "fix"
        frmFix.OnShow
        frmFix.Show
    Case "transform"
        frmTransform.Show
    End Select
    picMain_Paint
End Sub

'--- treeview menu -----------------------------------------------------------

Private Sub mnuTreeContextViewTex_Click()
    Dim fname As String
    If vmesh.loadok Then fname = GetSelectedTextureFilename
    If stdmesh.loadok Then fname = GetStdMeshSelectedTextureFilename
    'If treemesh.loadok Then fname = GetSelectedTextureFilename2
    
    If FileExist(fname) Then
        ShellExecute 0, vbNullString, fname, vbNullString, vbNullString, vbNormalFocus
    End If
End Sub


'strips top file+folder from path (path must have filename or trailing slash)
Private Function StripTopFolder(ByVal path As String) As String
    path = GetFilePath(path)
    
    Dim pos As Long
    pos = InStrRev(path, "\")
    If pos < 2 Then
        StripTopFolder = ""
        Exit Function
    End If
    StripTopFolder = Mid(path, 1, pos - 1)
    
    'pos = InStrRev(path, "\")
    'If pos <> 0 Then
    '    StripTopFolder = Mid(path, 1, pos - 1)
    'Else
    '    StripTopFolder = ""
    'End If
End Function


'case in-sensitive check if folder exists
Public Function FolderExists(ByRef path As String) As Boolean
    Dim fs As FileSystemObject
    Set fs = New FileSystemObject
    FolderExists = fs.FolderExists(path)
End Function

Private Sub mnuTreeContextOpenFolder_Click()
    Dim fname As String
    If vmesh.loadok Then
        fname = GetSelectedTextureFilename
        If FileExist(fname) Then
            ShellExecute 0, vbNullString, "explorer.exe", "/select, " & Chr(34) & fname & Chr(34), vbNullString, vbNormalFocus
        Else
            If texpathnum > 0 Then
                Dim i As Long
                For i = 1 To texpathnum
                    If texpath(i).use Then
                        fname = Replace(texpath(i).path & "\" & BF2GetMapFilename(selgeom, sellod, selmat, seltex), "/", "\")
                        'fname = texpath(i).path & "\Objects\vehicles\"
                        Dim nuts As Long
                        Do While fname <> ""
                            fname = StripTopFolder(fname)
                            If FolderExists(fname) Then
                                ShellExecute 0, vbNullString, fname, vbNullString, vbNullString, vbNormalFocus
                                Exit Sub
                            End If
                            nuts = nuts + 1
                            If nuts > 30 Then Exit Sub
                        Loop
                    End If
                Next i
            End If
        End If
    End If
End Sub

Private Sub mnuTreeContextSelectFaces_Click()
    If selmat > -1 Then
        SelectByMaterial selmat
        picMain_Paint
    End If
End Sub

Private Sub mnuTreeContextEdit_Click()
'Dim str As String
'Dim def As String
'    def = GetSelectedTextureFilename
'    str = InputBox("Texture:", "Edit Texture File Name", def)
'    If Len(str) > 0 Then
'        'setselectedtexturefilename str
'    End If
    
    If selmat > -1 Then
        frmMaterial.Show vbModal
        Exit Sub
    End If
End Sub

Private Function ValSel(ByVal level As Long) As Boolean
    With vmesh
        If Not .loadok Then Exit Function
        
        If selgeom < 0 Then Exit Function
        If selgeom > vmesh.geomnum - 1 Then Exit Function
        If level = 1 Then
            ValSel = True
            Exit Function
        End If
        
        If sellod < 0 Then Exit Function
        If sellod > vmesh.geom(selgeom).lodnum - 1 Then Exit Function
        If level = 2 Then
            ValSel = True
            Exit Function
        End If
        
        If selmat < 0 Then Exit Function
        If selmat > vmesh.geom(selgeom).lod(sellod).matnum Then Exit Function
        If level = 3 Then
            ValSel = True
            Exit Function
        End If
        
        If seltex < 0 Then Exit Function
        If seltex > vmesh.geom(selgeom).lod(sellod).mat(selmat).mapnum Then Exit Function
        If level = 4 Then
            ValSel = True
            Exit Function
        End If
        
    End With
End Function

Private Sub mnuTreeContextCopy_Click()
    If Not ValSel(3) Then Exit Sub
    copymat = vmesh.geom(selgeom).lod(sellod).mat(selmat)
    copymatset = True
End Sub

Private Sub mnuTreeContextPaste_Click()
    If Not ValSel(3) Then Exit Sub
    If Not copymatset Then Exit Sub
    PasteMaterial vmesh.geom(selgeom).lod(sellod).mat(selmat), copymat
    frmMain.FillTreeView
    picMain_Paint
End Sub

Private Sub mnuTreeContextDelete_Click()
    If ValSel(3) Then
        BF2DeleteMat selgeom, sellod, selmat
    Else
        If ValSel(2) Then
            BF2DeleteLod selgeom, sellod
        End If
    End If
End Sub

Private Sub mnuTreeContextExpand_Click()
Dim i As Long
    trvMain.Visible = False
    For i = 1 To trvMain.Nodes.count
        trvMain.Nodes.Item(i).Expanded = True
    Next i
    trvMain.Visible = True
End Sub

Private Sub mnuTreeContextCollapse_Click()
Dim i As Long
    trvMain.Visible = False
    For i = 1 To trvMain.Nodes.count
        trvMain.Nodes.Item(i).Expanded = False
    Next i
    trvMain.Visible = True
End Sub

Private Function GetSelectedTextureFilename() As String
    GetSelectedTextureFilename = BF2GetTextureFilename(selgeom, sellod, selmat, seltex)
End Function

Private Sub trvMain_DblClick()
    If seltex > -1 Then
        mnuTreeContextViewTex_Click
    End If
End Sub

Private Sub trvMain_KeyUp(KeyCode As Integer, Shift As Integer)
    SelectMesh val(trvMain.SelectedItem.tag), trvMain.SelectedItem.key
    picMain_Paint
End Sub

Private Sub trvMain_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    On Error GoTo hell
    
    'select node under cursor
    Dim n As MSComctlLib.node
    Set n = Me.trvMain.HitTest(X, Y)
    If Not n Is Nothing Then
        SelectMesh n.tag, n.key
        picMain_Paint
    End If
    
    Exit Sub
hell:
    SelectMesh -1, MakeKey(0, 0, -1, -1)
    picMain_Paint
End Sub

Private Sub trvMain_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    On Error GoTo errhandler
    
    'note: we show the context menu on MouseDown because NodeClick steals the MouseUp event
    If Button = vbRightButton Then
        
        Me.mnuTreeContextViewTex.enabled = False
        'Me.mnuTreeContextOpenFolder.enabled = False
        Me.mnuTreeContextEdit.enabled = False
        Me.mnuTreeContextSelectFaces.enabled = False
        Me.mnuTreeContextCopy.enabled = False
        Me.mnuTreeContextPaste.enabled = False
        
        If vmesh.loadok Then
            If selmat > -1 And seltex > -1 Then
                If GetSelectedTextureFilename <> "" Then
                    Me.mnuTreeContextViewTex.enabled = True
                    'Me.mnuTreeContextOpenFolder.enabled = True
                End If
            End If
            
            If selmat > -1 Then
                Me.mnuTreeContextEdit.enabled = True
                Me.mnuTreeContextSelectFaces.enabled = True
            End If
            If selmat > -1 And seltex = -1 Then
                Me.mnuTreeContextCopy.enabled = True
                Me.mnuTreeContextPaste.enabled = True
            End If
        End If
        
        'show context menu
        PopupMenu Me.mnuTreeContext, vbPopupMenuRightButton, _
                  trvMain.Left + (X / 15) + 2, _
                  trvMain.top + (Y / 15) + 2, mnuTreeContextViewTex
        
    End If
    
    Exit Sub
errhandler:
    MsgBox "trvMain_MouseUp" & vbLf & err.description, vbCritical
End Sub

'NOTE: DONT USE THIS, BREAKS MouseUp and MouseDown events!!!
'Private Sub trvMain_NodeClick(ByVal node As MSComctlLib.node)
'    If node.tag <> "" Then
'        SelectMesh node.tag, node.key
'        picMain_Paint
'    End If
'End Sub

Public Sub SelectMesh(ByVal id As Long, Optional ByVal key As String)
    'On Error Resume Next
    
    'bf2 mesh
    If vmesh.loadok Then
        
        're-enable drawing to allow some form of recovery
        vmesh.drawok = True
        
        'reset selection in case of error
        selgeom = 0
        sellod = 0
        selmat = -1
        seltex = -1
        
        If id = -1 Then
            Dim str() As String
            
            str = Split(key, "|")
            If str(0) = "@" Then
                selgeom = val(str(1))
                sellod = val(str(2))
                selmat = val(str(3))
                seltex = val(str(4))
            End If
        Else
            'old selection mechanism
            selgeom = GetBit(id, 0)
            sellod = GetBit(id, 1)
        End If
        
        'make sure the indices are not out of range
        If selgeom < 0 Then selgeom = 0
        If sellod < 0 Then sellod = 0
        If selmat < -1 Then selmat = -1
        If seltex < -1 Then seltex = -1
        
        If selgeom > vmesh.geomnum - 1 Then selgeom = 0
        If sellod > vmesh.geom(selgeom).lodnum - 1 Then sellod = 0
        If selmat > 0 Then
            If selmat > vmesh.geom(selgeom).lod(sellod).matnum Then selmat = -1
        End If
        If seltex > 0 Then
            If seltex > vmesh.geom(selgeom).lod(sellod).mat(selmat).mapnum Then seltex = -1
        End If
        
        'update status bar
        SetStatus "geom", "Geom " & selgeom
        SetStatus "lod", "Lod " & sellod
        SetStatus "mat", "Material " & selmat
        SetStatus "tri", vmesh.geom(selgeom).lod(sellod).polycount & " triangles"
        
        'redraw UV editor
        UvEdit_Paint
        frmUvEdit.FillMaterialList
    End If
    
    'bf2 collision mesh
    If cmesh.loadok Then
        selgeom = GetBit(id, 0)
        selsub = GetBit(id, 1)
        sellod = GetBit(id, 2)
        selmat = -1
        
        If selgeom > cmesh.geomnum - 1 Then selgeom = 0
        If selsub > cmesh.geom(selgeom).subgnum - 1 Then selsub = 0
        If sellod > cmesh.geom(selgeom).subg(selsub).lodnum - 1 Then sellod = 0
        
        SetStatus "geom", "Geom " & selgeom
        SetStatus "lod", "Sub " & selsub
        SetStatus "mat", "Col " & sellod
        SetStatus "tri", ""
    End If
    
    'bf42 standardmesh
    If stdmesh.loadok Then
        Dim b1 As Byte
        b1 = GetBit(id, 0)
        
        If b1 < 2 Then
            selgeom = GetBit(id, 0)
            sellod = GetBit(id, 1)
            selmat = GetBit(id, 2)
            seltex = -1
        End If
        
        SetStatus "geom", ""
        If b1 = 0 Then
            SetStatus "lod", "Lod " & sellod
            SetStatus "mat", stdmesh.lod(sellod).matnum & " materials"
            SetStatus "tri", stdmesh.lod(sellod).polycount & " triangles"
        End If
        If b1 = 1 Then
            SetStatus "lod", "Col " & sellod
            SetStatus "mat", ""
            SetStatus "tri", stdmesh.col(sellod).facenum & " triangles"
        End If
        If b1 = 2 Then 'we abuse seltex to know which shader is selected
            seltex = GetBit(id, 1)
        End If
    End If
    
    'FHX geometry
    If fhxgeo.loadok Then
        selgeom = -1
        sellod = id
        selmat = -1
        
        If sellod < 0 Then sellod = 0
        If sellod > fhxgeo.lodnum - 1 Then sellod = fhxgeo.lodnum - 1
        
        SetStatus "geom", ""
        SetStatus "lod", "Lod " & sellod
        SetStatus "mat", (fhxgeo.lod(sellod).matgroupnum) & " materials"
        SetStatus "tri", (fhxgeo.lod(sellod).indexnum / 3) & " triangles"
    End If
    
    On Error GoTo 0
End Sub

Private Sub cmdLog_Click()
    mnuViewLog_Click
End Sub

'--- files --------------------------------------------------------------------------

'drop file on form
Public Sub DropFile(ByRef str As String)
    If FileExist(str) Then
        Select Case LCase(GetFileExt(str))
        Case "baf"
            If LoadBF2Anim(str) Then
                SetTime 0
            End If
        Case "ske"
            LoadBF2Skeleton str
        Case "con", "tweak"
            LoadCon str
        Case Else
            OpenFile str
        End Select
    End If
    FillTreeView
    Form_Resize
    picMain_Paint
End Sub

Private Sub OpenFile(ByVal filename As String)
    quitguard = True
    blockdraw = True
    
    CloseFile
    
    copymatset = False
    seldefault = MakeTag(0, 0, 0)
    
    current_file = filename
    current_folder = GetFilePath(filename)
    
    OpenMeshFile filename
    FillTreeView
    frmUvEdit.FillChannelList
    EditMesh False, False
    'ZoomExtends
    
    SetStatus "info", "Done."
    SetStatus "mem", "TexMem: " & GetTextureMemory
    
    'reset selection
    SelectMesh seldefault
    
    mnuFileSave.enabled = True
    mnuFileSaveAs.enabled = True
    mnuFileClose.enabled = True
    mnuFileReload.enabled = True
    mnuFileExport.enabled = True
    
    'update UI
    UpdateCaption
    Form_Resize
    
    blockdraw = False
    quitguard = False
    RedrawViewports
End Sub

Private Sub SaveFile(ByVal filename As String)
    current_file = filename
    current_folder = GetFilePath(filename)
    SaveMeshFile filename
    
    SetStatus "info", "Saved."
    UpdateCaption
End Sub

Private Sub CloseFile()
    current_file = ""
    
    CloseMeshFile
    FillTreeView
    txtLog.Text = ""
    
    SetStatus "info", ""
    SetStatus "geom", ""
    SetStatus "lod", ""
    SetStatus "mat", ""
    SetStatus "mem", ""
    
    mnuFileSave.enabled = False
    mnuFileSaveAs.enabled = False
    mnuFileClose.enabled = False
    mnuFileReload.enabled = False
    mnuFileExport.enabled = False
    
    UpdateCaption
    'Form_Resize
    
    RedrawViewports
End Sub

'updates title bar
Private Sub UpdateCaption()
    If Len(current_file) = 0 Then
        frmMain.Caption = App.Title & " " & App.Major & "." & App.Minor & "." & App.Revision
    Else
        frmMain.Caption = App.Title & " " & App.Major & "." & App.Minor & "." & App.Revision & " - [" & current_file & "]"
    End If
End Sub

'reset mousepointer
Private Sub stsMain_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Me.MousePointer = vbDefault
End Sub
Private Sub trvMain_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Me.MousePointer = vbDefault
End Sub

Private Sub txtLog_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Me.MousePointer = vbDefault
End Sub

Private Sub txtConsole_KeyDown(KeyCode As Integer, Shift As Integer)
    If Not KeyCode = vbKeyReturn Then Exit Sub
    
    Dim cmd As String
    cmd = Me.txtConsole.Text
    Me.txtConsole.Text = ""
    
    Dim str() As String
    str() = Split(cmd, " ", 1)
    
    Select Case str(0)
    Case "overflow"
        On Error Resume Next
        Dim v As Single
        'v = GetNaN 'IND
        'v = -GetNaN 'QNAN
        v = Sqr(0)
        InputBox "Copy this:", "v", CStr(v)
        
        Dim tmp As Long
        CopyMem VarPtr(tmp), VarPtr(v), 4
        InputBox "Copy this:", "tmp", tmp
        On Error GoTo 0
        
    Case "weights"
        With vmesh
            Dim vw As bf2vw
            Dim i As Long
            Dim woff As Long
            woff = BF2MeshGetWeightOffset
            
            Dim minb As Long
            Dim maxb As Long
            Dim minw As Long
            Dim maxw As Long
            minb = 999
            maxb = -999
            
            For i = 0 To .vertnum - 1
                CopyMem VarPtr(vw), VarPtr(.vert(i * .stride + woff)), 4
                
                If i < 100 Then
                    Echo "vert[" & i & "].b1: " & vw.b1
                    Echo "vert[" & i & "].b2: " & vw.b2
                    Echo "vert[" & i & "].w1: " & vw.w1
                    Echo "vert[" & i & "].w2: " & vw.w2
                End If
                
                minb = min(minb, vw.b1)
                minb = min(minb, vw.b2)
                maxb = max(maxb, vw.b1)
                maxb = max(maxb, vw.b2)
                
                minw = min(minw, vw.w1)
                minw = min(minw, vw.w2)
                maxw = max(maxw, vw.w1)
                maxw = max(maxw, vw.w2)
            Next i
            
            Echo "bone range: " & minb & " to " & maxb
            Echo "weight range: " & minw & " to " & maxw
        End With
    Case Else
        Echo "Unknown command."
    End Select
    
    Me.txtLog.SelStart = Len(Me.txtLog.Text)
    Exit Sub
errhandler:
    Echo "ERROR: " & err.description
    Me.txtLog.SelStart = Len(Me.txtLog.Text)
End Sub

'fills treeview
Public Sub FillTreeView()
    
    Me.trvMain.Visible = False
    Me.trvMain.enabled = False
    
    'make backup of node states
    Dim i As Long
    Dim j As Long
    Dim n_num As Long
    Dim n_key() As String
    Dim n_exp() As Boolean
    Dim selkey As String
    If Me.trvMain.Nodes.count > 0 Then
        n_num = Me.trvMain.Nodes.count
        ReDim n_key(1 To n_num)
        ReDim n_exp(1 To n_num)
        For i = 1 To trvMain.Nodes.count
            n_key(i) = trvMain.Nodes.Item(i).key
            n_exp(i) = trvMain.Nodes.Item(i).Expanded
        Next i
        If Not Me.trvMain.SelectedItem Is Nothing Then
            selkey = Me.trvMain.SelectedItem.key
        End If
    End If
    
    'clear treeview
    Me.trvMain.Nodes.Clear
    
    'BF2
    FillTreeVisMesh Me.trvMain
    FillTreeColMesh Me.trvMain
    FillTreeBF2Skeleton Me.trvMain
    FillTreeBF2Anim Me.trvMain
    FillTreeSamples Me.trvMain
    FillTreeOcc Me.trvMain
    FillTreeBF2Con Me.trvMain
    
    'bf1942
    FillTreeStdMesh Me.trvMain
    FillTreeStdMeshShaders Me.trvMain
    FillTreeTreeMesh Me.trvMain
    
    'FHX
    FillTreeFhxGeo Me.trvMain
    FillTreeFhxTri Me.trvMain
    FillTreeFhxRig Me.trvMain
    
    'obj
    FillTreeObj Me.trvMain
    
    'restore node states
    If Me.trvMain.Nodes.count > 0 Then
        Dim delid As Long
        For i = 1 To trvMain.Nodes.count
            delid = 0
            For j = 1 To n_num
                'If trvMain.Nodes(i).key = n_key(j) Then
                If StrMatch(trvMain.Nodes(i).key, n_key(j)) Then
                    trvMain.Nodes.Item(i).key = n_key(j)
                    trvMain.Nodes.Item(i).Expanded = n_exp(j)
                    delid = j
                    Exit For
                End If
            Next j
            
            'shrink list
            If delid > 0 Then
                'n_key(delid) = n_key(n_num)
                'n_num = n_num - 1
            End If
            
            If LenB(selkey) > 0 Then
                If trvMain.Nodes(i).key = selkey Then
                    Set trvMain.SelectedItem = trvMain.Nodes(i)
                End If
            End If
        Next i
    End If
    
    Me.trvMain.enabled = True
    Me.trvMain.Visible = True
End Sub

'fast string compare
Private Function StrMatch(ByRef a As String, ByRef b As String) As Boolean
    If LenB(a) = 0 Then Exit Function
    If LenB(b) = 0 Then Exit Function
    If AscW(a) <> AscW(b) Then Exit Function
    If a <> b Then Exit Function
    StrMatch = True
End Function

'fills suffix menu list
Private Sub FillSuffixMenu()
Dim i As Long
    For i = 1 To suffixnum
        Load mnuOptionsSuffixItem(i)
        mnuOptionsSuffixItem(i).Caption = suffix(i)
        mnuOptionsSuffixItem(i).Visible = True
    Next i
End Sub

