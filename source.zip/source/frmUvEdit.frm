VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmUvEdit 
   Caption         =   "UV Editor"
   ClientHeight    =   7995
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   9780
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmUvEdit.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   533
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   652
   StartUpPosition =   1  'CenterOwner
   Begin VB.Frame fraTransform 
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Caption         =   "Frame1"
      Height          =   375
      Left            =   120
      TabIndex        =   6
      Top             =   7320
      Width           =   7575
      Begin VB.CommandButton cmdUnwrap 
         Caption         =   "Z"
         Height          =   315
         Index           =   2
         Left            =   5520
         TabIndex        =   13
         Top             =   30
         Width           =   375
      End
      Begin VB.CommandButton cmdUnwrap 
         Caption         =   "Y"
         Height          =   315
         Index           =   1
         Left            =   5040
         TabIndex        =   12
         Top             =   30
         Width           =   375
      End
      Begin VB.CommandButton cmdUnwrap 
         Caption         =   "X"
         Height          =   315
         Index           =   0
         Left            =   4560
         TabIndex        =   11
         Top             =   30
         Width           =   375
      End
      Begin VB.CommandButton cmdScale 
         Caption         =   "Scale"
         Height          =   315
         Left            =   2640
         TabIndex        =   10
         Top             =   30
         Width           =   855
      End
      Begin VB.TextBox txtScale 
         Alignment       =   2  'Center
         Height          =   285
         Index           =   1
         Left            =   1560
         TabIndex        =   8
         Text            =   "1.0"
         Top             =   60
         Width           =   975
      End
      Begin VB.TextBox txtScale 
         Alignment       =   2  'Center
         Height          =   285
         Index           =   0
         Left            =   480
         TabIndex        =   7
         Text            =   "1.0"
         Top             =   60
         Width           =   975
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "Unwrap:"
         Height          =   195
         Left            =   3840
         TabIndex        =   14
         Top             =   105
         Width           =   615
      End
      Begin VB.Label labMisc 
         AutoSize        =   -1  'True
         Caption         =   "UV:"
         Height          =   195
         Left            =   60
         TabIndex        =   9
         Top             =   105
         Width           =   255
      End
   End
   Begin MSComctlLib.ImageList imlTools 
      Left            =   6600
      Top             =   3000
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16711935
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   17
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":1042
            Key             =   "select"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":11AC
            Key             =   "move"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":1306
            Key             =   "scale"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":146C
            Key             =   "uvxneg"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":17BE
            Key             =   "uvxnpos"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":1B10
            Key             =   "uvyneg"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":1E62
            Key             =   "uvypos"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":21B4
            Key             =   "collapse"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":2506
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":2660
            Key             =   ""
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":27BA
            Key             =   ""
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":2914
            Key             =   ""
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":2A6E
            Key             =   ""
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":2BD0
            Key             =   ""
         EndProperty
         BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":2D32
            Key             =   ""
         EndProperty
         BeginProperty ListImage16 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":2E98
            Key             =   ""
         EndProperty
         BeginProperty ListImage17 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmUvEdit.frx":2FFE
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Frame fraTools 
      BackColor       =   &H00C0FFC0&
      BorderStyle     =   0  'None
      Caption         =   "Tools"
      Height          =   780
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   8655
      Begin VB.CommandButton cmdFaceSel 
         Caption         =   "Sync Selection"
         Height          =   315
         Left            =   6240
         TabIndex        =   5
         Top             =   420
         Width           =   1455
      End
      Begin VB.ComboBox cbbMaterial 
         Height          =   315
         Left            =   2040
         Style           =   2  'Dropdown List
         TabIndex        =   4
         Top             =   60
         Width           =   3255
      End
      Begin VB.ComboBox cbbChannel 
         Height          =   315
         Left            =   60
         Style           =   2  'Dropdown List
         TabIndex        =   2
         Top             =   60
         Width           =   1935
      End
      Begin MSComctlLib.Toolbar tlbTools 
         Height          =   330
         Left            =   60
         TabIndex        =   3
         Top             =   405
         Width           =   6075
         _ExtentX        =   10716
         _ExtentY        =   582
         ButtonWidth     =   609
         ButtonHeight    =   582
         AllowCustomize  =   0   'False
         Wrappable       =   0   'False
         Style           =   1
         ImageList       =   "imlTools"
         _Version        =   393216
         BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
            NumButtons      =   20
            BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "select"
               Object.ToolTipText     =   "Select UVs"
               ImageIndex      =   17
               Style           =   2
               Value           =   1
            EndProperty
            BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "move"
               Object.ToolTipText     =   "Move UVs"
               ImageIndex      =   2
               Style           =   2
            EndProperty
            BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "movex"
               ImageIndex      =   9
               Style           =   2
            EndProperty
            BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "movey"
               ImageIndex      =   10
               Style           =   2
            EndProperty
            BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "scale"
               Object.ToolTipText     =   "Scale UVs"
               ImageIndex      =   3
               Style           =   2
            EndProperty
            BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "scalex"
               Object.ToolTipText     =   "Scale U"
               ImageIndex      =   15
               Style           =   2
            EndProperty
            BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "scaley"
               Object.ToolTipText     =   "Scale V"
               ImageIndex      =   16
               Style           =   2
            EndProperty
            BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Style           =   3
            EndProperty
            BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "rotleft"
               ImageIndex      =   12
            EndProperty
            BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "rotright"
               ImageIndex      =   11
            EndProperty
            BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Style           =   3
            EndProperty
            BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "mirrorx"
               ImageIndex      =   13
            EndProperty
            BeginProperty Button13 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "mirrory"
               ImageIndex      =   14
            EndProperty
            BeginProperty Button14 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Style           =   3
            EndProperty
            BeginProperty Button15 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "uvxneg"
               ImageIndex      =   4
            EndProperty
            BeginProperty Button16 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "uvxpos"
               ImageIndex      =   5
            EndProperty
            BeginProperty Button17 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "uvyneg"
               ImageIndex      =   6
            EndProperty
            BeginProperty Button18 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "uvypos"
               ImageIndex      =   7
            EndProperty
            BeginProperty Button19 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Style           =   3
            EndProperty
            BeginProperty Button20 {66833FEA-8583-11D1-B16A-00C0F0283628} 
               Key             =   "collapse"
               ImageIndex      =   8
            EndProperty
         EndProperty
      End
   End
   Begin VB.PictureBox picMain 
      BackColor       =   &H00404040&
      BorderStyle     =   0  'None
      Height          =   4500
      Left            =   840
      ScaleHeight     =   300
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   300
      TabIndex        =   0
      Top             =   1080
      Width           =   4500
   End
End
Attribute VB_Name = "frmUvEdit"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Enum uvtoolmode
    tool_select = 0
    tool_move = 1
    tool_scale = 2
    tool_movex
    tool_movey
    tool_scalex
    tool_scaley
End Enum

Private zoom As Single
Private offx As Single
Private offy As Single
Private mousedown As Boolean
Private mousex As Long
Private mousey As Long
Private dragx As Single     'mouse coordinates at start of drag
Private dragy As Single     'mouse coordinates at start of drag
Private dsx As Single       'zoom scale
Private dsy As Single       'zoom scale
Private showtex As Long     'texture map index
Private texasp As Single    'texture aspect ratio
Private toolmode As uvtoolmode      'current tool mode
Private oldtoolmode As uvtoolmode   'mode before pressing ctrl/alt
Private uvchan As Long
Public uvmatsel As Long

Private sel_vis As Boolean
Private sel_minx As Single
Private sel_miny As Single
Private sel_maxx As Single
Private sel_maxy As Single

Private selbox As Boolean
Private selbox_min As float2
Private selbox_max As float2
Private selbox_ctr As float2
                
Private hglrc As Long


Private Sub Form_Load()
    Me.fraTools.BackColor = &H8000000F
    Me.fraTransform.BackColor = &H8000000F
    
    'setup opengl
    Dim pfd As PIXELFORMATDESCRIPTOR
    Dim fmt As Long
    pfd.nSize = Len(pfd)
    pfd.nVersion = 1
    pfd.dwFlags = PFD_SUPPORT_OPENGL Or PFD_DRAW_TO_WINDOW Or PFD_DOUBLEBUFFER Or PFD_TYPE_RGBA
    pfd.iPixelType = PFD_TYPE_RGBA
    pfd.cColorBits = 24
    pfd.cDepthBits = 0
    pfd.iLayerType = PFD_MAIN_PLANE
    fmt = ChoosePixelFormat(Me.picMain.hDC, pfd)
    If fmt = 0 Then
        MsgBox "OpenGL initalization failed.", vbCritical
        Exit Sub
    End If
    fmt = SetPixelFormat(Me.picMain.hDC, fmt, pfd)
    hglrc = wglCreateContext(Me.picMain.hDC)
    wglShareLists frmMain.hglrc, hglrc
    wglMakeCurrent Me.picMain.hDC, hglrc
    
    'default states
    glTexEnvi GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE
    
    offx = 50
    offy = 50
    zoom = 1
    uvchan = 0
    toolmode = 0
    SetTexture
    
    FillChannelList
    FillMaterialList
    
    If Not idemode Then Hook2 Me.hWnd
    SetTopMostWindow Me.hWnd, True
    
    uveditor_isloaded = True
End Sub

Private Sub Form_GotFocus()
    'SetTopMostWindow Me.hWnd, True
End Sub

Private Sub Form_Resize()
    If Not Me.WindowState = vbMinimized Then
        If Me.width < 200 * 15 Then Me.width = 200 * 15
        If Me.height < 100 * 15 Then Me.height = 100 * 15
        Me.picMain.Move 3, Me.fraTools.height, Me.ScaleWidth - 6, Me.ScaleHeight - fraTools.height - 3 - fraTransform.height - 3
        Me.fraTransform.Move 3, Me.ScaleHeight - fraTransform.height - 3
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    If Not app_exit Then
        Cancel = True
        Me.Hide
        Exit Sub
    End If
    If hglrc Then
        wglMakeCurrent 0, 0
        wglDeleteContext hglrc
        hglrc = 0
    End If
    If Not idemode Then
        UnHook2
    End If
End Sub

'--- keyboard input ---------------------------------------------------------------------------

'keyboard down event
Private Sub picMain_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyControl Then keyctrl = True
    If KeyCode = vbKeyMenu Then keyalt = True
    
    'override tool mode
    If keyctrl And toolmode > tool_select Then
        oldtoolmode = toolmode
        SetToolMode tool_select
    End If
End Sub

'keyboard up event
Private Sub picMain_KeyUp(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyControl Then keyctrl = False
    If KeyCode = vbKeyMenu Then keyalt = False
    
    'restore tool mode
    If oldtoolmode <> tool_select Then
        SetToolMode oldtoolmode
        oldtoolmode = tool_select
    End If
End Sub

'--- mouse input ------------------------------------------------------------------------------


'mouse button down event
Private Sub picMain_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    mousedown = True
    mousex = x
    mousey = y
    
    dragx = x
    dragy = y
    
    picMain_Paint
End Sub


'mouse move event
Private Sub picMain_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    If mousedown Then
        Dim vx As Single
        Dim vy As Single
        vx = (x - mousex)
        vy = (y - mousey)
        
        'motion vector in UV space
        Dim uvx As Single
        Dim uvy As Single
        uvx = (vx / dsx)
        uvy = (vy / dsy) * texasp
        
        Dim sx As Single
        Dim sy As Single
        sx = 1 + ((vx / dsx))
        sy = 1 + ((-vy / dsy) * (1 / texasp))
        
        If Button = vbLeftButton Then
            Select Case toolmode
            Case tool_select
                sel_vis = True
                sel_minx = ((min(dragx, x) - offx) / dsx)
                sel_miny = ((min(dragy, y) - offy) / dsy) * texasp
                sel_maxx = ((max(dragx, x) - offx) / dsx)
                sel_maxy = ((max(dragy, y) - offy) / dsy) * texasp
                
            Case tool_move:   MoveVerts uvx, uvy
            Case tool_movex:  MoveVerts uvx, 0
            Case tool_movey:  MoveVerts 0, uvy
            
            Case tool_scale:  ScaleVerts sx, sy  'TODO: proper scaling 'areascaleverts vx, vy
            Case tool_scalex: ScaleVerts sx, 1
            Case tool_scaley: ScaleVerts 1, sy
            End Select
        End If
        
        If Button = vbRightButton Then
            ZoomVP dragx, dragy, (vy * 0.01)
            'Me.Caption = dsx
        End If
        
        If Button = vbMiddleButton Then
            offx = offx + vx
            offy = offy + vy
        End If
        
        RedrawViewports
    End If
    mousex = x
    mousey = y
End Sub


'mouse button up event
Private Sub picMain_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    
    'ignore MouseUp after minimizing/maximizing window
    If Not mousedown Then Exit Sub
    
    'selection
    If Button = vbLeftButton Then
        If toolmode = tool_select Then
            
            If sel_vis Then
                SelVerts sel_minx, sel_miny, sel_maxx, sel_maxy
            Else
                SelVerts ((x - 3) - offx) / dsx, (((y - 3) - offy) / dsy) * texasp, _
                         ((x + 3) - offx) / dsx, (((y + 3) - offy) / dsy) * texasp
            End If
            
        End If
    End If
    
    sel_vis = False
    mousedown = False
    RedrawViewports
End Sub


'mouse wheel event
Public Sub MouseWheel(ByVal MouseKeys As Long, ByVal value As Long, ByVal x As Long, ByVal y As Long)
    'NOTE: x and y seem to contain bad values (zero?), so we use mousex, mousey
    ZoomVP mousex, mousey, (value * -0.1)
    picMain_Paint
End Sub


'--- misc ------------------------------------------------------------------------------------------------


'zooms viewport at coordinates
Public Sub ZoomVP(ByVal x As Single, ByVal y As Single, ByVal z As Single)
    Dim cx As Single
    Dim cy As Single
    cx = TFXi(x)
    cy = TFYi(y)
    
    zoom = zoom - (z * zoom)
    If zoom < 0.001 Then zoom = 0.001
    If zoom > 1000 Then zoom = 1000
    
    Dim ncx As Single
    Dim ncy As Single
    ncx = TFXi(x)
    ncy = TFYi(y)
    
    offx = offx + (ncx - cx) * zoom
    offy = offy + (ncy - cy) * zoom
End Sub


'fills dropdown lists
Public Sub FillChannelList()
    On Error GoTo errhandler
    Me.cbbChannel.Clear
    
    uvchan = 0
    uvmatsel = 0
    
    With vmesh
        If Not .loadok Then Exit Sub
        If .uvnum = 5 Then
            Dim i As Long
            For i = 0 To .vertattribnum - 1
                If Not .vertattrib(i).flag = 255 Then
                    Select Case .vertattrib(i).usage
                    Case 5: Me.cbbChannel.AddItem "UV 1 (Base)"
                    Case 261: Me.cbbChannel.AddItem "UV 2 (Detail)"
                    Case 517: Me.cbbChannel.AddItem "UV 3 (Dirt)"
                    Case 773: Me.cbbChannel.AddItem "UV 4 (Crack)"
                    Case 1029: Me.cbbChannel.AddItem "UV 5 (Lightmap)"
                    End Select
                End If
            Next i
        Else
            For i = 0 To .uvnum - 1
                Me.cbbChannel.AddItem "UV " & (i + 1)
            Next i
        End If
    End With
    
    Me.cbbChannel.ListIndex = uvchan
    ClearSelection 'TODO: is this ok?!
    selbox = False
    
    Exit Sub
errhandler:
    MsgBox "FillChannelList" & vbLf & err.description, vbCritical
End Sub


'fills dropdown lists
Public Sub FillMaterialList()
    On Error GoTo errhandler
    
    Me.cbbMaterial.Clear
    With vmesh
        If Not .loadok Then Exit Sub
        If Not IsValidLod(selgeom, sellod) Then Exit Sub
        
        With .geom(selgeom).lod(sellod)
            Dim i As Long
            For i = 0 To .matnum - 1
                Me.cbbMaterial.AddItem "Material " & i & " - " & .mat(i).shortname
            Next i
            
            If uvmatsel < 0 Then uvmatsel = 0
            If uvmatsel > .matnum - 1 Then uvmatsel = 0
            Me.cbbMaterial.ListIndex = uvmatsel
        End With
        
        SetMaskFlags selgeom, sellod, uvmatsel
        'ClearSelection
        'selbox = False
    End With
    
    Exit Sub
errhandler:
    MsgBox "FillMaterialList" & vbLf & err.description, vbCritical
End Sub


'sets current tool mode
Private Sub SetToolMode(ByRef mode As uvtoolmode)
    toolmode = mode
    Select Case toolmode
    Case tool_select:      picMain.MousePointer = vbDefault
    Case tool_move:        picMain.MousePointer = vbSizeAll
    Case tool_movex:       picMain.MousePointer = vbSizeWE
    Case tool_movey:       picMain.MousePointer = vbSizeNS
    Case tool_scale:       picMain.MousePointer = vbSizeNESW
    Case tool_scalex:      picMain.MousePointer = vbSizeWE
    Case tool_scaley:      picMain.MousePointer = vbSizeNS
    End Select
End Sub


'toolbar button click event
Private Sub tlbTools_ButtonClick(ByVal Button As MSComctlLib.Button)
    Select Case Button.key
    Case "select":      SetToolMode tool_select
    Case "move":        SetToolMode tool_move
    Case "movex":       SetToolMode tool_movex
    Case "movey":       SetToolMode tool_movey
    Case "scale":       SetToolMode tool_scale
    Case "scalex":      SetToolMode tool_scalex
    Case "scaley":      SetToolMode tool_scaley
    
    Case "rotright":    RotateVerts 90
    Case "rotleft":     RotateVerts -90
    Case "mirrorx":     ScaleVerts -1, 1
    Case "mirrory":     ScaleVerts 1, -1
    
    Case "uvxneg":      MoveVerts -1, 0
    Case "uvxpos":      MoveVerts 1, 0
    Case "uvyneg":      MoveVerts 0, -1
    Case "uvypos":      MoveVerts 0, 1
    Case "collapse":    CollapseUvVerts
    End Select
    
    RedrawViewports
    Me.picMain.SetFocus
End Sub


'scale entry event
Private Sub txtScale_Validate(index As Integer, Cancel As Boolean)
    txtScale(index).Text = FormatFloat(txtScale(index).Text)
End Sub


'selects channel
Private Sub cbbChannel_Click()
    On Error GoTo errhandler
    
    If Not vmesh.loadok Then Exit Sub
    
    uvchan = Me.cbbChannel.ListIndex
    If uvchan < 0 Then uvchan = 0
    If uvchan > 4 Then uvchan = 4
    If (uvchan < 4) Then
        Me.cbbMaterial.BackColor = &H80000005
        Me.cbbMaterial.enabled = True
        uvmatsel = Me.cbbMaterial.ListIndex
    Else
        Me.cbbMaterial.BackColor = &H8000000F
        Me.cbbMaterial.enabled = False
        uvmatsel = -1
    End If
    
    SetMaskFlags selgeom, sellod, uvmatsel
    'ClearSelection
    'selbox = False
    SetTexture
    
    RedrawViewports
    
    Exit Sub
errhandler:
    MsgBox "cbbChannel_Click" & vbLf & err.description, vbCritical
End Sub


'selects material
Private Sub cbbMaterial_Click() 'NOTE: .ListIndex is zero-based, with -1 being undefined
    uvmatsel = Me.cbbMaterial.ListIndex
    'Me.Caption = uvmatsel
    
    SetMaskFlags selgeom, sellod, uvmatsel
    'ClearSelection
    'selbox = False
    SetTexture
    
    RedrawViewports
End Sub


'updates background texture
Private Sub SetTexture()
    showtex = 0
    texasp = 1
    With vmesh
        If IsValidMat(selgeom, sellod, uvmatsel) Then
            With .geom(selgeom).lod(sellod).mat(uvmatsel)
                
                If vmesh.isStaticMesh Then
                    Select Case uvchan
                    Case 0 'base
                    Case 1 'detail
                        If Not .hasDetail Then Exit Sub
                    Case 2 'dirt
                        If Not .hasDirt Then Exit Sub
                    Case 3 'crack
                        If Not .hasCrack Then Exit Sub
                    Case 4 'lightmap
                    End Select
                End If
                
                Dim ch As Long
                ch = uvchan
                
                'out of map range
                If ch < 0 Then ch = 0
                If ch > .mapnum - 1 Then ch = .mapnum - 1
                
                'should never be normal maps
                'If ch > 4 Then ch = 4
                
                showtex = .texmapid(ch)
                texasp = GetTexMapAspect(showtex)
                
            End With
        End If
    End With
End Sub


'selects UV vertices within rectangular boundaries
Private Sub SelVerts(ByVal minx As Single, ByVal miny As Single, ByVal maxx As Single, ByVal maxy As Single)
Dim i As Long
    
    'scale uv space
    With vmesh
        If Not .loadok Then Exit Sub
        SetMaskFlags selgeom, sellod, uvmatsel
        
        Dim uvoffset As Long
        uvoffset = BF2MeshGetTexcOffset(uvchan)
        
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            
                Dim x As Single
                Dim y As Single
                x = .vert(i * .stride + uvoffset + 0)
                y = .vert(i * .stride + uvoffset + 1)
                
                'clear vert selection
                If Not keyctrl And Not keyalt Then
                    .vertinfo(i).sel = 0
                End If
                If x >= minx Then
                    If x <= maxx Then
                        If y >= miny Then
                            If y <= maxy Then
                                
                                If keyalt Then
                                    .vertinfo(i).sel = 0
                                Else
                                    .vertinfo(i).sel = 1
                                End If
                                
                            End If
                        End If
                    End If
                End If
                
            End If
        Next i
        
    End With
    
    UpdateSelBox
End Sub


'updates selection box
Public Sub UpdateSelBox()
    'If Not Me.Visible Then Exit Sub
    
    selbox = False
    selbox_min.x = 9999
    selbox_min.y = 9999
    selbox_max.x = -9999
    selbox_max.y = -9999
    
    With vmesh
        If Not .loadok Then Exit Sub
        SetMaskFlags selgeom, sellod, uvmatsel
        
        Dim uvoff As Long
        uvoff = BF2MeshGetTexcOffset(uvchan)
        
        Dim i As Long
        Dim n As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag And .vertinfo(i).sel Then
                
                Dim v As float2
                v = GetTexc(uvoff, i)
                
                If v.x < selbox_min.x Then selbox_min.x = v.x
                If v.y < selbox_min.y Then selbox_min.y = v.y
                If v.x > selbox_max.x Then selbox_max.x = v.x
                If v.y > selbox_max.y Then selbox_max.y = v.y
                
                n = n + 1
            End If
        Next i
        
    End With
    
    selbox = (n > 0)
    selbox_ctr.x = (selbox_min.x + selbox_max.x) * 0.5
    selbox_ctr.y = (selbox_min.y + selbox_max.y) * 0.5
End Sub


'moves selected UV vertices
Private Sub MoveVerts(ByVal vx As Single, ByVal vy As Single)
Dim i As Long
    With vmesh
        If Not .loadok Then Exit Sub
        SetMaskFlags selgeom, sellod, uvmatsel
        
        Dim uvoffset As Long
        uvoffset = BF2MeshGetTexcOffset(uvchan)
        
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                
                Dim x As Single
                Dim y As Single
                
                x = .vert(i * .stride + uvoffset + 0)
                y = .vert(i * .stride + uvoffset + 1)
                
                x = x + vx
                y = y + vy
                
                .vert(i * .stride + uvoffset + 0) = x
                .vert(i * .stride + uvoffset + 1) = y
                
            End If
            End If
        Next i
    End With
    UpdateSelBox
End Sub


'moves selected UV vertices
Private Sub RotateVerts(ByVal rot As Single)
    If Not selbox Then Exit Sub
    With vmesh
        If Not .loadok Then Exit Sub
        SetMaskFlags selgeom, sellod, uvmatsel
        
        Dim uvoff As Long
        uvoff = BF2MeshGetTexcOffset(uvchan)
        
        'Dim aspscale As float2
        'aspscale = Rotate2D(float2(0, 0), float2(1, texasp), rot)
        
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                Dim uv As float2
                uv = GetTexc(uvoff, i)
                uv.x = uv.x - selbox_ctr.x
                uv.y = uv.y - selbox_ctr.y
                uv.y = uv.y / texasp
                uv = Rotate2D(float2(0, 0), uv, rot)
                uv.y = uv.y * texasp
                uv.x = uv.x + selbox_ctr.x
                uv.y = uv.y + selbox_ctr.y
                SetTexc uvoff, i, uv
            End If
            End If
        Next i
    End With
    UpdateSelBox
End Sub


'scales selected UV vertices
Private Sub ScaleVerts(ByVal sx As Single, ByVal sy As Single)
    With vmesh
        If Not .loadok Then Exit Sub
        SetMaskFlags selgeom, sellod, uvmatsel
        
        Dim uvoffset As Long
        uvoffset = BF2MeshGetTexcOffset(uvchan)
        
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                Dim uv As float2
                uv = GetTexc(uvoffset, i)
                
                uv.x = uv.x - selbox_ctr.x
                uv.y = uv.y - selbox_ctr.y
                
                uv.x = uv.x * sx
                uv.y = uv.y * sy
                
                uv.x = uv.x + selbox_ctr.x
                uv.y = uv.y + selbox_ctr.y
                
                SetTexc uvoffset, i, uv
            End If
            End If
        Next i
    End With
    UpdateSelBox
End Sub


'scale
Private Sub cmdScale_Click()
    'Dim str As String
    'str = InputBox("Scale Factor:", "Scale", 1)
    'If Len(str) = 0 Then Exit Sub
    
    Dim sx As Single
    Dim sy As Single
    sx = val(Me.txtScale(0).Text)
    sy = val(Me.txtScale(1).Text)
    
    With vmesh
        If Not .loadok Then Exit Sub
        SetMaskFlags selgeom, sellod, uvmatsel
        
        Dim uvoffset As Long
        uvoffset = BF2MeshGetTexcOffset(uvchan)
        
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                
                Dim uv As float2
                uv = GetTexc(uvoffset, i)
                
                uv.x = uv.x * sx
                uv.y = uv.y * sy
                
                SetTexc uvoffset, i, uv
                
                '.vert(i * .stride + uvoffset + 0) = .vert(i * .stride + uvoffset + 0) * s
                '.vert(i * .stride + uvoffset + 1) = .vert(i * .stride + uvoffset + 1) * s
                
            End If
            End If
        Next i
        
    End With
    UpdateSelBox
    RedrawViewports
    Me.picMain.SetFocus
End Sub


Private Sub cmdFaceSel_Click()
    SelectFaceVertices
    UpdateSelBox
    RedrawViewports
End Sub


Private Sub cmdUnwrap_Click(index As Integer)
    Unwrap index + 1
    UpdateSelBox
    RedrawViewports
    Me.picMain.SetFocus
End Sub


'unwraps faces
Private Sub Unwrap(ByVal axis As Long)
    With vmesh
        If Not .loadok Then Exit Sub
        SetMaskFlags selgeom, sellod, uvmatsel
        
        Dim uvoffset As Long
        uvoffset = BF2MeshGetTexcOffset(uvchan)
        
        Dim i As Long
        For i = 0 To .facenum - 1
            With .faceinfo(i)
                If .flag Then
                If .sel Then
                    '.vert(i * .stride + uvoffset + 0) = cx
                    '.vert(i * .stride + uvoffset + 1) = cy
                    
                    'get vertices
                    Dim v1 As float3
                    Dim v2 As float3
                    Dim v3 As float3
                    v1 = GetVert(.v1)
                    v2 = GetVert(.v2)
                    v3 = GetVert(.v3)
                    
                    'get edges
                    Dim e1 As float3
                    Dim e2 As float3
                    Dim e3 As float3
                    e1 = SubFloat3(v2, v1)
                    e2 = SubFloat3(v3, v2)
                    e3 = SubFloat3(v1, v3)
                    
                    Dim d1 As Single
                    Dim d2 As Single
                    Dim d3 As Single
                    d1 = Magnitude(e1)
                    d2 = Magnitude(e2)
                    d3 = Magnitude(e3)
                    
                    Dim t1 As float2
                    Dim t2 As float2
                    Dim t3 As float2
                    t1 = GetTexc(uvoffset, i)
                    t2 = GetTexc(uvoffset, i)
                    t3 = GetTexc(uvoffset, i)
                    
                    't1 = ScaleFloat2(Normalize(e1), d1))
                    't2 = ScaleFloat2(Normalize(e2), d2)
                    't3 = ScaleFloat2(Normalize(e3), d3)
                    
                    If axis = 1 Then 'X
                        t1.x = v1.z * 0.1
                        t2.x = v2.z * 0.1
                        t3.x = v3.z * 0.1
                        
                        t1.y = v1.y * 0.1
                        t2.y = v2.y * 0.1
                        t3.y = v3.y * 0.1
                    End If
                    
                    If axis = 2 Then 'Y
                        t1.x = v1.x * 0.1
                        t2.x = v2.x * 0.1
                        t3.x = v3.x * 0.1
                        
                        t1.y = v1.z * 0.1
                        t2.y = v2.z * 0.1
                        t3.y = v3.z * 0.1
                    End If
                    
                    If axis = 3 Then 'Z
                        t1.x = v1.x * 0.1
                        t2.x = v2.x * 0.1
                        t3.x = v3.x * 0.1
                        
                        t1.y = v1.y * 0.1
                        t2.y = v2.y * 0.1
                        t3.y = v3.y * 0.1
                    End If
                    
                    SetTexc uvoffset, .v1, t1
                    SetTexc uvoffset, .v2, t2
                    SetTexc uvoffset, .v3, t3
                    
                End If
                End If
            End With
        Next i
        
    End With
End Sub


'collapses selected UV vertices
Private Sub CollapseUvVerts()
Dim i As Long
    With vmesh
        If Not .loadok Then Exit Sub
        SetMaskFlags selgeom, sellod, uvmatsel
        
        Dim uvoffset As Long
        uvoffset = BF2MeshGetTexcOffset(uvchan)
        
        'determine selected vertex bounds
        Dim minx As Single
        Dim miny As Single
        Dim maxx As Single
        Dim maxy As Single
        minx = 9999
        miny = 9999
        maxx = -9999
        maxy = -9999
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                
                Dim x As Single
                Dim y As Single
                x = .vert(i * .stride + uvoffset + 0)
                y = .vert(i * .stride + uvoffset + 1)
                
                minx = min(minx, x)
                miny = min(miny, y)
                maxx = max(maxx, x)
                maxy = max(maxy, y)
                
            End If
            End If
        Next i
        
        'compute selection center
        Dim cx As Single
        Dim cy As Single
        cx = (minx + maxx) * 0.5
        cy = (miny + maxy) * 0.5
        
        'collapse vertices
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                .vert(i * .stride + uvoffset + 0) = cx
                .vert(i * .stride + uvoffset + 1) = cy
            End If
            End If
        Next i
        
    End With
    UpdateSelBox
End Sub


'redraws UV view
Public Sub picMain_Paint()
    If frmMain.blockdraw Then Exit Sub
    If Not Me.Visible Then Exit Sub
    
    On Error GoTo errhandler:
    
    'update draw scale
    dsx = zoom * 200
    dsy = zoom * 200
    
    DrawGL
    SwapBuffers Me.picMain.hDC
    
    Exit Sub
errhandler:
    Me.Caption = "picMain_Paint Error: " & err.description
    On Error GoTo 0
End Sub


'draws view with OpenGL
Private Sub DrawGL()
    If hglrc = 0 Then Exit Sub
    Dim w As Long
    Dim h As Long
    w = Me.picMain.ScaleWidth
    h = Me.picMain.ScaleHeight
    If w = 0 Then Exit Sub
    If h = 0 Then Exit Sub
    
    wglMakeCurrent Me.picMain.hDC, hglrc
    
    glViewport 0, 0, w, h
    glClearColor 0.25, 0.25, 0.25, 0
    glClear GL_COLOR_BUFFER_BIT
    
    glMatrixMode GL_PROJECTION
    glLoadIdentity
    glOrtho 0, w, h, 0, -1, 1
    
    glMatrixMode GL_MODELVIEW
    glLoadIdentity
    glTranslatef offx, offy, 0
    'glScalef zoom, zoom, 1
    glScalef dsx, dsy, 1
    glScalef 1, 1 / texasp, 1
    
    glDisable GL_LIGHTING
    glDisable GL_CULL_FACE
    
    Dim dpx As Single       '1 viewport pixel width in UV space
    Dim dpy As Single       '1 viewport pixel height in UV space
    dpx = 0 '(1 / w) * (1 / dsx)           'TODO: this is currently broken!!
    dpy = 0 '(1 / w) * texasp * (1 / dsy)  'TODO: this is currently broken!!
    
    Dim i As Long
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim uvoffset As Long
        uvoffset = BF2MeshGetTexcOffset(uvchan)
        
        'draw triangles
        Dim s As Long
        Dim v As Long
        With .geom(selgeom).lod(sellod)
            
            'check if lightmap
            If vmesh.isStaticMesh And vmesh.uvnum > 1 And uvchan = vmesh.uvnum - 1 Then
                
                'draw background
                glDisable GL_TEXTURE_2D
                glColor3f 0.3, 0.3, 0.3
                glBegin GL_QUADS
                    glVertex2f 0, 0
                    glVertex2f 0, 1
                    glVertex2f 1, 1
                    glVertex2f 1, 0
                glEnd
                
                glEnableClientState GL_VERTEX_ARRAY
                Dim m As Long
                For m = 0 To .matnum - 1
                    With .mat(m)
                        glColor3f 0.5, 0.5, 0.5
                        
                        s = .istart
                        v = (.vstart * vmesh.stride) + uvoffset
                        
                        'draw solid
                        glVertexPointer 2, GL_FLOAT, vmesh.vertstride, ByVal VarPtr(vmesh.vert(v))
                        glDrawElements GL_TRIANGLES, .inum, GL_UNSIGNED_SHORT, ByVal VarPtr(vmesh.index(s))
                        
                        'draw wire
                        StartAALine 1.333: glBlendFunc GL_ALPHA, GL_ONE_MINUS_SRC_COLOR
                        glPolygonMode GL_FRONT_AND_BACK, GL_LINE
                        glColor3f 0.5, 0.5, 0.5
                        glDisable GL_TEXTURE_2D
                        glColor4f 1, 1, 1, 0.1
                        glDrawElements GL_TRIANGLES, .inum, GL_UNSIGNED_SHORT, ByVal VarPtr(vmesh.index(s))
                        glPolygonMode GL_FRONT_AND_BACK, GL_FILL
                        EndAALine
                    End With
                Next m
                glDisableClientState GL_VERTEX_ARRAY
            Else
                If IsValidMat(selgeom, sellod, uvmatsel) Then
                    With .mat(uvmatsel)
                        
                        'bind/unbind texture
                        BindTexture showtex
                        
                        'draw background (textured)
                        glColor3f 0.5, 0.5, 0.5
                        glBegin GL_QUADS
                            glTexCoord2f 0, 0: glVertex2f 0, 0
                            glTexCoord2f 0, 1: glVertex2f 0, 1
                            glTexCoord2f 1, 1: glVertex2f 1, 1
                            glTexCoord2f 1, 0: glVertex2f 1, 0
                        glEnd
                        
                        'draw texture border
                        If showtex Then glDisable GL_TEXTURE_2D
                        glLineWidth 2
                        glColor3f 0, 0, 0
                        glBegin GL_LINE_STRIP
                            glVertex2f 0, 0
                            glVertex2f 0, 1
                            glVertex2f 1, 1
                            glVertex2f 1, 0
                            glVertex2f 0, 0
                        glEnd
                        If showtex Then glEnable GL_TEXTURE_2D
                        
                        s = .istart
                        v = (.vstart * vmesh.stride) + uvoffset
                        
                        glVertexPointer 2, GL_FLOAT, vmesh.vertstride, ByVal VarPtr(vmesh.vert(v))
                        glTexCoordPointer 2, GL_FLOAT, vmesh.vertstride, ByVal VarPtr(vmesh.vert(v))
                        
                        glEnableClientState GL_VERTEX_ARRAY
                        glEnableClientState GL_TEXTURE_COORD_ARRAY
                            
                            'draw UV faces solid
                            glColor3f 0.95, 0.95, 0.95 'NOTE: slightly darker to show verts/edges on very bright textures
                            glDrawElements GL_TRIANGLES, .inum, GL_UNSIGNED_SHORT, ByVal VarPtr(vmesh.index(s))
                            
                            'draw UV faces wire
                            glDisable GL_TEXTURE_2D
                            StartAALine 1.333
                                'glBlendFunc GL_ALPHA, GL_ONE_MINUS_SRC_COLOR
                                glLineWidth 1.333
                                glColor4f 1, 1, 1, 0.1
                                glPolygonMode GL_FRONT_AND_BACK, GL_LINE
                                glDrawElements GL_TRIANGLES, .inum, GL_UNSIGNED_SHORT, ByVal VarPtr(vmesh.index(s))
                                glPolygonMode GL_FRONT_AND_BACK, GL_FILL
                            EndAALine
                            
                        glDisableClientState GL_VERTEX_ARRAY
                        glDisableClientState GL_TEXTURE_COORD_ARRAY
                    End With
                End If
            End If
                        
        End With
        
        'draw faces
        'glBlendFunc GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA
        'glEnable GL_BLEND
        'glColor4f 1, 1, 0, 0.25
        'For i = 0 To .facenum - 1
        '    If .faceinfo(i).sel Then
        '        glBegin GL_TRIANGLES
        '            glVertex3fv .vert(.index(i * 3 + 2) * .stride + uvoffset)
        '            glVertex3fv .vert(.index(i * 3 + 1) * .stride + uvoffset)
        '            glVertex3fv .vert(.index(i * 3 + 0) * .stride + uvoffset)
        '        glEnd
        '    End If
        'Next i
        'glDisable GL_BLEND
        
        'draw vertices
        SetMaskFlags selgeom, sellod, uvmatsel
        StartAAPoint 4: glBlendFunc GL_ALPHA, GL_ONE_MINUS_SRC_COLOR
        glBegin GL_POINTS
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
                If .vertinfo(i).sel Then
                    glColor3f 1, 0, 0
                Else
                    glColor3f 1, 1, 1
                End If
                glVertex2fv .vert(i * .stride + uvoffset)
            End If
        Next i
        glEnd
        EndAAPoint
        
        'selection transform box
        If selbox Then
            glColor3f 1, 0.5, 0 'orange
            
            glLineWidth 1
            glBegin GL_LINE_STRIP
                glVertex2f selbox_min.x - dpx * 2, selbox_min.y - dpy * 2
                glVertex2f selbox_min.x - dpx * 2, selbox_max.y + dpy * 2
                glVertex2f selbox_max.x + dpx * 2, selbox_max.y + dpy * 2
                glVertex2f selbox_max.x + dpx * 2, selbox_min.y - dpy * 2
                glVertex2f selbox_min.x - dpx * 2, selbox_min.y - dpy * 2
            glEnd
            
            glPointSize 5
            glBegin GL_POINTS
                glVertex2f selbox_min.x - dpx * 2, selbox_min.y - dpy * 2
                glVertex2f selbox_min.x - dpx * 2, selbox_max.y + dpy * 2
                glVertex2f selbox_max.x + dpx * 2, selbox_max.y + dpy * 2
                glVertex2f selbox_max.x + dpx * 2, selbox_min.y - dpy * 2
                glVertex2fv selbox_ctr.x
            glEnd
        End If
        
        'draw selection rectangle
        If sel_vis Then
            glBlendFunc GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA
            glEnable GL_BLEND
            
            'fill
            glColor4f 1, 1, 1, 0.1
            glBegin GL_QUADS
                glVertex2f sel_minx, sel_miny
                glVertex2f sel_minx, sel_maxy
                glVertex2f sel_maxx, sel_maxy
                glVertex2f sel_maxx, sel_miny
            glEnd
            
            'outline
            glLineWidth 1
            glColor4f 1, 1, 1, 0.25
            glBegin GL_LINE_STRIP
                glVertex2f sel_minx + dpx * 2, sel_miny + dpy * 2
                glVertex2f sel_minx + dpx * 2, sel_maxy + dpy * 2
                glVertex2f sel_maxx + dpx * 2, sel_maxy + dpy * 2
                glVertex2f sel_maxx + dpx * 2, sel_miny + dpy * 2
                glVertex2f sel_minx + dpx * 2, sel_miny + dpy * 2
            glEnd
            
            glDisable GL_BLEND
        End If
        
    End With
    
End Sub

'transform
Private Function TFX(ByVal x As Single) As Single
    TFX = (x * zoom) + offx
End Function
Private Function TFY(ByVal y As Single) As Single
    TFY = (y * zoom) + offy
End Function

'inverse transform
Private Function TFXi(ByVal x As Single) As Single
    TFXi = (x - offx) / zoom
End Function
Private Function TFYi(ByVal y As Single) As Single
    TFYi = (y - offy) / zoom
End Function

