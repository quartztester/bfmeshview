Attribute VB_Name = "BF2_Normals"
Option Explicit


'generates weighted normals
Private Sub GenNormalsLOD(ByVal geomid As Long, ByVal lodid As Long)
    With vmesh
        If Not .loadok Then Exit Sub
        
        'allocate arrays
        ReDim norm(0 To .vertnum - 1) As float3 'temp normal array
        
        'accumulate normals
        frmMain.StartProgress .facenum, "Computing normals..."
        Dim i As Long
        For i = 0 To .facenum - 1
            With .faceinfo(i)
                If .geom = geomid And .lod = lodid And Not .bad Then
                    Dim sn1 As Long
                    Dim sn2 As Long
                    Dim sn3 As Long
                    sn1 = vmesh.vertinfo(.v1).sharenorm
                    sn2 = vmesh.vertinfo(.v2).sharenorm
                    sn3 = vmesh.vertinfo(.v3).sharenorm
                    norm(sn1) = AddFloat3(norm(sn1), ScaleFloat3(.n, .area * .angle1))
                    norm(sn2) = AddFloat3(norm(sn2), ScaleFloat3(.n, .area * .angle2))
                    norm(sn3) = AddFloat3(norm(sn3), ScaleFloat3(.n, .area * .angle3))
                End If
            End With
            frmMain.UpdateProgress i
        Next i
        
        'copy shared normals to duplicates
        For i = 0 To .vertnum - 1
            With .vertinfo(i)
                If .geom = geomid And .lod = lodid Then
                    Dim sn As Long
                    sn = vmesh.vertinfo(i).sharenorm
                    If sn <> i Then
                        norm(i) = norm(sn)
                    End If
                End If
            End With
        Next i
        
        'copy normals to BF2 mesh
        For i = 0 To .vertnum - 1
            With .vertinfo(i)
                If .geom = geomid And .lod = lodid Then
                    SetNorm i, Normalize(norm(i))
                End If
            End With
        Next i
        
        'clean up
        Erase norm()
        
        frmMain.EndProgress
    End With
End Sub


'generates weighted tangents
Private Sub GenTangentsLOD(ByVal geomid As Long, ByVal lodid As Long)
    With vmesh
        If Not .loadok Then Exit Sub
        
        'get UV offset (staticmesh tangents are for second UV channel)
        Dim uvoff As Long
        If .isStaticMesh Then
            uvoff = 9
            'uvoff = BF2MeshGetTexcOffset(1)
        Else
            uvoff = 7
            'uvoff = BF2MeshGetTexcOffset(0)
        End If
        
        Dim i As Long
        Dim j As Long
        Dim n As float3
        Dim s As float3
        Dim t As float3
        
        'tangent+bitangent array
        ReDim tanS(0 To .vertnum - 1) As float3
        ReDim tanT(0 To .vertnum - 1) As float3
        
        'compute tangents
        frmMain.StartProgress .facenum, "Computing tangents..."
        For i = 0 To .facenum - 1
            With .faceinfo(i)
                If .geom = geomid And .lod = lodid And Not .bad Then
                    
                    'get vertex positions
                    Dim v1 As float3
                    Dim v2 As float3
                    Dim v3 As float3
                    v1 = GetVert(.v1)
                    v2 = GetVert(.v2)
                    v3 = GetVert(.v3)
                    
                    'get UVs
                    Dim uv1 As float2
                    Dim uv2 As float2
                    Dim uv3 As float2
                    uv1 = GetTexc(uvoff, .v1)
                    uv2 = GetTexc(uvoff, .v2)
                    uv3 = GetTexc(uvoff, .v3)
                    
                    'get shared tangent indices
                    Dim st1 As Long
                    Dim st2 As Long
                    Dim st3 As Long
                    st1 = vmesh.vertinfo(.v1).sharetang
                    st2 = vmesh.vertinfo(.v2).sharetang
                    st3 = vmesh.vertinfo(.v3).sharetang
                    
                    'compute vertex edge vectors
                    Dim x1 As Single
                    Dim x2 As Single
                    Dim y1 As Single
                    Dim y2 As Single
                    Dim z1 As Single
                    Dim z2 As Single
                    x1 = v2.x - v1.x
                    x2 = v3.x - v1.x
                    y1 = v2.y - v1.y
                    y2 = v3.y - v1.y
                    z1 = v2.z - v1.z
                    z2 = v3.z - v1.z
                    
                    'compute U vector
                    Dim s1 As Single
                    Dim s2 As Single
                    s1 = uv2.x - uv1.x
                    s2 = uv3.x - uv1.x
                    
                    'compute V vector
                    Dim t1 As Single
                    Dim t2 As Single
                    t1 = uv2.y - uv1.y
                    t2 = uv3.y - uv1.y
                    
                    '...
                    Dim r As Single
                    Dim d As Single
                    d = (s1 * t2 - s2 * t1)
                    If Abs(d) < EPSILON Then
                        r = 0
                    Else
                        r = 1 / d
                    End If
                    
                    'compute face tangent
                    Dim sdir As float3
                    sdir.x = (t2 * x1 - t1 * x2) * r
                    sdir.y = (t2 * y1 - t1 * y2) * r
                    sdir.z = (t2 * z1 - t1 * z2) * r
                    
                    'compute face bi-tangent
                    Dim tdir As float3
                    tdir.x = (s1 * x2 - s2 * x1) * r
                    tdir.y = (s1 * y2 - s2 * y1) * r
                    tdir.z = (s1 * z2 - s2 * z1) * r
                    
                    ''store face tangent/bitangent
                    'tface(i).tanS = sdir
                    'tface(i).tanT = tdir
                    
                    'accumulate tangent
                    tanS(st1) = AddFloat3(tanS(st1), ScaleFloat3(sdir, .area * .angle1))
                    tanS(st2) = AddFloat3(tanS(st2), ScaleFloat3(sdir, .area * .angle2))
                    tanS(st3) = AddFloat3(tanS(st3), ScaleFloat3(sdir, .area * .angle3))
                    
                    'accumulate bi-tangent
                    tanT(st1) = AddFloat3(tanT(st1), ScaleFloat3(tdir, .area * .angle1))
                    tanT(st2) = AddFloat3(tanT(st2), ScaleFloat3(tdir, .area * .angle2))
                    tanT(st3) = AddFloat3(tanT(st3), ScaleFloat3(tdir, .area * .angle3))
                    
                End If
            End With
            frmMain.UpdateProgress i
        Next i
        frmMain.EndProgress
        
        'copy shared tangents to duplicates
        For i = 0 To .vertnum - 1
            With .vertinfo(i)
                If .geom = geomid And .lod = lodid Then
                    Dim st As Long
                    st = .sharetang
                    If st <> i Then
                        tanS(i) = tanS(st)
                        tanT(i) = tanT(st)
                    End If
                End If
            End With
        Next i
        
        'weld tangents/bitangents
        'NOTE: we do this before normalization, so the weights stored in magnitude of tanS/tanT still count
        If True Then
            frmMain.StartProgress .vertnum, "Welding tangents..."
            Dim p1 As float3
            Dim p2 As float3
            Dim n1 As float3
            Dim n2 As float3
            For i = 0 To .vertnum - 1
                If .vertinfo(i).geom = geomid And .vertinfo(i).lod = lodid Then
                    
                    p1 = GetVert(i)
                    n1 = GetNorm(i)
                    
                    For j = i + 1 To .vertnum - 1
                        If .vertinfo(i).geom = geomid And .vertinfo(i).lod = lodid Then
                            
                            p2 = GetVert(j)
                            n2 = GetVert(j)
                            
                            If Equals(p1, p2) Then
                            If Equals(n1, n2) Then
                                
                                If DotProduct(tanS(i), tanS(j)) > 0.5 Then
                                    s = ScaleFloat3(AddFloat3(tanS(i), tanS(j)), 0.5)
                                    tanS(i) = s
                                    tanS(j) = s
                                End If
                                
                                If DotProduct(tanT(i), tanT(j)) > 0.5 Then
                                    t = ScaleFloat3(AddFloat3(tanT(i), tanT(j)), 0.5)
                                    tanT(i) = t
                                    tanT(j) = t
                                End If
                                
                            End If
                            End If
                            
                        End If
                    Next j
                    
                End If
                frmMain.UpdateProgress i
            Next i
            frmMain.EndProgress
        End If
        
        'normalize tangents
        For i = 0 To .vertnum - 1
            With .vertinfo(i)
                If .geom = geomid And .lod = lodid Then
                    tanS(i) = Normalize(tanS(i))
                    tanT(i) = Normalize(tanT(i))
                End If
            End With
        Next i
        
        'orthogonalize
        frmMain.StartProgress .vertnum, "Ortho-normalizing tangents..."
        For i = 0 To .vertnum - 1
            With .vertinfo(i)
                If .geom = geomid And .lod = lodid Then
                    
                    'get normal
                    n = GetNorm(i)
                    
                    'get tangents
                    s = tanS(i)
                    t = tanT(i)
                    
                    'Gram-Schmidt orthogonalize
                    s = Normalize(SubFloat3(s, ScaleFloat3(n, DotProduct(n, s))))
                    t = Normalize(SubFloat3(t, ScaleFloat3(n, DotProduct(n, t))))
                    
                    'copy to BF2 mesh
                    SetTang i, s
                    
                    'set bfmeshview tangent
                    vmesh.xtan(i).x = s.x
                    vmesh.xtan(i).y = s.y
                    vmesh.xtan(i).z = s.z
                    
                    'calculate handedness
                    If (DotProduct(CrossProduct(n, s), t) > 0) Then
                        vmesh.xtan(i).w = 1
                    Else
                        vmesh.xtan(i).w = -1
                    End If
                    
                End If
            End With
            frmMain.UpdateProgress i
        Next i
        frmMain.EndProgress
        
        'clean up
        Erase tanS()
        Erase tanT()
        
    End With
End Sub


'generates weighted material normals
Public Sub GenWeightedNormals()
    With vmesh
        If Not .loadok Then Exit Sub
        
        'generate geometry info
        GenMeshEditInfo
        
        'recompute in case stuff has changed
        'ComputeFaceGeometry
        'ComputeSharedVertPos
        frmMain.StartProgress 50, "Updating shared vertex normals..."
        ComputeSharedVertNorm 'TODO: write UpdateSharedVertNorm, which uses existing shared positional info?
        frmMain.EndProgress
        'ComputeSharedVertTang
        
        Dim g As Long
        For g = 0 To .geomnum - 1
            Dim l As Long
            For l = 0 To .geom(g).lodnum - 1
                GenNormalsLOD g, l
                GenTangentsLOD g, l
            Next l
        Next g
        
        'fix bad tangents
        BF2FixTangents
        
    End With
End Sub


'--- tools --------------------------------------------------------------------------------------------------------------------------------------------


'find triangle with this vertex and returns face normal
Private Function GetVertFaceNormal(ByVal vi As Long) As float3
    With vmesh
        Dim i As Long
        For i = 0 To .facenum - 1
            With .faceinfo(i)
                If .flag Then
                    
                    If .v1 = vi Then
                        GetVertFaceNormal = .n 'ScaleFloat3(.n, .area * .angle1)
                        Exit Function
                    End If
                    
                    If .v2 = vi Then
                        GetVertFaceNormal = .n 'ScaleFloat3(.n, .area * .angle2)
                        Exit Function
                    End If
                    
                    If .v3 = vi Then
                        GetVertFaceNormal = .n 'ScaleFloat3(.n, .area * .angle3)
                        Exit Function
                    End If
                    
                End If
            End With
        Next i
    End With
    
    'return existing normal
    GetVertFaceNormal = GetNorm(vi)
End Function


'flattens normals of selected vertices
Public Sub FlattenVertNormals()
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                SetNorm i, Normalize(GetVertFaceNormal(i))
            End If
            End If
        Next i
        
    End With
    frmMain.picMain_Paint
End Sub


'flattens normals of selected faces
Public Sub FlattenFaceNormals()
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        
        Dim i As Long
        For i = 0 To .facenum - 1
            With .faceinfo(i)
                If .flag Then
                If .sel Then
                    SetNorm .v1, .n
                    SetNorm .v2, .n
                    SetNorm .v3, .n
                End If
                End If
            End With
        Next i
        
    End With
    frmMain.picMain_Paint
End Sub


'welds normals of selected vertices
Public Sub WeldVertNormals()
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        
        Dim n As float3
        n = float3(0, 0, 0)
        
        'accumulate normal vector
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                n = AddFloat3(n, GetNorm(i))
            End If
            End If
        Next i
        
        'normalize
        n = Normalize(n)
        
        'set normal
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                SetNorm i, n
            End If
            End If
        Next i
        
    End With
    frmMain.picMain_Paint
End Sub


'welds normals of selected faces
Public Sub WeldFaceNormals()
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        
        Dim i As Long
        Dim j As Long
        
        ReDim norm(0 To .vertnum - 1) As float3
        
        'accumulate normal vector
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).facesel Then
                norm(.vertinfo(i).sharepos) = AddFloat3(norm(.vertinfo(i).sharepos), GetNorm(i))
            End If
            End If
        Next i
        
        'normalize
        For i = 0 To .vertnum - 1
            norm(i) = Normalize(norm(i))
        Next i
        
        'set new normals
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).facesel Then
                SetNorm i, Normalize(norm(.vertinfo(i).sharepos))
            End If
            End If
        Next i
        
        'clean up
        Erase norm()
    End With
    frmMain.picMain_Paint
End Sub


'collapses selected vertices
Public Sub CollapseVerts()
Dim i As Long
    With vmesh
        If Not .loadok Then Exit Sub
        UpdateMaskFlags
        
        'determine selected vertex bounds
        Dim bmin As float3
        Dim bmax As float3
        bmin.x = 99999
        bmin.y = 99999
        bmin.z = 99999
        bmax.x = -99999
        bmax.y = -99999
        bmax.z = -99999
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                
                Dim v As float3
                v = GetVert(i)
                
                bmin.x = min(bmin.x, v.x)
                bmin.y = min(bmin.y, v.y)
                bmin.z = min(bmin.z, v.z)
                
                bmax.x = max(bmax.x, v.x)
                bmax.y = max(bmax.y, v.y)
                bmax.z = max(bmax.z, v.z)
                
            End If
            End If
        Next i
        
        'compute selection center
        Dim c As float3
        c.x = (bmin.x + bmax.x) * 0.5
        c.y = (bmin.y + bmax.y) * 0.5
        c.z = (bmin.z + bmax.z) * 0.5
        
        'collapse vertices
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
            If .vertinfo(i).sel Then
                SetVert i, c
            End If
            End If
        Next i
        
    End With
    frmMain.picMain_Paint
End Sub
