Attribute VB_Name = "BF2_Edit"
Option Explicit


'selects all faces with currently selected material
Public Sub SelectByMaterial(ByVal matid As Long)
    With vmesh
        If Not .loadok Then Exit Sub
        If Not IsValidLod(selgeom, sellod) Then Exit Sub
        If Not edit_mesh Then Exit Sub
        
        UpdateMaskFlags
        
        With .geom(selgeom).lod(sellod)
            Dim i As Long
            
            'verts
            If selmode = sel_vert Then
                ClearVertSelection
                For i = .vertStart To .vertEnd
                    If vmesh.vertinfo(i).mat = matid Then vmesh.vertinfo(i).sel = True
                Next i
            End If
            
            'faces
            If selmode >= sel_face Then
                ClearFaceSelection
                For i = .faceStart To .faceEnd
                    'If vmesh.faceinfo(i).mat = matid Then vmesh.faceinfo(i).sel = True
                    If vmesh.faceinfo(i).mat = matid Then SetFaceSelection i, 1
                Next i
            End If
            
        End With
    End With
End Sub


'selects all vertices with bad tangent vectors
Public Sub SelectBadTangents()
    With vmesh
        If Not .loadok Then Exit Sub
        If Not IsValidLod(selgeom, sellod) Then Exit Sub
        If Not edit_mesh Then Exit Sub
        
        UpdateMaskFlags
        
        With .geom(selgeom).lod(sellod)
            Dim i As Long
            
            'verts
            If selmode = sel_vert Then
                ClearVertSelection
                For i = .vertStart To .vertEnd
                    If Magnitude(GetTang(i)) < 0.5 Then vmesh.vertinfo(i).sel = True
                Next i
            End If
            
            'faces
            If selmode >= sel_face Then
                ClearFaceSelection
                For i = .faceStart To .faceEnd
                    If Magnitude(GetTang(vmesh.faceinfo(i).v1)) < 0.5 Then vmesh.faceinfo(i).sel = True
                    If Magnitude(GetTang(vmesh.faceinfo(i).v2)) < 0.5 Then vmesh.faceinfo(i).sel = True
                    If Magnitude(GetTang(vmesh.faceinfo(i).v3)) < 0.5 Then vmesh.faceinfo(i).sel = True
                Next i
            End If
            
        End With
    End With
End Sub


'repairs tangent vector
Private Sub BF2FixTangent(ByVal i As Long)
    With vmesh
        Dim n As float3
        n = GetNorm(i)
        
        'supply arbitrary tangent
        Dim t As float3
        If n.y > 0.99 Then
            t = float3(1, 0, 0)
        Else
            t = float3(0, 1, 0)
        End If
        
        'orthogonalize
        t = Normalize(CrossProduct(n, t))
        
        'set tangent
        SetTang i, t
        .xtan(i).x = t.x
        .xtan(i).y = t.y
        .xtan(i).z = t.z
        .xtan(i).w = 1
    End With
End Sub


'fixes zero'd tangent vectors
Public Sub BF2FixTangents()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim i As Long
        'For i = 0 To .facenum - 1
        '
        '    With .faceinfo(i)
        '
        '        If Magnitude(GetTang(.v1)) < 0.5 Then
        '
        '
        '
        '        End If
        '
        '    End With
        '
        'Next i
        
        For i = 0 To .vertnum - 1
            If Magnitude(GetTang(i)) < 0.5 Then BF2FixTangent i
        Next i
        
    End With
End Sub
