Attribute VB_Name = "BF2_MeshInfo"
Option Explicit

Public Const NORMTHRESHOLD As Single = 0.99
Public Const TANGTHRESHOLD As Single = 0.5


'generates mesh static face/vertex info (always available)
Public Sub GenMeshInfo()
    With vmesh
        
        'internal stuff
        ReDim .vertinfo(0 To .vertnum - 1)
        ReDim .faceinfo(0 To .facenum - 1)
        .editinfo = False
        
        'generate info
        Dim g As Long
        For g = 0 To .geomnum - 1
            With .geom(g)
                Dim l As Long
                For l = 0 To .lodnum - 1
                    With .lod(l)
                        
                        Dim m As Long
                        For m = 0 To .matnum - 1
                            With .mat(m)
                                
                                'set vertex range
                                .vertStart = .vstart
                                .vertEnd = .vstart + .vnum - 1
                                
                                'set face range
                                .faceStart = (.istart / 3)
                                .faceEnd = (.istart / 3) + (.inum / 3) - 1
                                
                                'set vertex info
                                Dim i As Long
                                For i = .vertStart To .vertEnd
                                    vmesh.vertinfo(i).geom = g
                                    vmesh.vertinfo(i).lod = l
                                    vmesh.vertinfo(i).mat = m
                                    vmesh.vertinfo(i).sel = 0
                                    vmesh.vertinfo(i).flag = 0
                                    vmesh.vertinfo(i).facesel = 0
                                Next i
                                
                                'set face info
                                For i = 0 To .facenum - 1
                                    Dim f As Long
                                    f = (.istart / 3) + i
                                    vmesh.faceinfo(f).geom = g
                                    vmesh.faceinfo(f).lod = l
                                    vmesh.faceinfo(f).mat = m
                                    vmesh.faceinfo(f).sel = 0
                                    vmesh.faceinfo(f).flag = 0
                                    vmesh.faceinfo(f).bad = 0
                                    vmesh.faceinfo(f).v1 = .vstart + vmesh.index(.istart + i * 3 + 0)
                                    vmesh.faceinfo(f).v2 = .vstart + vmesh.index(.istart + i * 3 + 1)
                                    vmesh.faceinfo(f).v3 = .vstart + vmesh.index(.istart + i * 3 + 2)
                                    vmesh.faceinfo(f).mathash = .hash
                                Next i
                                
                                ''update LOD vert range
                                'If .vertStart < vmesh.geom(g).lod(L).vertStart Then vmesh.geom(g).lod(L).vertStart = .vertStart
                                'If .vertEnd > vmesh.geom(g).lod(L).vertEnd Then vmesh.geom(g).lod(L).vertEnd = .vertEnd
                                
                                ''update LOD face range
                                'If .faceStart < vmesh.geom(g).lod(L).faceStart Then vmesh.geom(g).lod(L).faceStart = .faceStart
                                'If .faceEnd > vmesh.geom(g).lod(L).faceEnd Then vmesh.geom(g).lod(L).faceEnd = .faceEnd
                                
                            End With
                        Next m
                        
                        'set vert/face range
                        If .matnum > 0 Then
                            .vertStart = .mat(0).vertStart
                            .faceStart = .mat(0).faceStart
                            .vertEnd = .mat(.matnum - 1).vertEnd
                            .faceEnd = .mat(.matnum - 1).faceEnd
                        Else
                            .vertStart = 0
                            .faceStart = 0
                            .vertEnd = 0
                            .faceEnd = 0
                        End If
                        
                    End With
                Next l
            End With
        Next g
        
    End With
End Sub


'computes info before editing
Public Sub GenMeshEditInfo()
    If vmesh.editinfo Then Exit Sub
    
    Dim str As String
    Dim t1 As Long
    Dim t2 As Long
    
    'fix NaNs to prevent further issues
    t1 = timeGetTime
    BF2FixNans
    t2 = timeGetTime
    str = str & "BF2FixNans: " & (t2 - t1) & vbLf
    
    'compute face info
    t1 = timeGetTime
    ComputeFaceGeometry
    t2 = timeGetTime
    str = str & "ComputeFaceGeometry: " & (t2 - t1) & vbLf
    
    'compute shared vertices
    t1 = timeGetTime
    ComputeSharedVertInfo
    t2 = timeGetTime
    str = str & "ComputeSharedVertInfo: " & (t2 - t1) & vbLf
    
    'compute polygons & elements
    t1 = timeGetTime
    ComputeFacePolygons
    t2 = timeGetTime
    str = str & "ComputeFacePolygons: " & (t2 - t1) & vbLf
    
    'MsgBox str
    
    vmesh.editinfo = True
End Sub


'computes shared vertex positions
Public Sub ComputeSharedVertPos()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim i As Long
        Dim j As Long
        
        Dim p1 As float3
        Dim p2 As float3
        
        Dim g As Long
        Dim l As Long
       
        For g = 0 To .geomnum - 1
            For l = 0 To .geom(g).lodnum - 1
                With .geom(g).lod(l)
                    
                    For i = .vertStart To .vertEnd
                        p1 = GetVert(i)
                        vmesh.vertinfo(i).sharepos = i
                        For j = .vertStart To i - 1
                            p2 = GetVert(j)
                            If Equals(p1, p2) Then
                                vmesh.vertinfo(i).sharepos = j
                                Exit For
                            End If
                        Next j
                    Next i
                    
                End With
            Next l
        Next g
        
    End With
End Sub


'computes shared vertex positions
Public Sub ComputeSharedVertNorm()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim i As Long
        Dim j As Long
        
        Dim p1 As float3
        Dim p2 As float3
        Dim n1 As float3
        Dim n2 As float3
        
        Dim g As Long
        Dim l As Long
        
        For g = 0 To .geomnum - 1
            For l = 0 To .geom(g).lodnum - 1
                With .geom(g).lod(l)
                    For i = .vertStart To .vertEnd
                        p1 = GetVert(i)
                        n1 = GetNorm(i)
                        vmesh.vertinfo(i).sharenorm = i
                        For j = .vertStart To i - 1
                            p2 = GetVert(j)
                            If Equals(p1, p2) Then
                            
                            n2 = GetNorm(j)
                            If DotProduct(n1, n2) > NORMTHRESHOLD Then
                                vmesh.vertinfo(i).sharenorm = j
                                Exit For
                            End If
                            End If
                        Next j
                    Next i
                End With
            Next l
        Next g
    End With
End Sub


'computes shared vertex positions
Public Sub ComputeSharedVertTang()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim i As Long
        Dim j As Long
        
        Dim p1 As float3
        Dim p2 As float3
        Dim n1 As float3
        Dim n2 As float3
        Dim t1 As float3
        Dim t2 As float3
        Dim Q1 As float3
        Dim Q2 As float3
        
        Dim g As Long
        Dim l As Long
        
        For g = 0 To .geomnum - 1
            For l = 0 To .geom(g).lodnum - 1
                With .geom(g).lod(l)
                    
                    For i = .vertStart To .vertEnd
                        p1 = GetVert(i)
                        n1 = GetNorm(i)
                        t1 = GetTang(i)
                        Q1 = ScaleFloat3(CrossProduct(n1, t1), vmesh.xtan(i).w)
                        
                        vmesh.vertinfo(i).sharetang = i
                        For j = .vertStart To i - 1
                            p2 = GetVert(j)
                            If Equals(p1, p2) Then
                            
                            n2 = GetNorm(j)
                            If DotProduct(n1, n2) > NORMTHRESHOLD Then
                            
                            t2 = GetTang(j)
                            If DotProduct(t1, t2) > TANGTHRESHOLD Then
                            
                            Q2 = ScaleFloat3(CrossProduct(n2, t2), vmesh.xtan(j).w)
                            If DotProduct(Q1, Q2) > TANGTHRESHOLD Then
                                vmesh.vertinfo(i).sharetang = j
                                Exit For
                            End If
                            End If
                            End If
                            End If
                            
                        Next j
                    Next i
                    
                End With
            Next l
        Next g
    End With
End Sub


'computes shared vertex positions
Public Sub ComputeSharedVertInfo()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim i As Long
        Dim j As Long
        
        Dim p1 As float3
        Dim p2 As float3
        Dim n1 As float3
        Dim n2 As float3
        Dim t1 As float3
        Dim t2 As float3
        Dim Q1 As float3
        Dim Q2 As float3
        
        Dim found_pos As Boolean
        Dim found_norm As Boolean
        Dim found_tang As Boolean
        
        Dim g As Long
        Dim l As Long
        
        For g = 0 To .geomnum - 1
            For l = 0 To .geom(g).lodnum - 1
                With .geom(g).lod(l)
                    
                    frmMain.StartProgress (.vertEnd - .vertStart - 1), "Computing shared vertices..."
                    For i = .vertStart To .vertEnd
                        
                        found_pos = False
                        found_norm = False
                        found_tang = False
                        
                        p1 = GetVert(i)
                        n1 = GetNorm(i)
                        t1 = GetTang(i)
                        Q1 = ScaleFloat3(CrossProduct(n1, t1), vmesh.xtan(i).w)
                        
                        vmesh.vertinfo(i).sharepos = i
                        vmesh.vertinfo(i).sharenorm = i
                        vmesh.vertinfo(i).sharetang = i
                        For j = .vertStart To i - 1
                        
                            'compate position
                            p2 = GetVert(j)
                            If Equals(p1, p2) Then
                                If Not found_pos Then
                                    vmesh.vertinfo(i).sharepos = j
                                    found_pos = True
                                End If
                                
                                'compare normal
                                n2 = GetNorm(j)
                                If DotProduct(n1, n2) > NORMTHRESHOLD Then
                                    If Not found_norm Then
                                        vmesh.vertinfo(i).sharenorm = j
                                        found_norm = True
                                    End If
                                    
                                    'compare tangent
                                    t2 = GetTang(j)
                                    If DotProduct(t1, t2) > TANGTHRESHOLD Then
                                        
                                        'compare bi-tangent
                                        Q2 = ScaleFloat3(CrossProduct(n2, t2), vmesh.xtan(j).w)
                                        If DotProduct(Q1, Q2) > TANGTHRESHOLD Then
                                            If Not found_tang Then
                                                vmesh.vertinfo(i).sharetang = j
                                                found_tang = True
                                            End If
                                            
                                            'found everything
                                            If found_pos And found_norm And found_tang Then Exit For
                                        End If
                                        
                                    End If
                                End If
                            End If
                            
                        Next j
                        
                        frmMain.UpdateProgress (i - .vertStart)
                    Next i
                    frmMain.EndProgress
                    
                End With
            Next l
        Next g
    End With
End Sub


'computes face surface area and corner angles
Public Sub ComputeFaceGeometry()
    With vmesh
        If Not .loadok Then Exit Sub
        
        frmMain.StartProgress .facenum, "Pre-computing geometry metadata..."
        
        Dim i As Long
        For i = 0 To .facenum - 1
            With .faceinfo(i)
                
                'get vertex positions
                Dim v1 As float3
                Dim v2 As float3
                Dim v3 As float3
                v1 = GetVert(.v1)
                v2 = GetVert(.v2)
                v3 = GetVert(.v3)
                
                'generate normal
                .n = GenNormal(v3, v2, v1)
                
                'compute face area
                .area = TriangleArea(v1, v2, v3)
                
                'compute corner angles
                .angle1 = AngleBetweenVectors(SubFloat3(v2, v1), SubFloat3(v3, v1))
                .angle2 = AngleBetweenVectors(SubFloat3(v2, v1), SubFloat3(v2, v3))
                .angle3 = AngleBetweenVectors(SubFloat3(v3, v2), SubFloat3(v3, v1))
                
                'check for NaNs
                .bad = 0
                If IsNaN3f(.n) Then .bad = 1
                If IsNaN(.area) Then .bad = 1
                If IsNaN(.angle1) Then .bad = 1
                If IsNaN(.angle2) Then .bad = 1
                If IsNaN(.angle3) Then .bad = 1
                
            End With
            frmMain.UpdateProgress i
        Next i
        
        frmMain.EndProgress
        
    End With
End Sub


'--- polygons -------------------------------------------------------------------------------------------------


'sets face polygon ID
Private Function TagFacePoly(ByVal face As Long, ByVal polyID As Long) As Boolean
    With vmesh.faceinfo(face)
        
        'already set
        If .poly <> -1 Then Exit Function
        
        'set polygon ID
        .poly = polyID
        
        'set for neighbors
        Const ang As Single = 0.99
        If .f1 <> -1 Then
            If DotProduct(.n, vmesh.faceinfo(.f1).n) > ang Then TagFacePoly .f1, polyID
        End If
        If .f2 <> -1 Then
            If DotProduct(.n, vmesh.faceinfo(.f2).n) > ang Then TagFacePoly .f2, polyID
        End If
        If .f3 <> -1 Then
            If DotProduct(.n, vmesh.faceinfo(.f3).n) > ang Then TagFacePoly .f3, polyID
        End If
        
    End With
    TagFacePoly = True
End Function


'sets vertex element ID
Private Sub TagVertElem(ByVal vert As Long, ByVal elemID As Long)
    With vmesh.vertinfo(vert)
        .elem = elemID
        
        'tag all faces touching this vertex
        'TODO: allows spreading to pieces touching only by one vertex
        
    End With
End Sub


'sets face element ID
Private Function TagFaceElem(ByVal face As Long, ByVal elemID As Long) As Boolean
    With vmesh.faceinfo(face)
        
        'already set
        If .elem <> -1 Then Exit Function
        
        'set polygon ID
        .elem = elemID
        
        'set for neighbors
        If .f1 <> -1 Then TagFaceElem .f1, elemID
        If .f2 <> -1 Then TagFaceElem .f2, elemID
        If .f3 <> -1 Then TagFaceElem .f3, elemID
        
        'set verts
        TagVertElem .v1, elemID
        TagVertElem .v2, elemID
        TagVertElem .v3, elemID
        
    End With
    TagFaceElem = True
End Function


'computes face polygon indices
Public Sub ComputeFacePolygons()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim i As Long
        Dim j As Long
        
        Dim v1 As Boolean
        Dim v2 As Boolean
        Dim v3 As Boolean
        
        'clear vertex info
        For i = 0 To .vertnum - 1
            .vertinfo(i).elem = -1
        Next i
        
        'clear face info
        For i = 0 To .facenum - 1
            .faceinfo(i).poly = -1
            .faceinfo(i).elem = -1
            .faceinfo(i).f1 = -1
            .faceinfo(i).f2 = -1
            .faceinfo(i).f3 = -1
        Next i
        
        'find neighbors
        Dim g As Long
        Dim l As Long
        For g = 0 To .geomnum - 1
            frmMain.StartProgress .geom(g).lodnum, "Pre-computing geometry metadata..."
            For l = 0 To .geom(g).lodnum - 1
                For i = .geom(g).lod(l).faceStart To .geom(g).lod(l).faceEnd
                    
                    'find neighbors
                    For j = .geom(g).lod(l).faceStart To .geom(g).lod(l).faceEnd
                        If i <> j Then
                            
                            v1 = False
                            v2 = False
                            v3 = False
                            
                            If .vertinfo(.faceinfo(i).v1).sharepos = .vertinfo(.faceinfo(j).v1).sharepos Then v1 = True
                            If .vertinfo(.faceinfo(i).v1).sharepos = .vertinfo(.faceinfo(j).v2).sharepos Then v1 = True
                            If .vertinfo(.faceinfo(i).v1).sharepos = .vertinfo(.faceinfo(j).v3).sharepos Then v1 = True
                            
                            If .vertinfo(.faceinfo(i).v2).sharepos = .vertinfo(.faceinfo(j).v1).sharepos Then v2 = True
                            If .vertinfo(.faceinfo(i).v2).sharepos = .vertinfo(.faceinfo(j).v2).sharepos Then v2 = True
                            If .vertinfo(.faceinfo(i).v2).sharepos = .vertinfo(.faceinfo(j).v3).sharepos Then v2 = True
                            
                            If .vertinfo(.faceinfo(i).v3).sharepos = .vertinfo(.faceinfo(j).v1).sharepos Then v3 = True
                            If .vertinfo(.faceinfo(i).v3).sharepos = .vertinfo(.faceinfo(j).v2).sharepos Then v3 = True
                            If .vertinfo(.faceinfo(i).v3).sharepos = .vertinfo(.faceinfo(j).v3).sharepos Then v3 = True
                            
                            If v1 And v2 Then .faceinfo(i).f1 = j
                            If v2 And v3 Then .faceinfo(i).f2 = j
                            If v3 And v1 Then .faceinfo(i).f3 = j
                            
                        End If
                    Next j
                Next i
                frmMain.UpdateProgress l
            Next l
            frmMain.EndProgress
        Next g
        
        'build polygons
        Dim polyID As Long
        polyID = 1
        For i = 0 To .facenum - 1
            If TagFacePoly(i, polyID) Then polyID = polyID + 1
        Next i
        .polynum = polyID 'note: may be 1 larger than actual?
        Erase .polyinfo()
        ReDim .polyinfo(0 To .polynum - 1)
        
        'build elements
        Dim elemID As Long
        elemID = 1
        For i = 0 To .facenum - 1
            If TagFaceElem(i, elemID) Then elemID = elemID + 1
        Next i
        .elemnum = elemID 'note: may be 1 larger than actual?
        Erase .eleminfo()
        ReDim .eleminfo(0 To .elemnum - 1)
        
    End With
End Sub

