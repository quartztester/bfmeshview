VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmFix 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Fix Faces"
   ClientHeight    =   3735
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   3495
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmFix.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   249
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   233
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.Frame fraMatch 
      Caption         =   "Matching Treshold"
      Height          =   2145
      Left            =   75
      TabIndex        =   9
      Top             =   1230
      Width           =   1935
      Begin VB.CheckBox chkMatchSel 
         Caption         =   "Match Selection"
         Height          =   255
         Left            =   120
         TabIndex        =   16
         Top             =   1440
         Width           =   1455
      End
      Begin VB.CheckBox chkMatchMat 
         Caption         =   "Match Material"
         Height          =   255
         Left            =   120
         TabIndex        =   15
         Top             =   1080
         Value           =   1  'Checked
         Width           =   1455
      End
      Begin VB.CheckBox chkOldMethod 
         Caption         =   "Old Method"
         Height          =   255
         Left            =   120
         TabIndex        =   14
         Top             =   1800
         Width           =   1215
      End
      Begin VB.TextBox txtAngle 
         Alignment       =   2  'Center
         Height          =   285
         Left            =   1080
         TabIndex        =   13
         Text            =   "0.5"
         Top             =   660
         Width           =   735
      End
      Begin VB.TextBox txtDistance 
         Alignment       =   2  'Center
         Height          =   285
         Left            =   1080
         TabIndex        =   11
         Text            =   "0.1"
         Top             =   300
         Width           =   735
      End
      Begin VB.Label labMatch 
         AutoSize        =   -1  'True
         Caption         =   "Angle:"
         Height          =   195
         Index           =   1
         Left            =   120
         TabIndex        =   12
         Top             =   690
         Width           =   465
      End
      Begin VB.Label labMatch 
         AutoSize        =   -1  'True
         Caption         =   "Distance:"
         Height          =   195
         Index           =   0
         Left            =   120
         TabIndex        =   10
         Top             =   330
         Width           =   675
      End
   End
   Begin ComctlLib.StatusBar stsStatus 
      Align           =   2  'Align Bottom
      Height          =   285
      Left            =   0
      TabIndex        =   8
      Top             =   3450
      Width           =   3495
      _ExtentX        =   6165
      _ExtentY        =   503
      Style           =   1
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   1
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Frame fraSource 
      Caption         =   "Source"
      Height          =   1125
      Left            =   75
      TabIndex        =   5
      Top             =   60
      Width           =   1935
      Begin VB.ComboBox cbbLod 
         Height          =   315
         Left            =   120
         Style           =   2  'Dropdown List
         TabIndex        =   7
         Top             =   660
         Width           =   1695
      End
      Begin VB.ComboBox cbbGeom 
         Height          =   315
         Left            =   120
         Style           =   2  'Dropdown List
         TabIndex        =   6
         Top             =   240
         Width           =   1695
      End
   End
   Begin VB.CommandButton cmdFixUV 
      Caption         =   "Copy UV4"
      Height          =   375
      Index           =   3
      Left            =   2160
      TabIndex        =   4
      Top             =   1560
      Width           =   1215
   End
   Begin VB.CommandButton cmdFixUV 
      Caption         =   "Copy UV3"
      Height          =   375
      Index           =   2
      Left            =   2160
      TabIndex        =   3
      Top             =   1080
      Width           =   1215
   End
   Begin VB.CommandButton cmdFixUV 
      Caption         =   "Copy UV2"
      Height          =   375
      Index           =   1
      Left            =   2160
      TabIndex        =   2
      Top             =   600
      Width           =   1215
   End
   Begin VB.CommandButton cmdFixNormal 
      Caption         =   "Copy Normals"
      Height          =   375
      Left            =   2160
      TabIndex        =   1
      Top             =   2040
      Width           =   1215
   End
   Begin VB.CommandButton cmdFixUV 
      Caption         =   "Copy UV1"
      Height          =   375
      Index           =   0
      Left            =   2160
      TabIndex        =   0
      Top             =   120
      Width           =   1215
   End
End
Attribute VB_Name = "frmFix"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private distThreshold As Single
Private areaTreshold As Single
Private angleThreshold As Single
Private matchMat As Boolean
Private matchSel As Boolean
Private oldMethod As Boolean


Private Sub Form_Load()
    Me.stsStatus.SimpleText = "Press To Fix..."
    SetTopMostWindow Me.hWnd, True
End Sub

Private Sub Form_GotFocus()
    'SetTopMostWindow Me.hWnd, True
End Sub

Private Sub cbbGeom_Change()
    FillLodList
End Sub

Private Sub cmdFixUV_Click(index As Integer)
    'If selmode = sel_vert Then FixVertUVs Index
    If selmode >= sel_face Then FixFaceUVs index
End Sub

Private Sub cmdFixNormal_Click()
    'If selmode = sel_vert Then FixVertNormals
    If selmode >= sel_face Then FixFaceNormals
End Sub

Public Sub OnShow()
    FillGeomList
    FillLodList
End Sub

'fills GEOM list
Public Sub FillGeomList()
    Me.cbbGeom.Clear
    If vmesh.loadok Then
        Dim i As Long
        For i = 0 To vmesh.geomnum - 1
            Me.cbbGeom.AddItem "GEOM " & i
        Next i
        Me.cbbGeom.ListIndex = 0
    End If
End Sub

'fills LOD list
Public Sub FillLodList()
    Me.cbbLod.Clear
    If vmesh.loadok Then
        Dim geomid As Long
        geomid = Me.cbbGeom.ListIndex
        If IsValidGeom(geomid) Then
            Dim i As Long
            For i = 0 To vmesh.geom(geomid).lodnum - 1
                Me.cbbLod.AddItem "LOD " & i
            Next i
            Me.cbbLod.ListIndex = 0
        End If
    End If
End Sub

'retrieves treshold constant from textbox
Private Sub UpdateTreshold()
    distThreshold = val(Me.txtDistance.Text)
    areaTreshold = 0.5
    angleThreshold = val(Me.txtAngle.Text)
    matchMat = (Me.chkMatchMat.value = vbChecked)
    matchSel = (Me.chkMatchSel.value = vbChecked)
    oldMethod = (Me.chkOldMethod.value = vbChecked)
End Sub

'-------------------------------------------------------------------------------------------------------------------------------------------------------

'returns minimum distance
Private Function GetClosestVert(ByVal vi1 As Long, ByVal vi2 As Long, ByVal vi3 As Long, ByVal vi As Long, ByRef dist As Single) As Long
    Dim v As float3
    v = GetVert(vi)
    
    Dim v1 As float3
    Dim v2 As float3
    Dim v3 As float3
    v1 = GetVert(vi1)
    v2 = GetVert(vi2)
    v3 = GetVert(vi3)
    
    Dim d As Single
    Dim dmin As Single
    Dim closest As Long
    
    dmin = Distance(v, v1)
    closest = vi1
    
    d = Distance(v, v2)
    If d < dmin Then
        dmin = d
        closest = vi2
    End If
    
    d = Distance(v, v3)
    If d < dmin Then
        dmin = d
        closest = vi3
    End If
    
    dist = dmin
    GetClosestVert = closest
End Function

'returns minimum distance
Private Function MinDist(ByRef p As float3, ByRef v1 As float3, ByRef v2 As float3, ByRef v3 As float3) As Single
    Dim d As Single
    Dim dmin As Single
    dmin = Distance(p, v1)
    
    d = Distance(p, v2)
    If d < dmin Then dmin = d
    
    d = Distance(p, v3)
    If d < dmin Then dmin = d
    
    MinDist = dmin
End Function


'effectively returns if two faces overlap
Private Function MatchingVerts(ByRef v1 As float3, ByRef v2 As float3, ByRef v3 As float3, _
                               ByRef fv1 As float3, ByRef fv2 As float3, ByRef fv3 As float3) As Long
    Dim n As Long
    Dim dmin As Single
    
    'v1
    dmin = MinDist(v1, fv1, fv2, fv3)
    If dmin < distThreshold Then n = n + 1
    
    'v2
    dmin = MinDist(v2, fv1, fv2, fv3)
    If dmin < distThreshold Then n = n + 1
    
    'v3
    dmin = MinDist(v3, fv1, fv2, fv3)
    If dmin < distThreshold Then n = n + 1
    
    MatchingVerts = n
End Function


'computes ratio of B for A
Private Function AreaRatio(ByVal a As Single, b As Single) As Single
    AreaRatio = 1 - (a / (a + b))
End Function


'finds face that matches closest
Private Function FindClosestFace(ByVal geomid As Long, ByVal lodid As Long, ByVal f As Long) As Long
    With vmesh.geom(geomid).lod(lodid)
        
        'TODO: find by 3d overlap; project face B to face A plane, compute overlap ratio, pick face largest ratio)
        'TODO: easier improvement; find by AABB overlap ratio
        'TODO: easier improvement; add dmin1, dmin2, dmin3 etc and all match only if all three are < threshold
        
        'get face info
        Dim m As Long
        Dim a As Single
        Dim n As float3
        Dim v1 As float3
        Dim v2 As float3
        Dim v3 As float3
        m = vmesh.faceinfo(f).mathash
        a = vmesh.faceinfo(f).area
        n = vmesh.faceinfo(f).n
        v1 = GetVert(vmesh.faceinfo(f).v1)
        v2 = GetVert(vmesh.faceinfo(f).v2)
        v3 = GetVert(vmesh.faceinfo(f).v3)
        
        Dim bestFace As Long
        bestFace = -1
        
        Dim dmin As Single
        dmin = 999999
        
        'find closest matching source face
        Dim i As Long
        For i = .faceStart To .faceEnd
            With vmesh.faceinfo(i)
                
                'skip bad faces
                If .bad Then GoTo nextface
                
                'skip very small faces
                If .area < 0.00001 Then GoTo nextface
                
                'skip very thin triangles
                If .angle1 < 0.001 Then GoTo nextface
                If .angle2 < 0.001 Then GoTo nextface
                If .angle3 < 0.001 Then GoTo nextface
                
                'only faces with matching material
                If matchMat Then
                    If .mathash <> m Then GoTo nextface
                End If
                
                'only selected source faces
                If matchSel Then
                    If .sel = 0 Then GoTo nextface
                End If
                
                'skip if area differs too much
                'If AreaRatio(a, .area) > areaTreshold Then GoTo nextface
                'If Abs(a / (a - .area)) < 0.9 Then GoTo nextface
                
                'skip face if normals diverge too much
                Dim ndot As Single
                ndot = DotProduct(n, .n)
                If ndot < angleThreshold Then GoTo nextface
                
                'use
                Dim d1 As Single
                Dim d2 As Single
                Dim d3 As Single
                d1 = Distance(v1, GetVert(.v1))
                d2 = Distance(v2, GetVert(.v2))
                d3 = Distance(v3, GetVert(.v3))
                
                'If d1 > dmin1 Then GoTo nextface
                'If d2 > dmin2 Then GoTo nextface
                'If d3 > dmin3 Then GoTo nextface
                
                Dim d As Single
                d = max(d1, max(d2, d3))
                
                If d < dmin Then
                    dmin = d
                    bestFace = i
                End If
                
nextface:
            End With
        Next i
        
        'found something
        If bestFace <> -1 Then
            If dmin < distThreshold Then
                FindClosestFace = bestFace
                Exit Function
            End If
        End If
        
    End With
    FindClosestFace = -1
End Function


'finds vertex that matches closest
Private Function FindClosestVert(ByVal geomid As Long, ByVal lodid As Long, ByRef f As Long, ByVal vi As Long) As Long
    With vmesh.geom(geomid).lod(lodid)
        
        'get destination face material hash
        Dim m As Long
        m = vmesh.faceinfo(f).mathash
        
        'get destination face normal
        Dim n As float3
        n = vmesh.faceinfo(f).n
        
        'get destination face vertex positions
        Dim fv1 As float3
        Dim fv2 As float3
        Dim fv3 As float3
        fv1 = GetVert(vmesh.faceinfo(f).v1)
        fv2 = GetVert(vmesh.faceinfo(f).v2)
        fv3 = GetVert(vmesh.faceinfo(f).v3)
        
        'get destination vertex position
        Dim v As float3
        If vi = 1 Then v = fv1
        If vi = 2 Then v = fv2
        If vi = 3 Then v = fv3
        
        'index of closest match
        Dim bestVert As Long
        bestVert = -1
        
        'distance to closest match
        Dim dmin As Single
        dmin = 99999
        
        'search source LOD for closest matching vert
        Dim i As Long
        For i = .faceStart To .faceEnd
            With vmesh.faceinfo(i)
                
                'skip bad faces
                If .bad Then GoTo nextface
                
                'skip very small faces
                If .area < 0.00001 Then GoTo nextface
                
                'skip very thin triangles
                If .angle1 < 0.001 Then GoTo nextface
                If .angle2 < 0.001 Then GoTo nextface
                If .angle3 < 0.001 Then GoTo nextface
                
                'only faces with matching material
                If matchMat Then
                    If .mathash <> m Then GoTo nextface
                End If
                
                'only selected source faces
                If matchSel Then
                    If .sel = 0 Then GoTo nextface
                End If
                
                'skip face if normals diverge too much
                Dim ndot As Single
                ndot = DotProduct(n, .n)
                If ndot < angleThreshold Then GoTo nextface
                
                'get source face vertices
                Dim v1 As float3
                Dim v2 As float3
                Dim v3 As float3
                v1 = GetVert(.v1)
                v2 = GetVert(.v2)
                v3 = GetVert(.v3)
                
                'measure distances to destination vertex
                Dim d1 As Single
                Dim d2 As Single
                Dim d3 As Single
                d1 = Distance(v, v1)
                d2 = Distance(v, v2)
                d3 = Distance(v, v3)
                
                'check if this face has at least two matching vertices
                'If SimilarFaces(v1, v2, v3, fv1, fv2, fv3) Then
                If MatchingVerts(v1, v2, v3, fv1, fv2, fv3) = 3 Then
                    
                    'find closest matching vertex
                    If d1 < dmin Then
                        dmin = d1
                        bestVert = .v1
                    End If
                    
                    If d2 < dmin Then
                        dmin = d2
                        bestVert = .v2
                    End If
                    
                    If d3 < dmin Then
                        dmin = d3
                        bestVert = .v3
                    End If
                    
                End If
nextface:
            End With
        Next i
        
        'returns best candidate if matching criteria
        If bestVert <> -1 Then
            If dmin < distThreshold Then
                FindClosestVert = bestVert
                Exit Function
            End If
        End If
        
    End With
    FindClosestVert = -1
End Function


'copies UVs of selected faces from another LOD
Private Sub FixFaceUVs(ByVal chan As Long)
    UpdateTreshold
    
    Dim srcGeom As Long
    Dim srcLod As Long
    srcGeom = Me.cbbGeom.ListIndex
    srcLod = Me.cbbLod.ListIndex
    If Not IsValidLod(selgeom, sellod) Then Exit Sub
    If Not IsValidLod(srcGeom, srcLod) Then Exit Sub
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        
        Dim texcoff As Long
        texcoff = BF2MeshGetTexcOffset(chan)
        
        Dim n As Long
        Dim n_total As Long
        With .geom(selgeom).lod(sellod)
            Dim i As Long
            For i = .faceStart To .faceEnd
                With vmesh.faceinfo(i)
                    If .sel Then
                        
                        If oldMethod Then
                            
                            Dim f As Long
                            f = FindClosestFace(srcGeom, srcLod, i) 'note: will not fix vertices if face not found
                            If f <> -1 Then
                                
                                'note: this is wrong if vertex order is different (really?)
                                SetTexc texcoff, .v1, GetTexc(texcoff, vmesh.faceinfo(f).v1)
                                SetTexc texcoff, .v2, GetTexc(texcoff, vmesh.faceinfo(f).v2)
                                SetTexc texcoff, .v3, GetTexc(texcoff, vmesh.faceinfo(f).v3)
                                
                                'note: this *should* be correct
                                'Dim dummy As Single
                                'SetTexc texcoff, .v1, GetTexc(texcoff, GetClosestVert(.v1, .v2, .v3, vmesh.faceinfo(f).v1, dummy))
                                'SetTexc texcoff, .v2, GetTexc(texcoff, GetClosestVert(.v1, .v2, .v3, vmesh.faceinfo(f).v2, dummy))
                                'SetTexc texcoff, .v3, GetTexc(texcoff, GetClosestVert(.v1, .v2, .v3, vmesh.faceinfo(f).v3, dummy))
                                
                                n = n + 1
                            End If
                            n_total = n_total + 1
                            
                        Else
                            
                            'new method
                            Dim v1 As Long
                            Dim v2 As Long
                            Dim v3 As Long
                            v1 = FindClosestVert(srcGeom, srcLod, i, 1)
                            v2 = FindClosestVert(srcGeom, srcLod, i, 2)
                            v3 = FindClosestVert(srcGeom, srcLod, i, 3)
                            If v1 <> -1 Then
                                SetTexc texcoff, .v1, GetTexc(texcoff, v1)
                                n = n + 1
                            End If
                            If v2 <> -1 Then
                                SetTexc texcoff, .v2, GetTexc(texcoff, v2)
                                n = n + 1
                            End If
                            If v3 <> -1 Then
                                SetTexc texcoff, .v3, GetTexc(texcoff, v3)
                                n = n + 1
                            End If
                            n_total = n_total + 3
                            
                        End If
                        
                    End If
                End With
            Next i
        End With
    End With
    If oldMethod Then
        Me.stsStatus.SimpleText = "Fixed " & n & " of " & n_total & " faces."
    Else
        Me.stsStatus.SimpleText = "Fixed " & n & " of " & n_total & " vertices."
    End If
    RedrawViewports
End Sub


'copies normals of selected faces from another LOD
Private Sub FixFaceNormals()
    UpdateTreshold

    Dim srcGeom As Long
    Dim srcLod As Long
    srcGeom = Me.cbbGeom.ListIndex
    srcLod = Me.cbbLod.ListIndex
    If Not IsValidLod(selgeom, sellod) Then Exit Sub
    If Not IsValidLod(srcGeom, srcLod) Then Exit Sub
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim n As Long
        Dim n_total As Long
        With .geom(selgeom).lod(sellod)
            Dim i As Long
            For i = .faceStart To .faceEnd
                With vmesh.faceinfo(i)
                    If .sel Then
                        
                        Dim f As Long
                        f = FindClosestFace(srcGeom, srcLod, i)
                        If f <> -1 Then
                            SetNorm .v1, GetNorm(vmesh.faceinfo(f).v1)
                            SetNorm .v2, GetNorm(vmesh.faceinfo(f).v2)
                            SetNorm .v3, GetNorm(vmesh.faceinfo(f).v3)
                            n = n + 1
                        End If
                        
                        n_total = n_total + 1
                    End If
                End With
            Next i
        End With
    End With
    Me.stsStatus.SimpleText = "Fixed " & n & " of " & n_total & " faces."
    RedrawViewports
End Sub
