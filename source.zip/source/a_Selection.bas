Attribute VB_Name = "a_Selection"
Option Explicit

Public Enum selmodes
    sel_vert = 0
    sel_edge
    sel_face
    sel_poly
    sel_elem
End Enum

Public edit_mesh As Boolean         'mesh editing mode
Public toolmode As Long             '0=view, 1=select
Public selmode As selmodes          'selection primitive
Public selinside As Boolean         'selected primitive must be entirely inside in order to be selected
Public selbackface As Boolean       'select front and backfaces (true), or only front faces (false)
Public mouse_hitpos2d As float3     'screen space hit position
Public mouse_hitpos3d As float3     'world space hit position
Public pickmatmode As Boolean       'material picking mode

Public keyctrl As Boolean           'key states of all forms
Public keyalt As Boolean
Public keyshift As Boolean

Private modelmatrix(15) As GLdouble
Private projmatrix(15) As GLdouble
Private viewport(3) As GLint


'updates matrices
Public Sub GetProjectionInfo()
    glGetDoublev GL_MODELVIEW_MATRIX, modelmatrix(0)
    glGetDoublev GL_PROJECTION_MATRIX, projmatrix(0)
    glGetIntegerv GL_VIEWPORT, viewport(0)
End Sub


'projects world space position to screen coordinate
'NOTE: p.z  0=nearplane, 1=farplane, negative is behind nearplane
Public Function Project(ByRef pos As float3) As float3
Dim winx As GLdouble
Dim winy As GLdouble
Dim winz As GLdouble
    gluProject pos.x, pos.y, pos.z, _
               modelmatrix(0), projmatrix(0), viewport(0), _
               winx, winy, winz
    Project.x = winx
    Project.y = viewport(3) - winy
    Project.z = 1 - winz
End Function


'unprojects screen space (pixels) position to world space
Public Function Unproject(ByRef pos As float3) As float3
Dim objx As GLdouble
Dim objy As GLdouble
Dim objz As GLdouble
    gluUnProject pos.x, viewport(3) - pos.y, pos.z, modelmatrix(0), projmatrix(0), viewport(0), objx, objy, objz
    Unproject.x = objx
    Unproject.y = objy
    Unproject.z = objz
End Function


'unprojects screen space (float) position to world space
Public Function Unproject2(ByRef pos As float3) As float3
Dim objx As GLdouble
Dim objy As GLdouble
Dim objz As GLdouble
Dim vp(3) As GLint
    vp(0) = 0
    vp(1) = 0
    vp(2) = 1
    vp(3) = 1
    gluUnProject pos.x, vp(3) - pos.y, pos.z, modelmatrix(0), projmatrix(0), vp(0), objx, objy, objz
    Unproject2.x = objx
    Unproject2.y = objy
    Unproject2.z = objz
End Function

'--- VERTICES ------------------------------------------------------------------------------------------------------------------

'projects vertices to screen space
Private Sub BF2ProjectVerts()
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
                .vertinfo(i).sv = Project(GetVertTF(i))
            End If
        Next i
    End With
End Sub


'tests screen space vertex against rectangle
Private Function VertTest(ByVal minx As Single, ByVal miny As Single, ByVal maxx As Single, ByVal maxy As Single, ByRef p As float3) As Boolean
    If p.z > 0 Then
        
        If p.x >= minx Then
            If p.x <= maxx Then
                If p.y >= miny Then
                    If p.y <= maxy Then
                        VertTest = True
                    End If
                End If
            End If
        End If
        
    End If
End Function


'selects vertices
Public Sub BF2SelectVerts(ByVal minx As Single, ByVal miny As Single, ByVal maxx As Single, ByVal maxy As Single)
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        BF2ProjectVerts
        
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then
                
                'clear vert selection
                If Not keyctrl And Not keyalt Then
                    .vertinfo(i).sel = 0
                End If
                
                'select/deselect vert
                If VertTest(minx, miny, maxx, maxy, .vertinfo(i).sv) Then
                    If keyalt Then
                        .vertinfo(i).sel = 0
                    Else
                        .vertinfo(i).sel = 1
                    End If
                End If
                
            End If
        Next i
        
    End With
End Sub

'--- FACES --------------------------------------------------------------------------------------------------------------------

'finds closest face under screen coordinate
Public Function PickFace(ByVal x As Single, y As Single) As Long
    With vmesh
        If Not .loadok Then
            PickFace = -1
            Exit Function
        End If
        
        BF2ProjectVerts
        
        Dim mpos As float2
        mpos = float2(x, y)
        
        'unproject mouse position to world space
        Dim mpos3d As float3
        mpos3d = Unproject(float3(x, y, 0))
        
        'compute world space mouse ray direction
        Dim mdir3d As float3
        mdir3d = Normalize(SubFloat3(Unproject(float3(x, y, 1)), mpos3d))
        
        'hit
        Dim hit As Long
        Dim hitz As Single
        hit = -1
        hitz = 99999
        
        Dim i As Long
        For i = 0 To .facenum - 1
            If .faceinfo(i).flag Then
                
                'get screen space vertices
                Dim v1 As float3
                Dim v2 As float3
                Dim v3 As float3
                v1 = .vertinfo(.faceinfo(i).v1).sv
                v2 = .vertinfo(.faceinfo(i).v2).sv
                v3 = .vertinfo(.faceinfo(i).v3).sv
                
                'check if inside triangle
                If TriangleTestF3CW(v1, v2, v3, mpos) Then
                    
                    'compute hit position
                    'Dim d1 As Single
                    'Dim d2 As Single
                    'Dim d3 As Single
                    'd1 = Distance2d(float2(v1.X, v1.Y), mpos)
                    'd2 = Distance2d(float2(v2.X, v2.Y), mpos)
                    'd3 = Distance2d(float2(v3.X, v3.Y), mpos)
                    
                    'Dim p As float3
                    'p = AddFloat3(ScaleFloat3(v1, d1), AddFloat3(ScaleFloat3(v2, d2), ScaleFloat3(v3, d3)))
                    
                    'Dim z As Single
                    'z = v1.z * d1 + v2.z * d2 + v3.z * d3
                    'p = float3(mpos.X, mpos.Y, z)
                    
                    'get world space verts
                    v1 = GetVertTF(.faceinfo(i).v1)
                    v2 = GetVertTF(.faceinfo(i).v2)
                    v3 = GetVertTF(.faceinfo(i).v3)
                    
                    'get face normal
                    Dim n As float3
                    n = GenNormal(v1, v2, v3)
                    
                    'construct plane
                    Dim p As float4
                    p = MakePlane(n, v1)
                    
                    'compute distance to plane
                    Dim d As Single
                    d = RayPlaneDist(mpos3d, mdir3d, p)
                    
                    'check if closer
                    If d > 0 And d < hitz Then
                        hit = i
                        hitz = d
                        mouse_hitpos3d = AddFloat3(mpos3d, ScaleFloat3(mdir3d, d))
                    End If
                    
                End If
                
            End If
        Next i
    End With
    PickFace = hit
End Function


'sets face selection state
Public Sub SetFaceSelection(ByVal f As Long, ByVal state As Byte)
    With vmesh
        'set face selection flag
        .faceinfo(f).sel = state
        
        'set face vertices selection flags
        .vertinfo(.faceinfo(f).v1).facesel = state
        .vertinfo(.faceinfo(f).v2).facesel = state
        .vertinfo(.faceinfo(f).v3).facesel = state
    End With
End Sub


Private Function ToggleSelState(ByVal s As Byte)
    If s = 0 Then
        ToggleSelState = 1
    Else
        ToggleSelState = 0
    End If
End Function


'selects single face
Public Sub BF2SelectFace(ByVal x As Single, y As Single)
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        
        Dim f As Long
        f = PickFace(x, y)
        
        'clear selection
        If Not keyctrl And Not keyalt Then
            ClearFaceSelection
        End If
        
        'select
        If f <> -1 Then
            SetFaceSelection f, ToggleSelState(.faceinfo(f).sel)
        End If
        
    End With
End Sub


'selects polygon
Public Sub BF2SelectPoly(ByVal x As Single, y As Single)
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        
        'select face
        Dim f As Long
        f = PickFace(x, y)
        
        'clear selection
        If Not keyctrl And Not keyalt Then
            ClearFaceSelection
        End If
        
        'select
        If f <> -1 Then
            
            Dim state As Byte
            state = ToggleSelState(.faceinfo(f).sel)
            
            'get polygon ID
            Dim polyID As Long
            polyID = .faceinfo(f).poly
            
            'set selection of all faces with face polygon ID
            Dim i As Long
            For i = 0 To .facenum - 1
                With .faceinfo(i)
                    If .flag Then
                        If .poly = polyID Then
                            SetFaceSelection i, state
                        End If
                    End If
                End With
            Next i
            
        End If
        
    End With
End Sub


'selects element
Public Sub BF2SelectElem(ByVal x As Single, y As Single)
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        
        'select face
        Dim f As Long
        f = PickFace(x, y)
        
        'clear selection
        If Not keyctrl And Not keyalt Then
            ClearFaceSelection
        End If
        
        'select
        If f <> -1 Then
            
            Dim state As Byte
            state = ToggleSelState(.faceinfo(f).sel)
            
            'get polygon ID
            Dim elemID As Long
            elemID = .faceinfo(f).elem
            
            'set selection of all faces with face element ID
            Dim i As Long
            For i = 0 To .facenum - 1
                With .faceinfo(i)
                    If .flag Then
                        If .elem = elemID Then
                            SetFaceSelection i, state
                        End If
                    End If
                End With
            Next i
            
        End If
        
    End With
End Sub


'area-selects faces
Public Sub BF2SelectFaces(ByVal minx As Single, ByVal miny As Single, ByVal maxx As Single, ByVal maxy As Single)
    With vmesh
        If Not .loadok Then Exit Sub
        
        UpdateMaskFlags
        BF2ProjectVerts
        
        Dim i As Long
        For i = 0 To .facenum - 1
            If .faceinfo(i).flag Then
                
                'clear vert selection
                If Not keyctrl And Not keyalt Then
                    .faceinfo(i).sel = 0
                End If
                
                'get screen space vertices
                Dim v1 As float3
                Dim v2 As float3
                Dim v3 As float3
                v1 = .vertinfo(.faceinfo(i).v1).sv
                v2 = .vertinfo(.faceinfo(i).v2).sv
                v3 = .vertinfo(.faceinfo(i).v3).sv
                
                'skip if behind nearplane
                If v1.z < 0 Then GoTo nextface
                If v2.z < 0 Then GoTo nextface
                If v3.z < 0 Then GoTo nextface
                
                'ignore backfacing
                If Not selbackface Then
                    Dim n As float3
                    n = GenNormal(v3, v2, v1)
                    If n.z < 0 Then GoTo nextface
                End If
                
                'vert tests
                Dim b1 As Boolean
                Dim b2 As Boolean
                Dim b3 As Boolean
                b1 = VertTest(minx, miny, maxx, maxy, v1)
                b2 = VertTest(minx, miny, maxx, maxy, v2)
                b3 = VertTest(minx, miny, maxx, maxy, v3)
                
                'overlap test
                Dim hit As Boolean
                If selinside Then
                    hit = (b1 And b2 And b3) 'all vertices inside rectangle
                Else
                    hit = (b1 Or b2 Or b3) 'one vertex inside
                    
                    'rectangle corners inside face
                    If Not hit Then hit = TriangleTestF3CW(v1, v2, v3, float2(minx, miny))
                    If Not hit Then hit = TriangleTestF3CW(v1, v2, v3, float2(minx, maxy))
                    If Not hit Then hit = TriangleTestF3CW(v1, v2, v3, float2(maxx, miny))
                    If Not hit Then hit = TriangleTestF3CW(v1, v2, v3, float2(maxx, maxy))
                    
                    'rectangle vs face edge tests
                    If Not hit Then hit = LineRectTest(minx, miny, maxx, maxy, v1, v2)
                    If Not hit Then hit = LineRectTest(minx, miny, maxx, maxy, v2, v3)
                    If Not hit Then hit = LineRectTest(minx, miny, maxx, maxy, v3, v1)
                End If
                
                'select
                If hit Then
                    If keyalt Then
                        SetFaceSelection i, 0
                    Else
                        SetFaceSelection i, 1
                    End If
                End If
                
            End If
nextface:
        Next i
    End With
End Sub


'area-selects polygons
Public Sub BF2SelectPolys(ByVal minx As Single, ByVal miny As Single, ByVal maxx As Single, ByVal maxy As Single)
    With vmesh
        If Not .loadok Then Exit Sub
        If .polynum = 0 Then Exit Sub
        
        UpdateMaskFlags
        
        'select faces
        BF2SelectFaces minx, miny, maxx, maxy
        
        'clear polygon selection flags
        Dim i As Long
        For i = 0 To .polynum - 1
            .polyinfo(i).sel = 0
        Next i
        
        'set polygon selection flags
        For i = 0 To .facenum - 1
            If .faceinfo(i).flag And .faceinfo(i).sel Then
                .polyinfo(.faceinfo(i).poly - 1).sel = True
            End If
        Next i
        
        'set face selection based on poly selection flags
        For i = 0 To .facenum - 1
            If .faceinfo(i).flag Then
                .faceinfo(i).sel = .polyinfo(.faceinfo(i).poly - 1).sel
            End If
        Next i
    End With
End Sub


'area-selects elements
Public Sub BF2SelectElems(ByVal minx As Single, ByVal miny As Single, ByVal maxx As Single, ByVal maxy As Single)
    With vmesh
        If Not .loadok Then Exit Sub
        If .elemnum = 0 Then Exit Sub
        
        'select faces
        BF2SelectFaces minx, miny, maxx, maxy
        
        'clear element selection flags
        Dim i As Long
        For i = 0 To .elemnum - 1
            .eleminfo(i).sel = 0
        Next i
        
        'set element selection flags
        For i = 0 To .facenum - 1
            If .faceinfo(i).flag And .faceinfo(i).sel Then
                .eleminfo(.faceinfo(i).elem - 1).sel = True
            End If
        Next i
        
        'set face selection based on element selection flags
        For i = 0 To .facenum - 1
            If .faceinfo(i).flag Then
                .faceinfo(i).sel = .eleminfo(.faceinfo(i).elem - 1).sel
            End If
        Next i
    End With
End Sub


'selects all vertices of selected faces
Public Sub SelectFaceVertices()
    With vmesh
        UpdateMaskFlags
        ClearVertSelection 'NOTE: don't optimize this away, unselected shared vertices may become deselected again!
        Dim i As Long
        For i = 0 To .facenum - 1
            If .faceinfo(i).flag Then
            If .faceinfo(i).sel Then
                .vertinfo(.faceinfo(i).v1).sel = True
                .vertinfo(.faceinfo(i).v2).sel = True
                .vertinfo(.faceinfo(i).v3).sel = True
            End If
            End If
        Next i
    End With
End Sub


'clears vertex selection for all geoms+lods
Public Sub ClearVertSelection()
    With vmesh
        If Not .loadok Then Exit Sub
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then .vertinfo(i).sel = 0
        Next i
    End With
End Sub


'clears face selection for all geoms+lods
Public Sub ClearFaceSelection()
    With vmesh
        If Not .loadok Then Exit Sub
        Dim i As Long
        For i = 0 To .vertnum - 1
            If .vertinfo(i).flag Then .vertinfo(i).facesel = 0
        Next i
        For i = 0 To .facenum - 1
            If .faceinfo(i).flag Then .faceinfo(i).sel = 0
        Next i
    End With
End Sub


'clears selection
Public Sub ClearSelection()
    ClearVertSelection
    ClearFaceSelection
End Sub


'selects all vertices/faces
Public Sub SelectAll()
    With vmesh
        If Not .loadok Then Exit Sub
        Dim i As Long
        If selmode = sel_vert Then
            For i = 0 To .vertnum - 1
                With .vertinfo(i)
                    If .geom = selgeom And .lod = sellod Then
                        .sel = True
                    Else
                        .sel = False
                    End If
                End With
            Next i
        End If
        If selmode >= sel_face Then
            For i = 0 To .facenum - 1
                With .faceinfo(i)
                    If .geom = selgeom And .lod = sellod Then
                        SetFaceSelection i, 1
                    Else
                        SetFaceSelection i, 0
                    End If
                End With
            Next i
        End If
    End With
End Sub


'inverts selection
Public Sub SelectInvert()
    With vmesh
        If Not .loadok Then Exit Sub
        Dim i As Long
        If selmode = sel_vert Then
            For i = 0 To .vertnum - 1
                With .vertinfo(i)
                    If .geom = selgeom And .lod = sellod Then
                        .sel = ToggleSelState(.sel)
                    End If
                End With
            Next i
        End If
        If selmode >= sel_face Then
            For i = 0 To .facenum - 1
                With .faceinfo(i)
                    If .geom = selgeom And .lod = sellod Then
                        SetFaceSelection i, ToggleSelState(.sel)
                    End If
                End With
            Next i
        End If
    End With
End Sub


'sets flags of currently selected geom+lod
Public Sub UpdateMaskFlags()
    SetMaskFlags selgeom, sellod, -1
End Sub


'sets the vertex+face flags of the currently selected geom+lod+mat
Public Sub SetMaskFlags(ByRef geomid As Long, ByRef lodid As Long, ByVal matid As Long)
    On Error GoTo errhandler
    
    With vmesh
        If Not .loadok Then Exit Sub
        
        Dim i As Long
        
        'set vert flags
        For i = 0 To .vertnum - 1
            With .vertinfo(i)
                
                'clear flag
                .flag = 0
                
                'set flag if match
                If .geom = geomid Then
                    If .lod = lodid Then
                        If matid < 0 Then
                            .flag = 1
                        Else
                            If .mat = matid Then
                                .flag = 1
                            End If
                        End If
                    End If
                End If
            End With
        Next i
        
        'set face flags
        For i = 0 To .facenum - 1
            With .faceinfo(i)
            
                'clear flag
                .flag = 0
                
                'set flag if match
                If .geom = geomid Then
                    If .lod = lodid Then
                        If matid < 0 Then
                            .flag = 1
                        Else
                            If .mat = matid Then
                                .flag = 1
                            End If
                        End If
                    End If
                End If
            End With
        Next i
        
    End With
    
    Exit Sub
errhandler:
    'MsgBox "SetMaskFlags Error: " & err.description, vbCritical
    On Error GoTo 0
End Sub

