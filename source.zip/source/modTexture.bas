Attribute VB_Name = "a_Texture"
Option Explicit

Public TEMP_texmap_width As Long
Public TEMP_texmap_height As Long


Private Type byte4
    r As Byte
    g As Byte
    b As Byte
    a As Byte
End Type


'texture array
Private Type texmap_type
    filename As String          '...
    origrelfilename As String   '...
    filesize As Long            'filesize in bytes
    width As Long               'width in pixels
    height As Long              'height in pixels
    asp As Single               'size aspect ratio
    tex As GLuint               'GL texture object
End Type
Public texmapnum As Long
Public texmap() As texmap_type

'dummy textures
Public dummytexcolor As GLuint
Public dummytexbump As GLuint


'loads texture from file
Public Function LoadTexture(ByVal filename As String, ByVal origrelfilename As String) As Long
    
    'ignore specular LUT
    If Not opt_loadspeclut Then
        If InStr(filename, "SpecularLUT") Then
            Exit Function
        End If
    End If
    
    'you wouldn't believe how badly Windows handles slashes
    filename = Replace(filename, "/", "\")
    
    'check to see if already loaded
    Dim i As Long
    For i = 1 To texmapnum
        If texmap(i).filename = filename Then
            LoadTexture = i
            Exit Function
        End If
    Next i
    
    SetStatus "info", "Loading " & filename
    
    'add new texture
    texmapnum = texmapnum + 1
    ReDim Preserve texmap(1 To texmapnum)
    
    With texmap(texmapnum)
        
        'load texture file
        Dim ext As String
        ext = LCase(GetFileExt(filename))
        Select Case ext
        Case "tga": .tex = LoadTGA(filename)
        Case "dds": .tex = LoadDDS(filename)
        End Select
        
        'set properties
        .filename = filename
        .origrelfilename = origrelfilename
        .filesize = GetFileSize(filename)
        .width = TEMP_texmap_width
        .height = TEMP_texmap_height
    End With
    
    'success
    LoadTexture = texmapnum
End Function


'returns texture map aspect ratio
Public Function GetTexMapAspect(ByVal index As Long) As Single
    If index < 1 Or index > texmapnum Then
        GetTexMapAspect = 1
        Exit Function
    End If
    With texmap(index)
        If .width * .height > 0 Then
            GetTexMapAspect = .width / .height
        Else
            GetTexMapAspect = 1
        End If
    End With
End Function


'returns filename string of texture to be loaded, or nothing if not found
Private Function BF2GetTexFileName(ByRef fname As String) As String
    Dim tmp As String
    
    'first try suffixed
    If suffix_sel > 0 Then
        tmp = Replace(ByVal fname, ".dds", "_" & suffix(suffix_sel) & ".dds")
        If FileExist(tmp) Then fname = tmp
    End If
    
    'try source file
    If opt_texoverride Then
        tmp = Replace(ByVal fname, ".dds", ".tga")
        If FileExist(tmp) Then fname = tmp
    End If
    
    'try non-suffixed
    If FileExist(fname) Then
        BF2GetTexFileName = fname
        Exit Function
    End If
    
    'we ain't found shit
    BF2GetTexFileName = ""
End Function


'returns true if map is bump map
Public Function IsBumpMap(ByRef mapfile As String) As Boolean
    If InString(mapfile, "_b.") Then IsBumpMap = True
    If InString(mapfile, "_n.") Then IsBumpMap = True
    If InString(mapfile, "_b_") Then IsBumpMap = True
    If InString(mapfile, "_n_") Then IsBumpMap = True
    If InString(mapfile, "_deb.") Then IsBumpMap = True
    If InString(mapfile, "_crb.") Then IsBumpMap = True
    If InString(mapfile, "_deb_") Then IsBumpMap = True
    If InString(mapfile, "_crb_") Then IsBumpMap = True
End Function


'loads all mesh textures
Public Sub LoadMeshTextures()
    On Error GoTo errorhandler
    
Dim i As Long
Dim j As Long
Dim k As Long
Dim m As Long
Dim p As Long

Dim fname As String
Dim fpath As String
Dim mapfile As String
Dim filename As String
    
    'unload existing textures
    UnloadMeshTextures
    
    'BF2 mesh
    With vmesh
        If .loadok Then
            
            Dim meshfilepath As String
            meshfilepath = GetFilePath(vmesh.filename)
            
            For i = 0 To .geomnum - 1
                For j = 0 To .geom(i).lodnum - 1
                    For k = 0 To .geom(i).lod(j).matnum - 1
                        
                        'try to load all maps
                        For m = 0 To .geom(i).lod(j).mat(k).mapnum - 1
                            
                            'clear texmapid
                            .geom(i).lod(j).mat(k).texmapid(m) = 0
                            
                            'get map filename
                            mapfile = .geom(i).lod(j).mat(k).map(m)
                            
                            'blow up if absolute path
                            If InStr(1, mapfile, ":", vbTextCompare) Then
                                Echo "WARNING: bad file path: " & Chr(34) & mapfile & Chr(34) & "!" & vbCrLf
                                mapfile = ""
                            End If
                            
                            'blow up if network path
                            If Left(mapfile, 2) = "\\" Then
                                Echo "WARNING: bad file path: " & Chr(34) & mapfile & Chr(34) & "!" & vbCrLf
                                mapfile = ""
                            End If
                            
                            If Len(mapfile) > 0 Then
                                
                                'determine if map is bump map (used to select proper dummy texture if file missing)
                                .geom(i).lod(j).mat(k).IsBumpMap(m) = IsBumpMap(mapfile)
                                'If .geom(i).lod(j).mat(k).IsBumpMap(m) Then Echo "!!! " & mapfile & " is a bump map!"
                                
                                'reset path
                                filename = ""
                                
                                'try path relative to mesh file
                                If opt_uselocaltexpath Then
                                    
                                  '  'try mesh path first
                                  '  fname = meshfilepath & GetFileName(mapfile)
                                  '  If BF2TexFileExist(fname) Then filename = fname
                                    
                                  '  'try texture path
                                  '  If Len(filename) = 0 Then
                                  '      fname = meshfilepath & "..\Textures\" & GetFileName(mapfile)
                                  '      If BF2TexFileExist(fname) Then filename = fname
                                  '  End If
                                    
                                    'try current mesh path
                                    filename = BF2GetTexFileName(meshfilepath & GetFileName(mapfile))
                                    
                                    'try asset texture path
                                    If Len(filename) = 0 Then
                                        filename = BF2GetTexFileName(meshfilepath & "..\Textures\" & GetFileName(mapfile))
                                    End If
                                    
                                End If
                                
                                'try all of the texture folders
                                If Len(filename) = 0 Then
                                    fname = GetFileName(mapfile)
                                    For p = 1 To texpathnum
                                        If texpath(p).use Then
                                            
                                            'texpath+path+filename
                                            filename = BF2GetTexFileName(texpath(p).path & "\" & mapfile)
                                            If Len(filename) > 0 Then Exit For
                                            
                                            'texpath+filename
                                            If Len(filename) = 0 Then
                                                filename = BF2GetTexFileName(texpath(p).path & "\" & fname)
                                                If Len(filename) > 0 Then Exit For
                                            End If
                                            
                                        End If
                                    Next p
                                End If
                                
                                'load texture
                                If Len(filename) > 0 Then
                                
                                    .geom(i).lod(j).mat(k).texmapid(m) = LoadTexture(filename, mapfile)
                                    
                                    BuildShader .geom(i).lod(j).mat(k), vmesh.filename
                                    
                                Else
                                    Echo "Texture " & Chr(34) & mapfile & Chr(34) & " not loaded!" & vbCrLf
                                End If
                                
                            End If
                            
                        Next m
                    
                    Next k
                Next j
            Next i
            
        End If
    End With
    
    'bf1942 standard mesh
    With stdmesh
        If .loadok And stdshader.loaded Then
            
            For i = 1 To stdshader.subshader_num
                With stdshader.subshader(i)
                    For p = 1 To texpathnum
                        If texpath(p).use Then
                            
                            fname = texpath(p).path & "\" & .texture & ".dds"
                            If FileExist(fname) Then
                                .texmapid = LoadTexture(fname, "")
                            End If
                            
                            fname = texpath(p).path & "\" & .texture & ".tga"
                            If FileExist(fname) Then
                                .texmapid = LoadTexture(fname, "")
                            End If
                            
                        End If
                    Next p
                End With
            Next i
            
        End If
    End With
    
    
    'bf1942 tree mesh
    With treemesh
        If .loadok Then
            
            For i = 0 To .meshnum - 1
                With .mesh(i)
                    For j = 0 To .matnum - 1
                        With .mat(j)
                            For p = 1 To texpathnum
                                If texpath(p).use Then
                                    
                                    fname = texpath(p).path & "\" & .texname & ".dds"
                                    If FileExist(fname) Then
                                        .texmapid = LoadTexture(fname, "")
                                    End If
                                    
                                End If
                            Next p
                        End With
                    Next j
                End With
            Next i
            
        End If
    End With
    
    
    Exit Sub
errorhandler:
    MsgBox "LoadMeshTextures" & vbLf & err.description, vbCritical
End Sub


'unloads all mesh textures
Public Sub UnloadMeshTextures()
Dim i As Long
    For i = 1 To texmapnum
        texmap(i).filename = ""
        If texmap(i).tex <> 0 Then
            glDeleteTextures 1, texmap(i).tex
            texmap(i).tex = 0
        End If
    Next i
    Erase texmap()
    texmapnum = 0
End Sub


Public Sub BindTexture(ByVal id As Long)
    If id < 1 Or id > texmapnum Then
        UnbindTexture
        Exit Sub
    End If
    glBindTexture GL_TEXTURE_2D, texmap(id).tex
    glEnable GL_TEXTURE_2D
    glDisable GL_TEXTURE_CUBE_MAP
End Sub
Public Sub UnbindTexture()
    glBindTexture GL_TEXTURE_2D, 0
    glDisable GL_TEXTURE_2D
    glDisable GL_TEXTURE_CUBE_MAP
End Sub


'...
Public Function GetTextureMemory() As String
Dim total As Long
Dim i As Long
    For i = 1 To texmapnum
        total = total + texmap(i).filesize
    Next i
    GetTextureMemory = FormatFileSize(total)
End Function


'returns texture filename on disk
Public Function BF2GetTextureFilename(ByVal geo As Long, ByVal lod As Long, ByVal mat As Long, ByVal tex As Long) As String
    On Error GoTo errhandler
    
    If Not vmesh.loadok Then Exit Function
    If geo < 0 Then Exit Function
    If lod < 0 Then Exit Function
    If mat < 0 Then Exit Function
    If tex < 0 Then Exit Function
    
    If geo > vmesh.geomnum - 1 Then Exit Function
    If lod > vmesh.geom(geo).lodnum - 1 Then Exit Function
    If mat > vmesh.geom(geo).lod(lod).matnum - 1 Then Exit Function
    If tex > vmesh.geom(geo).lod(lod).mat(mat).mapnum - 1 Then Exit Function
    
    Dim texmapid As Long
    texmapid = vmesh.geom(geo).lod(lod).mat(mat).texmapid(tex)
    If texmapid > 0 Then
        BF2GetTextureFilename = texmap(texmapid).filename
    End If
    
    Exit Function
errhandler:
    MsgBox "BF2GetTextureFilename" & vbLf & err.description, vbCritical
End Function


'returns texture filename on disk
Public Function BF2GetMapFilename(ByVal geo As Long, ByVal lod As Long, ByVal mat As Long, ByVal tex As Long) As String
    On Error GoTo errhandler
    
    If Not vmesh.loadok Then Exit Function
    If geo < 0 Then Exit Function
    If lod < 0 Then Exit Function
    If mat < 0 Then Exit Function
    If tex < 0 Then Exit Function
    
    If geo > vmesh.geomnum - 1 Then Exit Function
    If lod > vmesh.geom(geo).lodnum - 1 Then Exit Function
    If mat > vmesh.geom(geo).lod(lod).matnum - 1 Then Exit Function
    If tex > vmesh.geom(geo).lod(lod).mat(mat).mapnum - 1 Then Exit Function
    
    BF2GetMapFilename = vmesh.geom(geo).lod(lod).mat(mat).map(tex)
    
    Exit Function
errhandler:
    MsgBox "BF2GetMapFilename" & vbLf & err.description, vbCritical
End Function


Public Function GenTexture(ByVal r As Byte, ByVal g As Byte, ByVal b As Byte, ByVal a As Byte) As GLuint
    Dim tex As GLuint
    Dim pix(3) As Byte
    pix(0) = r
    pix(1) = g
    pix(2) = b
    pix(3) = a
    glGenTextures 1, tex
    glBindTexture GL_TEXTURE_2D, tex
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
    glTexImage2D GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, ByVal VarPtr(pix(0))
    glBindTexture GL_TEXTURE_2D, 0
    GenTexture = tex
End Function

'byte4 constructor
Public Function byte4(ByVal r As Byte, ByVal g As Byte, ByVal b As Byte, ByVal a As Byte) As byte4
    byte4.r = r
    byte4.g = g
    byte4.b = b
    byte4.a = a
End Function

Private Function IsEven(ByVal v As Long) As Boolean
    If v = 0 Then Exit Function
    IsEven = (val(v) Mod 2) = 0
End Function


'generates dummy color map
Public Sub GenDummyTexColor()
    Dim w As Long
    Dim h As Long
    w = 512
    h = 512
    Dim size As Long
    size = w * h
    Dim data() As byte4
    ReDim data(0 To size - 1)
    Dim red As byte4
    Dim yellow As byte4
    red = byte4(255, 50, 50, 255)
    yellow = byte4(255, 200, 50, 255)
    Dim x As Long
    Dim y As Long
    For y = 0 To h - 1
        For x = 0 To w - 1
            Dim i As Long
            i = x + w * y
            If IsEven(CLng(x \ 8) + CLng(y \ 8)) Then
                data(i) = red
            Else
                data(i) = yellow
            End If
        Next x
    Next y
    
    'create texture
    Dim handle As GLuint
    glGenTextures 1, handle
    glBindTexture GL_TEXTURE_2D, handle
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
    glTexParameterf GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, maxaniso
    glTexParameteri GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE
    gluBuild2DMipmaps GL_TEXTURE_2D, GL_RGBA, w, h, GL_RGBA, GL_UNSIGNED_BYTE, ByVal VarPtr(data(0).r)
    glBindTexture GL_TEXTURE_2D, 0
    
    Erase data()
    
    dummytexcolor = handle
End Sub


'generates dummy normal map (tangent space)
Public Sub GenDummyTexBump()
    Dim data(0) As byte4
    data(0) = byte4(127, 127, 255, 255)
    
    'create texture
    Dim handle As GLuint
    glGenTextures 1, handle
    glBindTexture GL_TEXTURE_2D, handle
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR
    glTexParameteri GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR
    glTexImage2D GL_TEXTURE_2D, 0, 4, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, ByVal VarPtr(data(0).r)
    glBindTexture GL_TEXTURE_2D, 0
    
    'dummytexcolor = handle
    dummytexbump = handle
End Sub

